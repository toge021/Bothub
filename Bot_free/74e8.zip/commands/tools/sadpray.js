export default {
    name: "sadpray",

    async execute(sock, mek, { from, args, sendWithContext }) {

        try {

            const prayer = `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ 𝙿𝚁𝙰𝚈𝙴𝚁 𝙾𝙵 𝚂𝙰𝙳𝙴𝚄𝚂
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

𝐒𝐴𝐷𝐸𝑈𝑆 : 𝐋𝐞𝐬 𝐦𝐞𝐢𝐥𝐥𝐞𝐮𝐫𝐬 𝐜𝐥𝐚𝐧 :

✦ ༉ᬼ⃟𝐷𝑎𝑛𝑠 𝑢𝑛 𝑚𝑜𝑛𝑑𝑒 𝑜𝑢̀ 𝑙𝑎 𝑛𝑎𝑡𝑢𝑟𝑒 𝑑𝑒𝑠 𝑒́𝑝𝑒́𝑒𝑠 𝑒𝑡 𝑙𝑒 𝑠𝑜𝑢𝑓𝑓𝑙𝑒 𝑑𝑒𝑠 𝑣𝑒𝑛𝑡𝑠 𝑓𝑜𝑟𝑔𝑒𝑛𝑡 𝑙𝑒𝑠 𝑎̂𝑚𝑒𝑠 𝑑𝑒 𝑔𝑢𝑒𝑟𝑟𝑖𝑒𝑟𝑠, 
𝑙𝑒 𝑐𝑙𝑎𝑛 𝑆𝐴𝐷𝐸𝑈𝑆 𝑠'𝑒́𝑙𝑒̀𝑣𝑒 𝑐𝑜𝑚𝑚𝑒 𝑢𝑛𝑒 𝑙𝑒́𝑔𝑒𝑛𝑑𝑒 𝑣𝑖𝑣𝑎𝑛𝑡𝑒, 
𝑚𝑦𝑠𝑡𝑒́𝑟𝑖𝑒𝑢𝑠𝑒 𝑒𝑡 𝑖𝑛𝑑𝑜𝑚𝑝𝑡𝑎𝑏𝑙𝑒.

✦ ༉ᬼ⃟ 𝑇𝑖𝑠𝑠𝑒́𝑠 𝑑𝑎𝑛𝑠 𝑙𝑒𝑠 𝑟𝑒𝑐𝑜𝑖𝑛𝑠 𝑠𝑜𝑚𝑏𝑟𝑒𝑠 𝑑𝑒 𝑙’ℎ𝑖𝑠𝑡𝑜𝑖𝑟𝑒, 
𝑠𝑒𝑠 𝑚𝑒𝑚𝑏𝑟𝑒𝑠 𝑠𝑜𝑛𝑡 𝑙𝑒𝑠 𝑎𝑟𝑡𝑖𝑠𝑎𝑛𝑠 𝑑'𝑢𝑛𝑒 𝑑𝑒𝑠𝑡𝑖𝑛𝑒́𝑒 
𝑚𝑎𝑟𝑞𝑢𝑒́𝑒 𝑝𝑎𝑟 𝑙’𝑜𝑚𝑏𝑟𝑒, 𝑙𝑎 𝑓𝑜𝑟𝑐𝑒 𝑒𝑡 𝑢𝑛𝑒 𝑠𝑎𝑔𝑒𝑠𝑠𝑒 𝑎𝑛𝑐𝑖𝑒𝑛𝑛𝑒.

✦ ༉ᬼ⃟𝐿𝑒 𝑛𝑜𝑚 𝑑𝑒 𝑆𝐴𝐷𝐸𝑈𝑆 𝑛𝑒 𝑠𝑒 𝑙𝑖𝑚𝑖𝑡𝑒 𝑝𝑎𝑠 𝑎̀ 𝑢𝑛 𝑠𝑖𝑚𝑝𝑙𝑒 𝑡𝑖𝑡𝑟𝑒, 
𝑖𝑙 𝑒𝑠𝑡 𝑢𝑛 𝑠𝑦𝑚𝑏𝑜𝑙𝑒 : 𝑟𝑒́𝑠𝑖𝑙𝑖𝑒𝑛𝑐𝑒, 𝑓𝑜𝑟𝑐𝑒 𝑒𝑡 𝑠𝑡𝑟𝑎𝑡𝑒́𝑔𝑖𝑒 𝑖𝑚𝑝𝑙𝑎𝑐𝑎𝑏𝑙𝑒.

✦ ༉ᬼ⃟𝐿'𝑎𝑙𝑙𝑒́𝑔𝑒𝑎𝑛𝑐𝑒, 𝑙𝑎 𝑑𝑖𝑠𝑐𝑖𝑝𝑙𝑖𝑛𝑒 𝑒𝑡 𝑙𝑎 𝑑𝑒́𝑡𝑒𝑟𝑚𝑖𝑛𝑎𝑡𝑖𝑜𝑛 
𝑔𝑢𝑖𝑑𝑒𝑛𝑡 𝑙𝑒 𝑐𝑙𝑎𝑛 𝑣𝑒𝑟𝑠 𝑙𝑎 𝑑𝑜𝑚𝑖𝑛𝑎𝑡𝑖𝑜𝑛.

╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
🐍🐍 "Dominons le monde"
`;

            // 📌 URL par défaut
            const defaultImage = "https://telegra.ph/file/0c9b6885669046f8d070b.jpg";

            const url = args[0] || defaultImage;

            await sendWithContext(sock, from, {
                image: { url },
                caption: prayer
            }, { quoted: mek });

        } catch (e) {

            console.log(e);

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╎ ⚠ ${e.message}
╰⊰
`
            }, { quoted: mek });
        }
    }
};