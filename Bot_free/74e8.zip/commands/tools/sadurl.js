import axios from "axios";
import { downloadContentFromMessage } from "@whiskeysockets/baileys";
import { IMGBB_API_KEY } from "../../config.js";

export default {
    name: "sadurl",

    async execute(sock, mek, { from, sendWithContext }) {

        try {

            // 🔥 récupération robuste image
            const quoted =
                mek.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage ||
                mek.message?.imageMessage;

            if (!quoted) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝚃𝙾𝙾𝙻𝚂"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ Réponds à une image
╰⊰◉⊱
`
                }, { quoted: mek });
            }

            if (!IMGBB_API_KEY) {
                return await sendWithContext(sock, from, {
                    text: "❌ API ImgBB manquante"
                }, { quoted: mek });
            }

            // 🔥 download image
            const stream = await downloadContentFromMessage(quoted, "image");

            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            // 🔥 IMPORTANT : base64 propre (SANS form-data)
            const base64 = buffer.toString("base64");

            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`,
                new URLSearchParams({
                    image: base64
                })
            );

            const url = res.data?.data?.url;

            if (!url) throw new Error("Upload failed");

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝚄𝙿𝙻𝙾𝙰𝙳"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🔗 URL généré
╰⊰◉⊱🐍 Dominons le monde 🐍 

⚘ ${url}

🫴🍷 "I'm perfect in every way"
`
            }, { quoted: mek });

        } catch (e) {

            console.log(e);

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ ${e.message}
╰⊰◉⊱
`
            }, { quoted: mek });

        }
    }
};