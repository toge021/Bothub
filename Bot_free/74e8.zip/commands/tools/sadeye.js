import { downloadContentFromMessage } from "@whiskeysockets/baileys";

export default {
    name: "sadeye",

    async execute(sock, mek, { from, sendWithContext }) {

        try {

            const quoted = mek.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            if (!quoted) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙴𝚈𝙴"
╎ ⚠ Réponds à une vue unique
╰⊰
`
                }, { quoted: mek });
            }

            // 🔥 CAS 1 : structure viewOnce classique
            let viewOnce =
                quoted.viewOnceMessageV2?.message ||
                quoted.viewOnceMessage?.message;

            // 🔥 CAS 2 : WhatsApp récent (IMPORTANT)
            if (!viewOnce) {
                if (quoted.imageMessage?.viewOnce) {
                    viewOnce = { imageMessage: quoted.imageMessage };
                } else if (quoted.videoMessage?.viewOnce) {
                    viewOnce = { videoMessage: quoted.videoMessage };
                }
            }

            if (!viewOnce) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙴𝚈𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Ce n'est pas une vue unique
╰⊰◉⊱
`
                }, { quoted: mek });
            }

            const type = Object.keys(viewOnce)[0];
            const media = viewOnce[type];

            if (!media) {
                return await sendWithContext(sock, from, {
                    text: "❌ Média introuvable"
                }, { quoted: mek });
            }

            const stream = await downloadContentFromMessage(
                media,
                type === "imageMessage" ? "image" : "video"
            );

            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            if (type === "imageMessage") {

                await sendWithContext(sock, from, {
                    image: buffer,
                    caption: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙴𝚈𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🐍 Dominons le monde 🐍 
╰⊰◉⊱
`
                }, { quoted: mek });

            } else {

                await sendWithContext(sock, from, {
                    video: buffer,
                    caption: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙴𝚈𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🐍Vive sadeus 
╰⊰◉⊱
`
                }, { quoted: mek });

            }

        } catch (e) {

            console.log(e);

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╎ ⚠ ${e.message}
╰⊰
`
            }, { quoted: mek });

        }
    }
};