import * as config from '../../config.js';

export default {
    name: "sadmode",

    async execute(sock, mek, { from, args, sendWithContext }) {

        try {

            const mode = args[0]?.toLowerCase();

            if (!mode) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙼𝙾𝙳𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ Mode actuel : ${global.MODE ?? config.MODE}
╰⊰◉⊱

⚘ Utilisation :
• .sadmode public
• .sadmode private
`
                }, { quoted: mek });
            }

            if (mode === "public") {

                global.MODE = "public";

                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙼𝙾𝙳𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🌍 Mode PUBLIC activé
╎ ⚘ Accessible à tous
╰⊰◉⊱
`
                }, { quoted: mek });

            }

            if (mode === "private") {

                global.MODE = "private";

                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙼𝙾𝙳𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🔒 Mode PRIVATE activé
╎ ⚘ Réservé à l'owner
╰⊰◉⊱
`
                }, { quoted: mek });

            }

            return await sendWithContext(sock, from, {
                text: "⚠ Utilise : public / private"
            }, { quoted: mek });

        } catch (e) {

            console.log(e);

            await sendWithContext(sock, from, {
                text: `❌ ${e.message}`
            }, { quoted: mek });

        }
    }
};