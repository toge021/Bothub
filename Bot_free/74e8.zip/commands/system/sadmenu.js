import fs from 'fs';
import { IMAGES } from '../../config.js';

export default {
    name: "sadmenu",
    async execute(sock, mek, { from, prefix, sendWithContext }) {
        const menuText = `╭⊰◉⊱╌╌╌╌╌╌╌╌╌╌╌⊰𓆤⊱
╎ S
╎ A
╎ D
╎ E
╎ U
╎ S
╎
╎ F
╎ A
╎ M
╎ I
╎ L
╎ Y
╎
╎ B
╎ O
╎ T
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
«⊰◉⊱ "𝙼𝙴𝙽𝚄 🐍" ⊰◉⊱»

╭⊰ "𝚂𝚈𝚂𝚃𝙴𝙼." ⊱ ⚙️
╠⊰◉⊱╌╌╌╌╌╌╌╌╌╌╌⊰𓃠⊱
╎ ⚘ ${prefix}sadmenu
╎ ⚘ ${prefix}sadfixe 
╎ ⚘ ${prefix}sadfix 
╎ ⚘ ${prefix}sadmode 
╎ ⚘ ${prefix}sadping
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝙰𝙳𝙼𝙸𝙽." ⊱ 👑
╠╌╌╌╌╌╌╌╌╌╌╌⊰𓆏⊱
╎ ⚘ ${prefix}sadeus 
╎ ⚘ ${prefix}sadmote 
╎ ⚘ ${prefix}sadnotmote 
╎ ⚘ ${prefix}sadnotmoteall 
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝙶𝚁𝙾𝚄𝙿." ⊱ 👥
╠╌╌╌╌╌╌╌╌╌╌╌⊰𓃦⊱
╎ ⚘ ${prefix}sad-all 
╎ ⚘ ${prefix}sadlock
╎ ⚘ ${prefix}sadunlock
╎ ⚘ ${prefix}sadname 
╎ ⚘ ${prefix}sadpp 
╎ ⚘ ${prefix}saddesc 
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝚃𝙾𝙾𝙻𝚂." ⊱ 🧠
╠╌╌╌╌╌╌╌╌╌╌╌⊰𓅓⊱
╎ ⚘ ${prefix}sadeye 
╎ ⚘ ${prefix}sadpray 
╎ ⚘ ${prefix}sadurl 
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝙸𝙽𝙵𝙾." ⊱ 📊
╠╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🐍 Dominons le monde 🐍 
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
«⊰ I'm perfect in every way 🫴🍷 ⊱»`;

        let image = fs.existsSync(IMAGES.MENU) ? fs.readFileSync(IMAGES.MENU) : null;
        
        await sendWithContext(sock, from, {
            image: image || { url: 'https://telegra.ph/file/0c9b6885669046f8d070b.jpg' },
            caption: menuText
        }, { quoted: mek });
    }
};
