export default {
    name: 'sadfixe',

    async execute(sock, mek, { from, args, sendWithContext }) {

        try {

            if (args.length === 0) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Fournis un nouveau préfixe
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
                }, { quoted: mek });
            }

            const oldPrefix = global.PREFIX || ".";
            const newPrefix = args[0];

            // 🔥 stockage mémoire
            global.PREFIX = newPrefix;

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙲𝙾𝙽𝚃𝚁𝙾𝙻"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ Préfixe modifié
╎ ☠ ${oldPrefix} ➜ ${newPrefix}
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
🐍 Sadeus Override
`
            }, { quoted: mek });

        } catch (e) {

            console.log(e);

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╎ ⚠ ${e.message}
╰⊰
`
            }, { quoted: mek });
        }
    }
};