export default {
    name: "sadfix",

    async execute(sock, mek, { from, args, sendWithContext }) {

        try {

            if (args.length === 0) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙸𝚇"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ Utilisation : .sadfix on/off
╰⊰◉⊱🐍 Dominons le monde 🐍 
`
                }, { quoted: mek });
            }

            const mode = args[0].toLowerCase();

            if (mode === "on") {

                global.NO_PREFIX = true;

                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙸𝚇"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ Mode sans préfixe ACTIVÉ
╰⊰◉⊱🐍 Dominons le monde 🐍 
`
                }, { quoted: mek });

            }

            if (mode === "off") {

                global.NO_PREFIX = false;

                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙸𝚇"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ Mode sans préfixe DÉSACTIVÉ
╰⊰◉⊱ 🐍 Dominons le monde 🐍
`
                }, { quoted: mek });

            }

            return await sendWithContext(sock, from, {
                text: "⚠ Utilise : on / off"
            }, { quoted: mek });

        } catch (e) {

            console.log(e);

            await sendWithContext(sock, from, {
                text: `❌ ${e.message}`
            }, { quoted: mek });

        }
    }
};