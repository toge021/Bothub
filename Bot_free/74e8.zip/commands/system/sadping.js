export default {
    name: "sadping",

    async execute(sock, mek, { from, sendWithContext }) {

        const start = Date.now();

        const { key } = await sendWithContext(sock, from, {
            text: `
╭⊰ "𝚂𝙰𝙳𝙿𝙸𝙽𝙶"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ System check...
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
        });

        const end = Date.now();
        const latency = end - start;

        await sendWithContext(sock, from, {
            text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝚂𝚃𝙰𝚃𝚄𝚂"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ☠ Latence : ${latency} ms
╎ 🐍 Dominons le monde 🐍 
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
`
            ,
            edit: key
        });

    }
};