import * as config from '../../config.js';

export default {
    name: 'sadnotmoteall',
    async execute(sock, mek, { from, isGroup, sendWithContext }) {
        if (!isGroup) return;

        try {
            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants;

            // 🔥 récupérer sender JID propre
            const senderJid = mek.key.participant || mek.key.remoteJid;

            // 🔥 owner clean
            const ownerJid = String(config.OWNER_NUMBER).replace(/\D/g, '') + "@s.whatsapp.net";

            // 🔥 tous les admins
            const admins = participants.filter(p => p.admin).map(p => p.id);

            // 🔥 filtrer (ne pas demote owner + toi)
            const toDemote = admins.filter(id => id !== ownerJid && id !== senderJid);

            if (toDemote.length === 0) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙳𝙴𝙼𝙾𝚃𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Aucun admin à rétrograder
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
                }, { quoted: mek });
            }

            // 🔥 demote en batch
            await sock.groupParticipantsUpdate(from, toDemote, 'demote');

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙳𝙴𝙼𝙾𝚃𝙴 𝙰𝙻𝙻"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ☠ Tous les admins rétrogradés
╎  🐍 Dominons le monde 🐍
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
      🐍Dominons le monde 🐍
`
            }, { quoted: mek });

        } catch (e) {
            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ ${e.message}
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
            }, { quoted: mek });
        }
    }
};