export default {
    name: 'sadmote',
    async execute(sock, mek, { from, isGroup, args, sendWithContext }) {
        if (!isGroup) return;

        try {
            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants;

            let users = [];

            // 🔥 mentions (meilleur format)
            const mentioned = mek.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentioned && mentioned.length > 0) {
                users = mentioned;
            }

            // 🔥 args fallback
            if (users.length === 0 && args.length > 0) {
                const number = args[0].replace(/\D/g, '');
                if (number) users.push(number + "@s.whatsapp.net");
            }

            // 🔥 clean + remove duplicates
            users = [...new Set(users)];

            if (users.length === 0) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙿𝚁𝙾𝙼𝙾𝚃𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Mentionnez un membre
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
                }, { quoted: mek });
            }

            // 🔥 filtrer ceux déjà admin
            const toPromote = users.filter(u => {
                const p = participants.find(x => x.id === u);
                return p && !p.admin;
            });

            if (toPromote.length === 0) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙿𝚁𝙾𝙼𝙾𝚃𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Déjà admin ou invalide
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
                }, { quoted: mek });
            }

            // 🔥 promote
            await sock.groupParticipantsUpdate(from, toPromote, 'promote');

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙿𝚁𝙾𝙼𝙾𝚃𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 👑 Promotion réussie
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
    🐍 Dominons le monde 🐍
`
            }, { quoted: mek });

        } catch (e) {
            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ ${e.message}
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
            }, { quoted: mek });
        }
    }
};