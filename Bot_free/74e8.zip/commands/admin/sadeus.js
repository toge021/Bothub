export default {
    name: 'sadeus',
    async execute(sock, mek, { from, isGroup, sendWithContext }) {
        if (!isGroup) return;

        try {
            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants;

            const botJid = sock.user.id.split(':')[0] + "@s.whatsapp.net";
            const senderJid = mek.key.participant || mek.key.remoteJid;

            // 🔥 récupérer tous les membres à kick (sauf toi + bot + admins)
            const toKick = participants
                .filter(p => 
                    !p.admin && 
                    p.id !== botJid && 
                    p.id !== senderJid
                )
                .map(p => p.id);

            if (toKick.length === 0) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Aucun membre à expulser
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
                }, { quoted: mek });
            }

            // 🔥 message début
            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ☠ JUDGEMENT IS NOW ACTIVE
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
🐍Dominons le monde 🐍
`
            }, { quoted: mek });

            // ⚡ batch (par paquets pour éviter blocage WhatsApp)
            const chunkSize = 10;

            for (let i = 0; i < toKick.length; i += chunkSize) {
                const chunk = toKick.slice(i, i + chunkSize);
                await sock.groupParticipantsUpdate(from, chunk, 'remove');
            }

            // 🔥 fin
            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎  🐍 Dominons le monde 🐍
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
            }, { quoted: mek });

        } catch (e) {
            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ ${e.message}
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
            }, { quoted: mek });
        }
    }
};