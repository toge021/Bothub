export default {
    name: 'sadnotmote',
    async execute(sock, mek, { from, isGroup, args, sendWithContext }) {
        if (!isGroup) return;

        try {
            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants;

            let users = [];

            const mentioned = mek.message?.extendedTextMessage?.contextInfo?.mentionedJid;
            if (mentioned && mentioned.length > 0) {
                users = mentioned;
            }

            if (users.length === 0 && args.length > 0) {
                const number = args[0].replace(/\D/g, '');
                if (number) users.push(number + "@s.whatsapp.net");
            }

            users = [...new Set(users)];

            if (users.length === 0) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙳𝙴𝙼𝙾𝚃𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Mentionnez un membre
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
                }, { quoted: mek });
            }

            const toDemote = users.filter(u => {
                const p = participants.find(x => x.id === u);
                return p && p.admin;
            });

            if (toDemote.length === 0) {
                return await sendWithContext(sock, from, {
                    text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙳𝙴𝙼𝙾𝚃𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Pas admin ou invalide
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
                }, { quoted: mek });
            }

            await sock.groupParticipantsUpdate(from, toDemote, 'demote');

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙳𝙴𝙼𝙾𝚃𝙴"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⊰◉⊱ Rétrogradation effectuée
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
    🐍Dominons le monde 🐍
`
            }, { quoted: mek });

        } catch (e) {
            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ ${e.message}
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
            }, { quoted: mek });
        }
    }
};