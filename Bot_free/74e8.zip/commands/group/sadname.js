export default {
    name: "sadname",
    async execute(sock, mek, { from, isGroup, args, sendWithContext }) {
        if (!isGroup) return;
        if (args.length === 0) return await sendWithContext(sock, from, { text: "Veuillez fournir le nouveau nom du groupe." }, { quoted: mek });
        const newName = args.join(" ");
        await sock.groupUpdateSubject(from, newName);
        await sendWithContext(sock, from, { text: "✅ Nom du groupe changé en : " + newName }, { quoted: mek });
    }
};
