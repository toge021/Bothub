export default {
    name: "saddesc",
    async execute(sock, mek, { from, isGroup, args, sendWithContext }) {
        if (!isGroup) return;

        if (args.length === 0) {
            return await sendWithContext(
                sock,
                from,
                { text: "╎ ⚘ Veuillez fournir la nouvelle description du groupe." },
                { quoted: mek }
            );
        }

        const newDesc = args.join(" ");

        await sock.groupUpdateDescription(from, newDesc);

        await sendWithContext(
            sock,
            from,
            {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝚂𝚈𝚎𝚜𝚝𝚎𝚖"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 📢 𝙈𝙄𝙎𝙀 𝘼 𝙅𝙊𝙐𝙍 𝙀𝙁𝙁𝙀𝘾𝙏𝙐𝙀𝙀
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝘾𝙊𝙉𝙏𝙀𝙉𝙐"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚘ ${newDesc}
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
   🐍 Dominons le monde 🐍 
`
            },
            { quoted: mek }
        );
    }
};