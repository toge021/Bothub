export default {
    name: 'sadlock',
    async execute(sock, mek, { from, isGroup, sendWithContext }) {
        if (!isGroup) return;

        await sock.groupSettingUpdate(from, 'announcement');

        await sendWithContext(
            sock,
            from,
            {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙳𝙴𝙲𝚁𝙴𝚃"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🔒 𝙇𝙀 𝙂𝙍𝙊𝙐𝙋𝙀 𝙀𝙎𝙏 𝙁𝙀𝙍𝙈𝙀
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝘿𝙄𝙎𝙋𝙊𝙎𝙄𝙏𝙄𝙊𝙉"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ☠ Le silence est désormais imposé
╎ ☠ Seuls les Sadeus peuvent agir
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
   🐍 Dominons le monde 🐍 
`
            },
            { quoted: mek }
        );
    }
};