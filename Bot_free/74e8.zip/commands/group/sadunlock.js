export default {
    name: 'sadunlock',
    async execute(sock, mek, { from, isGroup, sendWithContext }) {
        if (!isGroup) return;

        try {
            await sock.groupSettingUpdate(from, 'not_announcement');

            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝚄𝙽𝙻𝙾𝙲𝙺"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🔓 𝙶𝚛𝚘𝚞𝚙𝚎 𝚘𝚞𝚟𝚎𝚛𝚝 𝚊̀ 𝚝𝚘𝚞𝚜
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
   🐍 Dominons le monde 🐍 
`
            }, { quoted: mek });

        } catch (e) {
            await sendWithContext(sock, from, {
                text: `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙵𝙰𝙸𝙻"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ⚠ Erreur lors de l’ouverture
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱
`
            }, { quoted: mek });
        }
    }
};