export default {
    name: "sad-all",
    async execute(sock, mek, { from, isGroup, sendWithContext }) {
        if (!isGroup) return;

        const groupMetadata = await sock.groupMetadata(from);
        const participants = groupMetadata.participants;

        let text = `
╭⊰ "𝚂𝙰𝙳𝙴𝚄𝚂 𝙲𝙾𝙽𝚅𝙾𝙲𝙰𝚃𝙸𝙾𝙽"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 📢 𝘼𝙇𝙀𝙍𝙏𝙀 𝘿𝙐 𝘾𝙇𝘼𝙉 𝙎𝘼𝘿𝙀𝙐𝙎
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝘾𝙊𝙉𝙑𝙊𝘾𝘼𝙏𝙄𝙊𝙉"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ ☠ À tous les Sadeus et êtres inférieurs…
╎ ☠ Cette convocation est active.
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝙇𝙄𝙎𝙏𝙀 𝘿𝙀𝙎 𝙈𝙀𝙈𝘽𝙍𝙀𝙎"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
`;

        for (let mem of participants) {
            text += `╎ ⚘ @${mem.id.split('@')[0]}\n`;
        }

        text += `
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

╭⊰ "𝙅𝙐𝙂𝙀𝙈𝙀𝙉𝙏 𝙎𝘼𝘿𝙀𝙐𝙎"
╠╌╌╌╌╌╌╌╌╌╌╌╌╌⊰𓆑⊱
╎ 🐍 Dominons le monde 🐍 
╎ 🐍 Dominons le monde 🐍 
╰⊰◉⊱╌╌╌╌╌╌╌╌╌╌⊰◉⊱

🫴🍷 "I'm perfect in every way"
       🐍 Sadeus Family 🐍
`;

        await sendWithContext(
            sock,
            from,
            { 
                text,
                mentions: participants.map(p => p.id) 
            },
            { quoted: mek }
        );
    }
};