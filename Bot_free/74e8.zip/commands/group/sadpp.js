import { downloadContentFromMessage } from "@whiskeysockets/baileys";

export default {
    name: "sadpp",
    async execute(sock, mek, { from, isGroup, sendWithContext }) {
        if (!isGroup) return;
        const quoted = mek.message.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage || mek.message.imageMessage;
        if (!quoted) return await sendWithContext(sock, from, { text: "Répondez à une image pour changer la photo du groupe." }, { quoted: mek });
        
        const stream = await downloadContentFromMessage(quoted, 'image');
        let buffer = Buffer.from([]);
        for await (const chunk of stream) {
            buffer = Buffer.concat([buffer, chunk]);
        }
        
        await sock.updateProfilePicture(from, buffer);
        await sendWithContext(sock, from, { text: "✅ Photo de profil du groupe mise à jour." }, { quoted: mek });
    }
};
