import dotenv from 'dotenv';
dotenv.config();

export const BOT_NAME = process.env.BOT_NAME || "SADEUS FAMILY BOT";
export const OWNER_NUMBER = process.env.OWNER_NUMBER || "228XXXXXXXX";
export const PREFIX = process.env.PREFIX || ".";
export const WA_CHANNEL = process.env.WA_CHANNEL || "https://whatsapp.com/channel/0029VajM9Z99sBI5mN7x2u2y";
export const IMGBB_API_KEY = process.env.IMGBB_API_KEY || "";

export let NO_PREFIX = false;
export let MODE = "public";

export const IMAGES = {
    MENU: "./images/sadmenu.jpg",
    THUMB: "./images/thumb.jpg",
    CONTEXT: "./images/sadeus_logo.jpg"
};
