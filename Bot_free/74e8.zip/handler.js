import fs from 'fs';
import path from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import * as config from './config.js';
import { sendWithContext } from './utils/sendWithContext.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let commands = new Map();

const clr = {
    green: (text) => `\x1b[32m${text}\x1b[0m`,
    red: (text) => `\x1b[31m${text}\x1b[0m`,
    blue: (text) => `\x1b[34m${text}\x1b[0m`
};

export async function loadCommands() {
    commands.clear();

    const commandFolders = ["admin", "group", "tools", "system"];

    for (const folder of commandFolders) {
        const folderPath = path.join(__dirname, "commands", folder);

        if (!fs.existsSync(folderPath)) continue;

        const commandFiles = fs.readdirSync(folderPath).filter(file => file.endsWith(".js"));

        for (const file of commandFiles) {
            try {
                const fileUrl = pathToFileURL(path.join(folderPath, file)).href;
                const module = await import(`${fileUrl}?update=${Date.now()}`);

                const command = module.default;

                if (command && command.name) {
                    commands.set(command.name.toLowerCase(), command);
                    console.log(clr.green(`[SUCCESS] Commande chargée : ${command.name}`));
                }

            } catch (e) {
                console.log(clr.red(`[ERROR] Impossible de charger ${file}:`), e.message);
            }
        }
    }
}

await loadCommands();

export async function handler(sock, mek) {

    try {

        if (!mek.message) return;

        const from = mek.key.remoteJid;
        const type = Object.keys(mek.message)[0];

        let body = '';

        if (type === 'conversation') body = mek.message.conversation;
        else if (type === 'extendedTextMessage') body = mek.message.extendedTextMessage.text;
        else if (type === 'imageMessage') body = mek.message.imageMessage.caption;
        else if (type === 'videoMessage') body = mek.message.videoMessage.caption;

        if (!body) return;

        const sender = mek.key.participant || mek.key.remoteJid;

        const senderNumber = sender.split("@")[0].replace(/[^0-9]/g, '');
        const ownerNumber = config.OWNER_NUMBER.replace(/[^0-9]/g, '');

        const isOwner = senderNumber === ownerNumber;
        const isGroup = from.endsWith("@g.us");

        // 🚫 MODE PRIVATE (gardé)
        if (config.MODE === "private" && !isOwner) return;

        const prefix = global.PREFIX || config.PREFIX;;

        const isCmd = body.startsWith(prefix);

        const noPrefix = global.NO_PREFIX ?? config.NO_PREFIX;

const commandText = isCmd
    ? body.slice(prefix.length).trim().split(/ +/).shift().toLowerCase()
    : (noPrefix
        ? body.trim().split(/ +/).shift().toLowerCase()
        : "");

const args = body.trim().split(/ +/).slice(1);

const cmd = commands.get(commandText);

if (!cmd) return;

        console.log(clr.blue(`[EXEC] Commande: ${commandText} par ${senderNumber}`));

        try {
            await sock.sendMessage(from, {
                react: { text: "🐍", key: mek.key }
            });
        } catch (e) {}

        await cmd.execute(sock, mek, {
            from,
            isGroup,
            sender,
            args,
            body,
            isOwner,
            commands,
            prefix,
            sendWithContext
        });

    } catch (err) {
        console.log(clr.red("[CRITICAL ERROR] Handler :"), err.message);
    }
}