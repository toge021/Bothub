import fs from 'fs';
import path from 'path';
import { WA_CHANNEL, IMAGES } from '../config.js';

const NEWSLETTER_JID = "120363424857953119@newsletter";
const NEWSLETTER_NAME = "🐍 𝑺𝑨𝑫𝑬𝑼𝑺 𝑭𝑨𝑴𝑰𝑳𝑳𝑬 🐍";

let thumbBuffer = null;
try {
    const imagePath = path.resolve(IMAGES.CONTEXT);
    if (fs.existsSync(imagePath)) {
        thumbBuffer = fs.readFileSync(imagePath);
    }
} catch (err) {
    // Silencieux si l'image n'existe pas
}

export function getContextInfo() {
    return {
        forwardingScore: 99,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: NEWSLETTER_JID,
            newsletterName: NEWSLETTER_NAME,
            serverMessageId: -1
        },
        externalAdReply: {
            title: "Rejoins notre chaîne WhatsApp",
            body: "🐍 𝑺𝑨𝑫𝑬𝑼𝑺 𝑭𝑨𝑴𝑰𝑳𝑳𝑬 🐍",
            mediaType: 1,
            thumbnail: thumbBuffer,
            renderLargerThumbnail: true,
            mediaUrl: WA_CHANNEL,
            sourceUrl: WA_CHANNEL,
            thumbnailUrl: WA_CHANNEL
        }
    };
}

export async function sendWithContext(client, remoteJid, content, options = {}) {
    const contextInfo = getContextInfo();
    const message = {
        ...content,
        contextInfo
    };
    return await client.sendMessage(remoteJid, message, options);
}
