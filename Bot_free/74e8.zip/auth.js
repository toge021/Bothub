// Ce fichier peut servir à centraliser la logique d'authentification si nécessaire.
// Pour l'instant, la logique est intégrée dans index.js pour rester léger.
module.exports = {};
