// copilot.js — ITACHI-XMD-V2
const axios = require('axios');

async function copilotCommand(sock, chatId, message, args) {
    const query = args.join(' ');
    if (!query) return sock.sendMessage(chatId, {
        text: '❌ Usage: .copilot <demande>\nEx: .copilot crée un menu whatsapp bot'
    }, { quoted: message });

    try {
        await sock.sendMessage(chatId, { text: '💻 Copilot génère le code...' }, { quoted: message });

        const prompt = `Tu es GitHub Copilot expert en développement. Génère du code propre et commenté pour: ${query}`;
        let answer = null;
        const apis = [
            `https://api.kastg.xyz/api/ai/chatgptV4?prompt=${encodeURIComponent(prompt)}`,
            `https://api.siputzx.my.id/api/ai/meta-llama?content=${encodeURIComponent(prompt)}`,
            `https://api.ryzendesu.vip/api/ai/chatgpt?text=${encodeURIComponent(prompt)}`
        ];

        for (const url of apis) {
            try {
                const r = await axios.get(url, { timeout: 20000 });
                answer = r.data?.result || r.data?.data || r.data?.response || r.data?.message;
                if (answer) break;
            } catch {}
        }

        if (!answer) throw new Error('API indisponible');

        await sock.sendMessage(chatId, {
            image: { url: 'https://i.ibb.co/xSScX4bP/file-0000000060a471fd918d46d4c7c69a21.png' },
            caption: `💻 *COPILOT AI — ITACHI-XMD*\n\n📋 *Demande :* ${query}\n\n${answer}\n\n> 🥷 IBSACKO™ · CENTRAL-HEX`
        }, { quoted: message });

    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ Erreur Copilot: ${e.message}` }, { quoted: message });
    }
}
module.exports = copilotCommand;
