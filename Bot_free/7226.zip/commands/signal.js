// commands/signal.js
// by Mr_Marco 🍷 — adapté pour ITACHI-XMD-V2

async function signalCommand(sock, chatId, senderId, mentionedJids, message, args) {
    let target = null;
    let count = 5;

    const numbers = args.filter(arg => /^\d+$/.test(arg));
    const nonNumbers = args.filter(arg => !/^\d+$/.test(arg));

    // 1. Mention prioritaire
    if (mentionedJids && mentionedJids.length > 0) {
        target = mentionedJids[0];
        if (numbers.length > 0) count = Math.min(parseInt(numbers[0]), 100);
    }
    // 2. Numéro donné en argument
    else if (nonNumbers.length > 0) {
        let cleaned = nonNumbers[nonNumbers.length - 1].replace(/[^0-9]/g, "");
        if (cleaned.length < 7) {
            return sock.sendMessage(chatId, {
                text: "❌ Numéro invalide.\nExemple : `.signal 5094113xxxx`"
            }, { quoted: message });
        }
        target = cleaned + "@s.whatsapp.net";
        if (numbers.length > 0) count = Math.min(parseInt(numbers[0]), 100);
    }
    // 3. Conversation privée sans argument
    else if (!chatId.endsWith("@g.us")) {
        target = chatId;
        if (numbers.length > 0) count = Math.min(parseInt(numbers[0]), 100);
    }

    if (!target) {
        return sock.sendMessage(chatId, {
            text: "❌ *Utilisation :*\n• `.signal @mention`\n• `.signal <numéro> <nombre>`\n• En privé : `.signal` tout court"
        }, { quoted: message });
    }

    if (count < 1) count = 1;

    const targetName = target.split("@")[0];

    await sock.sendMessage(chatId, {
        text: `🚨 *Signalement de* *${targetName}* *en cours...*\nNombre : ${count}\n_(Aucun message envoyé à la cible)_`,
        mentions: [target]
    }, { quoted: message });

    let success = 0;
    for (let i = 1; i <= count; i++) {
        try {
            // Méthode compatible @whiskeysockets/baileys
            await sock.sendMessage(target, {
                contact: {
                    displayName: "Report",
                    vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Report\nEND:VCARD`
                }
            });
            // Bloquer puis débloquer pour simuler signalement
            await sock.updateBlockStatus(target, "block");
            await new Promise(r => setTimeout(r, 500));
            await sock.updateBlockStatus(target, "unblock");
            success++;
            console.log(`✅ Signalement ${i}/${count} pour ${target}`);
        } catch (err) {
            console.error(`❌ Échec signalement ${i} : ${err.message}`);
        }
        if (i < count) {
            await new Promise(r => setTimeout(r, 2000));
        }
    }

    await sock.sendMessage(chatId, {
        text: `✅ *${success}/${count}* signalement(s) effectué(s) contre *${targetName}*.`,
        mentions: [target]
    }, { quoted: message });
}

module.exports = signalCommand;
