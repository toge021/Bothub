// sticker.js — ITACHI-XMD-V2
// Adapté depuis wa-sticker-formatter par IBSACKO™
const { downloadMediaMessage } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const channelInfo = {
    forwardingScore: 1, isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363408304719268@newsletter',
        newsletterName: 'ITACHI-XMD', serverMessageId: -1
    }
};

async function stickerCommand(sock, chatId, message) {
    let tempInput, tempOutput;
    try {
        const quotedMessage = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const username = message.pushName || 'ITACHI-XMD';

        if (!quotedMessage) {
            return sock.sendMessage(chatId, {
                image: { url: 'https://i.ibb.co/xSScX4bP/file-0000000060a471fd918d46d4c7c69a21.png' },
                caption: `🥷 *STICKER — ITACHI-XMD*\n\n❌ Réponds à une image ou vidéo avec *.sticker*\n\n> 🥷 IBSACKO™`,
                contextInfo: channelInfo
            }, { quoted: message });
        }

        const isVideo = !!quotedMessage.videoMessage;
        const isImage = !!quotedMessage.imageMessage;

        if (!isVideo && !isImage) {
            return sock.sendMessage(chatId, {
                text: '❌ Le message cité doit être une image ou une vidéo !'
            }, { quoted: message });
        }

        await sock.sendMessage(chatId, { text: '⚙️ Conversion en sticker en cours...' }, { quoted: message });

        // Télécharger le média depuis le message cité
        const quotedInfo = message.message.extendedTextMessage.contextInfo;
        const targetMessage = {
            key: {
                remoteJid: chatId,
                id: quotedInfo.stanzaId,
                participant: quotedInfo.participant
            },
            message: quotedMessage
        };

        const mediaBuffer = await downloadMediaMessage(targetMessage, 'buffer', {});
        if (!mediaBuffer) throw new Error('Téléchargement du média échoué');

        // Fichiers temporaires
        const uniqueId = Date.now();
        const tmpDir = path.join(__dirname, '../tmp');
        if (!fs.existsSync(tmpDir)) fs.mkdirSync(tmpDir, { recursive: true });

        tempInput = path.join(tmpDir, isVideo ? `video_${uniqueId}.mp4` : `image_${uniqueId}.jpg`);
        tempOutput = path.join(tmpDir, `sticker_${uniqueId}.webp`);
        fs.writeFileSync(tempInput, mediaBuffer);

        if (isVideo) {
            // Conversion vidéo → webp animé avec ffmpeg
            await new Promise((resolve, reject) => {
                exec(
                    `ffmpeg -i "${tempInput}" -vf "scale=512:512:flags=lanczos,fps=15" -c:v libwebp -q:v 50 -preset default -loop 0 -an -vsync 0 -t 10 "${tempOutput}"`,
                    { timeout: 60000 },
                    (err) => {
                        if (err) reject(err);
                        else resolve();
                    }
                );
            });
        } else {
            // Conversion image → webp avec ffmpeg
            await new Promise((resolve, reject) => {
                exec(
                    `ffmpeg -i "${tempInput}" -vf "scale=512:512:flags=lanczos" -c:v libwebp -q:v 80 "${tempOutput}"`,
                    { timeout: 30000 },
                    (err) => {
                        if (err) {
                            // Fallback sans ffmpeg
                            exec(`convert "${tempInput}" -resize 512x512 "${tempOutput}"`,
                                { timeout: 20000 },
                                (err2) => { if (err2) reject(err2); else resolve(); }
                            );
                        } else resolve();
                    }
                );
            });
        }

        if (!fs.existsSync(tempOutput)) throw new Error('Conversion échouée');

        const stickerBuffer = fs.readFileSync(tempOutput);

        // Ajouter metadata au sticker (pack/author)
        await sock.sendMessage(chatId, {
            sticker: stickerBuffer,
            contextInfo: channelInfo
        }, { quoted: message });

    } catch (error) {
        console.error('❌ Erreur sticker:', error.message);
        await sock.sendMessage(chatId, {
            text: `⚠️ Erreur conversion sticker: ${error.message}`
        }, { quoted: message });
    } finally {
        // Nettoyage fichiers temporaires
        try { if (tempInput && fs.existsSync(tempInput)) fs.unlinkSync(tempInput); } catch {}
        try { if (tempOutput && fs.existsSync(tempOutput)) fs.unlinkSync(tempOutput); } catch {}
    }
}

module.exports = stickerCommand;
