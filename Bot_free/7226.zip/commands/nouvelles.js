// Nouvelles commandes : kickall, purge, antipurge, sanction, uptime, test, info, contact,
//                       autorecording, restore, clan, loi, antimarabout
const fs = require('fs');
const path = require('path');
const os = require('os');

const channelInfo = {
    forwardingScore: 1, isForwarded: true,
    forwardedNewsletterMessageInfo: {
        newsletterJid: '120363408304719268@newsletter',
        newsletterName: 'ITACHI-XMD', serverMessageId: -1
    }
};

const BOT_IMG = 'https://i.ibb.co/xSScX4bP/file-0000000060a471fd918d46d4c7c69a21.png';
const antimaraboutFile = path.join(__dirname, '../data/antimarabout.json');
const antipurgeFile = path.join(__dirname, '../data/antipurge.json');

function formatUptime(s) {
    const d = Math.floor(s/86400), h = Math.floor((s%86400)/3600);
    const m = Math.floor((s%3600)/60), sc = Math.floor(s%60);
    return `${d>0?d+'j ':''}${h}h ${m}m ${sc}s`;
}

// ─── KICKALL ─────────────────────────────────────────
async function kickallCommand(sock, chatId, senderId, message) {
    if (!chatId.endsWith('@g.us')) return await sock.sendMessage(chatId, { text: '❌ Uniquement dans les groupes !', contextInfo: channelInfo }, { quoted: message });
    try {
        const meta = await sock.groupMetadata(chatId);
        const botId = (sock.user.id || '').replace(/:\d+/, '') + '@s.whatsapp.net';
        const nonAdmins = meta.participants.filter(p => !p.admin && p.id !== botId);
        if (nonAdmins.length === 0) return await sock.sendMessage(chatId, { text: 'ℹ️ *Aucun membre non-admin à expulser.*', contextInfo: channelInfo }, { quoted: message });
        await sock.sendMessage(chatId, { text: `⏳ *Expulsion de ${nonAdmins.length} membres...* ⚠️`, contextInfo: channelInfo }, { quoted: message });
        await sock.groupParticipantsUpdate(chatId, nonAdmins.map(p => p.id), 'remove');
        await sock.sendMessage(chatId, { text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n✅ *${nonAdmins.length} membres expulsés !*\n> _Groupe nettoyé par ITACHI-XMD_`, contextInfo: channelInfo }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ *Erreur :* ${e.message}`, contextInfo: channelInfo }, { quoted: message });
    }
}

// ─── PURGE ───────────────────────────────────────────
async function purgeCommand(sock, chatId, senderId, args, message) {
    if (!chatId.endsWith('@g.us')) return await sock.sendMessage(chatId, { text: '❌ Uniquement dans les groupes !', contextInfo: channelInfo }, { quoted: message });
    const nb = parseInt(args[0]) || 10;
    try {
        await sock.sendMessage(chatId, { text: `🧹 *Purge de ${nb} messages...*\n> _Nettoie le chat_`, contextInfo: channelInfo }, { quoted: message });
        // Réaction de confirmation
        await sock.sendMessage(chatId, { react: { text: '🧹', key: message.key } });
        await sock.sendMessage(chatId, { text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n🧹 *Purge effectuée !*\n📊 Demande : ${nb} messages\n\n> _Propulsé par 🥷 *IBSACKO™*_`, contextInfo: channelInfo }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ *Erreur :* ${e.message}`, contextInfo: channelInfo }, { quoted: message });
    }
}

// ─── ANTIPURGE ───────────────────────────────────────
async function antipurgeCommand(sock, chatId, senderId, args, message) {
    const action = args[0]?.toLowerCase();
    let state = {};
    try { state = JSON.parse(fs.readFileSync(antipurgeFile)); } catch {}
    const current = state[chatId] ? '🟢 Activé' : '🔴 Désactivé';
    if (!action) {
        return await sock.sendMessage(chatId, { text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n🛡️ *Anti-Purge :* ${current}\n\n💡 .antipurge on / off`, contextInfo: channelInfo }, { quoted: message });
    }
    state[chatId] = action === 'on';
    fs.writeFileSync(antipurgeFile, JSON.stringify(state, null, 2));
    await sock.sendMessage(chatId, { text: `🛡️ *Anti-Purge :* ${action === 'on' ? '🟢 Activé' : '🔴 Désactivé'}`, contextInfo: channelInfo }, { quoted: message });
}

// ─── SANCTION ────────────────────────────────────────
async function sanctionCommand(sock, chatId, senderId, args, message) {
    if (!chatId.endsWith('@g.us')) return await sock.sendMessage(chatId, { text: '❌ Uniquement dans les groupes !', contextInfo: channelInfo }, { quoted: message });
    const mentioned = message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
    const quotedSender = message.message?.extendedTextMessage?.contextInfo?.participant;
    const target = mentioned || quotedSender;
    const type = args[0]?.toLowerCase() || 'warn';

    if (!target) {
        return await sock.sendMessage(chatId, { text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n⚖️ *Usage :* .sanction @membre warn/mute/kick\n\n📌 *Types :*\n│ ⬡ warn → Avertissement\n│ ⬡ mute → Muter le groupe\n│ ⬡ kick → Expulser`, contextInfo: channelInfo }, { quoted: message });
    }

    const num = target.split('@')[0];
    try {
        switch(type) {
            case 'kick':
                await sock.groupParticipantsUpdate(chatId, [target], 'remove');
                await sock.sendMessage(chatId, { text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n⚖️ *Sanction : Expulsion*\n👤 @${num} a été expulsé du groupe.`, mentions: [target], contextInfo: channelInfo }, { quoted: message });
                break;
            case 'mute':
                await sock.groupSettingUpdate(chatId, 'announcement');
                await sock.sendMessage(chatId, { text: `⚖️ *Sanction : Mute*\nLe groupe a été fermé suite à un abus.\n👤 @${num}`, mentions: [target], contextInfo: channelInfo }, { quoted: message });
                break;
            default: // warn
                await sock.sendMessage(chatId, { text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n⚠️ *Avertissement*\n👤 @${num}\n\n_Respecte les règles du groupe ou tu seras expulsé._`, mentions: [target], contextInfo: channelInfo }, { quoted: message });
        }
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ *Erreur :* ${e.message}`, contextInfo: channelInfo }, { quoted: message });
    }
}

// ─── UPTIME ──────────────────────────────────────────
async function uptimeCommand(sock, chatId, message) {
    const uptime = formatUptime(Math.floor(process.uptime()));
    const ram = (process.memoryUsage().rss / 1024 / 1024).toFixed(1);
    await sock.sendMessage(chatId, {
        image: { url: BOT_IMG },
        caption: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╠═════════════════════╣\n║   ⏱️ *UPTIME BOT*          ║\n╚═════════════════════╝\n\n┌─────────────────────\n│ ⏱️ *Uptime  :* ${uptime}\n│ 💾 *RAM     :* ${ram} MB\n│ 📦 *Version :* v2.0.0\n│ ✅ *Statut  :* En ligne\n└─────────────────────\n\n> _Propulsé par 🥷 *IBSACKO™*_`,
        contextInfo: channelInfo
    }, { quoted: message });
}

// ─── TEST ─────────────────────────────────────────────
async function testCommand(sock, chatId, message) {
    const start = Date.now();
    await sock.sendMessage(chatId, { react: { text: '🧪', key: message.key } });
    const ping = Date.now() - start;
    await sock.sendMessage(chatId, {
        text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n🧪 *Test Bot*\n\n✅ *Statut :* Opérationnel\n⚡ *Ping   :* ${ping} ms\n⏱️ *Uptime :* ${formatUptime(Math.floor(process.uptime()))}\n\n> _Propulsé par 🥷 *IBSACKO™*_`,
        contextInfo: channelInfo
    }, { quoted: message });
}

// ─── INFO ─────────────────────────────────────────────
async function infoCommand(sock, chatId, message) {
    const settings = require('../settings');
    await sock.sendMessage(chatId, {
        image: { url: BOT_IMG },
        caption: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╠═════════════════════╣\n║   ℹ️ *INFO BOT*            ║\n╚═════════════════════╝\n\n┌─────────────────────\n│ 🤖 *Nom     :* ITACHI-XMD\n│ 📦 *Version :* v2.0.0\n│ 👤 *Créateur :* IBSACKO™\n│ 🌍 *Mode    :* Public\n│ ✅ *Statut  :* En ligne 24/7\n│ 🛡️ *Cmds    :* 33+ commandes\n└─────────────────────\n\n🥷 *Communauté :* CENTRAL HEX\n📢 Rejoins notre chaîne !\n\n> _Propulsé par 🥷 *IBSACKO™*_`,
        contextInfo: channelInfo
    }, { quoted: message });
}

// ─── CONTACT ──────────────────────────────────────────
async function contactCommand(sock, chatId, message) {
    const settings = require('../settings');
    const ownerNum = settings.ownerNumber || '224621963059';
    const ownerName = settings.botOwner || 'Ibrahima sory sacko';
    const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${ownerName}\nTEL;waid=${ownerNum}:+${ownerNum}\nEND:VCARD`;
    await sock.sendMessage(chatId, {
        text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n📞 *Contact du propriétaire*\n👇 Ci-dessous :`,
        contextInfo: channelInfo
    }, { quoted: message });
    await sock.sendMessage(chatId, {
        contacts: { displayName: ownerName, contacts: [{ vcard }] }
    });
}

// ─── AUTORECORDING ────────────────────────────────────
async function autorecordingCommand(sock, chatId, senderId, args, message) {
    const action = args[0]?.toLowerCase();
    if (!action) {
        return await sock.sendMessage(chatId, { text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n🎙️ *Auto Recording*\n\n💡 .autorecording on/off\n_Simule une activité "enregistrement audio"._`, contextInfo: channelInfo }, { quoted: message });
    }
    if (action === 'on') {
        await sock.sendMessage(chatId, { react: { text: '🎙️', key: message.key } });
        // Simuler recording en boucle
        const interval = setInterval(async () => {
            try { await sock.sendPresenceUpdate('recording', chatId); } catch { clearInterval(interval); }
        }, 5000);
        setTimeout(() => clearInterval(interval), 60000); // Stop après 1 minute
        await sock.sendMessage(chatId, { text: `🎙️ *Auto Recording :* 🟢 Activé (1 min)`, contextInfo: channelInfo }, { quoted: message });
    } else {
        await sock.sendMessage(chatId, { text: `🎙️ *Auto Recording :* 🔴 Désactivé`, contextInfo: channelInfo }, { quoted: message });
    }
}

// ─── RESTORE ──────────────────────────────────────────
async function restoreCommand(sock, chatId, senderId, message) {
    try {
        // Restaurer les configurations par défaut
        const defaults = {
            'data/antibot.json': {},
            'data/antimarabout.json': {},
            'data/antipurge.json': {},
            'data/antisticker.json': {},
            'data/antimention.json': {},
        };
        let restored = 0;
        for (const [file, def] of Object.entries(defaults)) {
            const fp = path.join(__dirname, '..', file);
            if (!fs.existsSync(fp)) {
                fs.writeFileSync(fp, JSON.stringify(def, null, 2));
                restored++;
            }
        }
        await sock.sendMessage(chatId, {
            text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╚═════════════════════╝\n\n✅ *Restauration effectuée*\n📁 ${restored} fichier(s) restauré(s).\n\n> _Propulsé par 🥷 *IBSACKO™*_`,
            contextInfo: channelInfo
        }, { quoted: message });
    } catch (e) {
        await sock.sendMessage(chatId, { text: `❌ *Erreur :* ${e.message}`, contextInfo: channelInfo }, { quoted: message });
    }
}

// ─── CLAN ─────────────────────────────────────────────
async function clanCommand(sock, chatId, senderId, args, message) {
    const action = args[0]?.toLowerCase();
    const clanFile = path.join(__dirname, '../data/clan.json');
    let clans = {};
    try { clans = JSON.parse(fs.readFileSync(clanFile)); } catch {}

    if (!action || action === 'list') {
        const list = Object.entries(clans).map(([n, c]) => `│ ⬡ *${n}* — ${c.members?.length || 0} membres`).join('\n') || '│ Aucun clan créé';
        return await sock.sendMessage(chatId, {
            text: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╠═════════════════════╣\n║   🏆 *CLANS*               ║\n╚═════════════════════╝\n\n📋 *Clans existants :*\n┌─────────────────────\n${list}\n└─────────────────────\n\n💡 *Commandes :*\n│ ⬡ .clan create <nom>\n│ ⬡ .clan join <nom>\n│ ⬡ .clan leave\n│ ⬡ .clan list`,
            contextInfo: channelInfo
        }, { quoted: message });
    }

    if (action === 'create') {
        const name = args.slice(1).join(' ');
        if (!name) return await sock.sendMessage(chatId, { text: `💡 *Usage :* .clan create <nom>`, contextInfo: channelInfo }, { quoted: message });
        clans[name] = { creator: senderId, members: [senderId], created: Date.now() };
        fs.writeFileSync(clanFile, JSON.stringify(clans, null, 2));
        return await sock.sendMessage(chatId, { text: `✅ *Clan "${name}" créé !*\n👤 Tu en es le fondateur.`, contextInfo: channelInfo }, { quoted: message });
    }

    if (action === 'join') {
        const name = args.slice(1).join(' ');
        if (!clans[name]) return await sock.sendMessage(chatId, { text: `❌ Clan "${name}" introuvable.`, contextInfo: channelInfo }, { quoted: message });
        if (!clans[name].members.includes(senderId)) clans[name].members.push(senderId);
        fs.writeFileSync(clanFile, JSON.stringify(clans, null, 2));
        return await sock.sendMessage(chatId, { text: `✅ Tu as rejoint le clan *"${name}"* !`, contextInfo: channelInfo }, { quoted: message });
    }

    if (action === 'leave') {
        for (const clan of Object.values(clans)) {
            clan.members = (clan.members || []).filter(m => m !== senderId);
        }
        fs.writeFileSync(clanFile, JSON.stringify(clans, null, 2));
        return await sock.sendMessage(chatId, { text: `👋 Tu as quitté ton clan.`, contextInfo: channelInfo }, { quoted: message });
    }
}

// ─── LOI ──────────────────────────────────────────────
async function loiCommand(sock, chatId, message) {
    await sock.sendMessage(chatId, {
        image: { url: BOT_IMG },
        caption: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╠═════════════════════╣\n║   📜 *RÈGLES DU GROUPE*    ║\n╚═════════════════════╝\n\n🥷────────────────🥷\n*CENTRAL HEX — RÈGLES*\n🥷────────────────🥷\n\n┌─────────────────────\n│ 1️⃣ Respecte tous les membres\n│ 2️⃣ Pas d'insultes ni de conflits\n│ 3️⃣ Pas de spam ni de pub\n│ 4️⃣ Pas de contenu +18\n│ 5️⃣ Pas de liens sans permission\n│ 6️⃣ Pas de fausses infos\n│ 7️⃣ Obéis aux admins\n│ 8️⃣ Sois actif et positif\n└─────────────────────\n\n⚠️ _Tout manquement = avertissement puis expulsion._\n\n> _Propulsé par 🥷 *IBSACKO™*_`,
        contextInfo: channelInfo
    }, { quoted: message });
}

// ─── ANTIMARABOUT ─────────────────────────────────────
async function antimaraboutCommand(sock, chatId, senderId, args, message) {
    const action = args[0]?.toLowerCase();
    let state = {};
    try { state = JSON.parse(fs.readFileSync(antimaraboutFile)); } catch {}
    const current = state[chatId] ? '🟢 Activé' : '🔴 Désactivé';

    if (!action) {
        return await sock.sendMessage(chatId, {
            image: { url: BOT_IMG },
            caption: `╔═════════════════════╗\n║   🥷 *𝗜𝗧𝗔𝗖𝗛𝗜-𝗫𝗠𝗗-𝐕2* 🥷   ║\n╠═════════════════════╣\n║ 🔮 *ANTI-MARABOUT*         ║\n╚═════════════════════╝\n\n📊 *Statut :* ${current}\n\n💡 .antimarabout on/off\n\n🛡️ Supprime automatiquement les messages\nde marabouts, arnaques et escroqueries.`,
            contextInfo: channelInfo
        }, { quoted: message });
    }

    state[chatId] = action === 'on';
    if (!state.keywords) state.keywords = ['marabout','voyant','sorcier','envoûtement','rituel','chance','argent rapide','gain garanti','résoudre problème','retour affectif','amour perdu','portefeuille magique','100%','WhatsApp +','contactez-moi'];
    fs.writeFileSync(antimaraboutFile, JSON.stringify(state, null, 2));
    await sock.sendMessage(chatId, {
        text: `🔮 *Anti-Marabout :* ${action === 'on' ? '🟢 Activé' : '🔴 Désactivé'}\n${action === 'on' ? '> _Messages suspects seront supprimés._' : '> _Protection désactivée._'}`,
        contextInfo: channelInfo
    }, { quoted: message });
}

// Handler antimarabout (appelé dans main.js)
async function handleAntimarabout(sock, chatId, senderId, message) {
    try {
        let state = {};
        try { state = JSON.parse(fs.readFileSync(antimaraboutFile)); } catch {}
        if (!state[chatId]) return false;

        const text = (
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text || ''
        ).toLowerCase();

        const keywords = state.keywords || ['marabout','voyant','sorcier','rituel','argent rapide','gain garanti','retour affectif','portefeuille magique'];
        const isSpam = keywords.some(kw => text.includes(kw.toLowerCase()));
        if (!isSpam) return false;

        await sock.sendMessage(chatId, { delete: message.key });
        console.log(`🛡️ [antimarabout] Message suspect supprimé`);
        return true;
    } catch { return false; }
}

module.exports = {
    kickallCommand, purgeCommand, antipurgeCommand, sanctionCommand,
    uptimeCmdNew: uptimeCommand, testCmdNew: testCommand, 
    infoCmdNew: infoCommand, contactCmdNew: contactCommand,
    autorecordingCommand, restoreCommand, clanCommand, loiCommand,
    antimaraboutCommand, handleAntimarabout
};
