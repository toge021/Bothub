export default async function modeCommand(message, client, { args, isOwner, config }) {
  const remoteJid = message.key.remoteJid;

  if (!isOwner) {
    return client.sendMessage(remoteJid, { text: "*❌ Only owner*" });
  }

  // Si aucune option, on affiche le mode actuel
  if (!args[0]) {
    return client.sendMessage(remoteJid, { text: `ℹ️ The current mode is: *${config.mode.toUpperCase()}*` });
  }

  const newMode = args[0].toLowerCase();
  if (newMode !== "public" && newMode !== "private") {
    return client.sendMessage(remoteJid, { text: "❌ Invalid mode! Use public or private." });
  }

  // Changer le mode directement dans le handler
  config.mode = newMode;
  client.sendMessage(remoteJid, { text: `✅ The bot's current mode is: *${newMode.toUpperCase()}*` });
}