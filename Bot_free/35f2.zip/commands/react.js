export default async function react(message, obito) {
  try {
    await obito.sendMessage(message.key.remoteJid, {
      react: { text: "🌚", key: message.key },
    });
  } catch (e) {
    console.error("Reaction error:", e);
  }
}