import {
  BotName
} from "../config.js";

export default async function pingCommand(message, client) {
  const remoteJid = message.key.remoteJid;
  const start = Date.now();

  await client.sendMessage(remoteJid, { text: "_Testinn....!_" });
  const latency = Date.now() - start;

  await client.sendMessage(remoteJid, {
    text: `*${BotName}*\n➠ 🏓 Pong!\n➠ Latence: ${latency} ms`,
  });
}