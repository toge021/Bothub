import { addPremium, getAllPremium } from "../database/premium.js";

export default async function addpremCommand(message, obito, { sender, args, isCreator }) {
  if (!isCreator) {
    return obito.sendMessage(message.key.remoteJid, {
      text: "> ❌ Only the creator can add a Premium user.",
    });
  }

  const target = args[0]?.replace(/[^0-9]/g, "");
  if (!target) {
    return obito.sendMessage(message.key.remoteJid, {
      text: "➠ ❌ Exemple : *.addprem 21307583###*",
    });
  }

  const added = addPremium(target);
  if (!added) {
    return obito.sendMessage(message.key.remoteJid, {
      text: `⚠️ The user ${target} is already a Premium user.`,

});
  }

  const allPrem = getAllPremium().length;
  await obito.sendMessage(message.key.remoteJid, {
    text: `➠ ✅ User *${target}* has adde. Premium\n➠ Total Premium: ${allPrem}`,
  });
}