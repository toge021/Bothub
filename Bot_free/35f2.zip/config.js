// === BOT INFO ===
export const BotName = "『🩸⃟‣FREE BOT SCRIPT』";
export const BotVersion = "1.0.0";
export const OwnerName = "🝛꯭𝐈𝛕ᷟ𝚣⃪ꙴ𝖺َᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝ᡃ⃝𝐍𝚯𝐗";

// === NUMBERS ===
export const OwnerNumber = "213553263576";
export const CreatorNumber = "213553263576";

// === PREFIX ===
export const Prefix = "!";

// === MODE ===
export const Mode = "public"; // public / private

// === MEDIA ===
export const MenuImage = "bot.png";
export const MenuAudio = "you-audio.mp3";

// === OPTIONS ===
export const AutoReact = true;
export const AutoRead = true;

// === LIENS AUTOFOLLOWERS ===
export const AutofollowNewletter = "120363427203053772@newsletter",
export const SupportGroup = "https://chat.whatsapp.com/F29k1q77NVj28Fh6ADovyN?s=cl&p=a&ilr=2";

// === FOOTER / SIGNATURE ===
export const Footer = "©𝐌ꝛ⥔𝐍𝚯𝐗⥕𝚸𝚪𝚰𝚳𝚵𝚵𝚵𝚵 𝚯𝐅𝐅𝚰𝐂𝐈𝚫𝐋"
};