const fs = require("fs-extra");
const path = require("path");

module.exports = {
    name: "setfont",
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const fontIndex = parseInt(args[0]);
        
        const fonts = [
            "1-𝖆𝖑𝖕𝖍𝖆 𝖇𝖔𝖙 — Gothic / Blackletter",
            "2-𝐚𝐥𝐩𝐡𝐚 𝐛𝐨𝐭 — Bold (gras classique)",
            "3-𝗮𝗹𝗽𝗵𝗮 𝗯𝗼𝘁 — Sans-serif bold moderne",
            "4-𝘢𝘭𝘱𝘩𝘢 𝘣𝘰𝘵 — Italic stylé",
            "5-𝙖𝙡𝙥𝙝𝙖 𝙗𝙤𝙩 — Monospace (style code)",
            "6-𝑎𝑙𝑝ℎ𝑎 𝑏𝑜𝑡 — Math italic (élégant)",
            "7-𝓪𝓵𝓹𝓱𝓪 𝓫𝓸𝓽 — Script (écriture manuscrite)",
            "8-𝔞𝔩𝔭𝔥𝔞 𝔟𝔬𝔱 — Fraktur (ancien style gothique)",
            "9-ᴀʟᴘʜᴀ ʙᴏᴛ — Petites capitales (small caps)",
            "10-ａｌｐｈａ ｂｏｔ — Full width (style japonais/space large)"
        ];

        if (!fontIndex || fontIndex < 1 || fontIndex > 10) {
            let list = "🎨 *CHOISISSEZ VOTRE POLICE* 🎨\n\nUtilisez *.setfont (chiffre)* pour changer.\n\n";
            fonts.forEach(f => list += `➤ ${f}\n`);
            return sock.sendCustom(from, { text: list });
        }

        const configPath = path.join(__dirname, "../env/config.json");
        let config = {};
        if (fs.existsSync(configPath)) {
            config = fs.readJsonSync(configPath);
        }
        config.selectedFont = fontIndex;
        fs.writeJsonSync(configPath, config, { spaces: 4 });

        await sock.sendCustom(from, { text: `✅ Police n°${fontIndex} sélectionnée avec succès !\n\n${fonts[fontIndex-1]}` });
    }
};
