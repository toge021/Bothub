module.exports = {
    name: 'restart',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendMessage(from, { text: "Redémarrage du bot en cours... 🔄" }, { quoted: m });
        process.exit(0);
    }
};
