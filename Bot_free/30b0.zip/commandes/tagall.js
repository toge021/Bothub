const fs = require("fs");
const path = require("path");

module.exports = {
    name: 'tagall',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        try {
            if (!from.endsWith("@g.us")) {
                return sock.sendCustom(from, {
                    text: "⚠️ Cette commande est réservée aux groupes."
                });
            }

            const metadata = await sock.groupMetadata(from).catch(() => null);

            if (!metadata) {
                return sock.sendCustom(from, {
                    text: "❌ Impossible de récupérer les infos du groupe."
                });
            }

            const participants = metadata.participants || [];

            if (!participants.length) {
                return sock.sendCustom(from, {
                    text: "❌ Aucun membre trouvé."
                });
            }

            const message = args.join(" ") || "📢 Appel général !";

            let mentions = [];
            let list = "";

            for (let p of participants) {
                if (!p?.id) continue;
                mentions.push(p.id);
                list += `┃ ➤ @${p.id.split("@")[0]}\n`;
            }

            // ✅ TON CHEMIN FIXÉ ICI
            const imgPath = path.join(__dirname, "../images/thumb.jpg");

            if (!fs.existsSync(imgPath)) {
                return sock.sendCustom(from, {
                    text: "❌ Image introuvable : images/thumb.jpg"
                });
            }

            const image = fs.readFileSync(imgPath);

            const caption = `╭━━━〔 📢 MCKINGER X VOID 〕━━━╮
┃
┃ ✦ GROUPE : ${metadata.subject}
┃ ✦ MESSAGE : ${message}
┃ ✦ MEMBRES : ${participants.length}
┃
${list}┃
╰━━━〔 ⚡ VOID SYSTEM 〕━━━╯`;

            await sock.sendMessage(from, {
                image,
                caption,
                mentions
            }, { quoted: m });

        } catch (e) {
            console.log("TAGALL ERROR:", e);

            await sock.sendCustom(from, {
                text: "❌ ᴇʀʀᴇᴜʀ ᴛᴀɢᴀʟʟ."
            });
        }
    }
};