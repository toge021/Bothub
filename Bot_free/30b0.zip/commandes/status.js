module.exports = {
    name: 'status',

    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        const uptime = process.uptime();
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);

        const statusMsg = `
> \`𝙼𝙲𝙺𝙸𝙽𝙶𝙴𝚁 • 𝚇 𝚅𝙾𝙸𝙳 𝚂𝚃𝙰𝚃𝚄𝚂\`

✧ ━━━━━━━━━━━━━━━━━ ✧
> 𝚂𝚈𝚂𝚃𝙴𝙼 𝙸𝙽𝙵𝙾 🌹

╭━━━━━━━━━━━━━━━╮
┃ 🤖 𝙱𝙾𝚃 : 𝙾𝙽𝙻𝙸𝙽𝙴
┃ ⚡ 𝚂𝚃𝙰𝚃𝚄𝚂 : 𝙰𝙲𝚃𝙸𝚅𝙴
┃ ⏱️ 𝚄𝙿𝚃𝙸𝙼𝙴 : ${hours}h ${minutes}m ${seconds}s
╰━━━━━━━━━━━━━━━╯

📊 𝚂𝚈𝚂𝚃𝙴𝙼
• Core : Stable
• Engine : Running
• Memory : Optimal

✧ ━━━━━━━━━━━━━━━━━ ✧

"I'm perfect in every way 🫴🍷"

✧ ━━━━━━━━━━━━━━━━━ ✧
> 𝙿𝙾𝚆𝙴𝚁𝙴𝙳 𝙱𝚈 𝙼𝙲𝙺𝙸𝙽𝙶𝙴𝚁 𝚇 𝚅𝙾𝙸𝙳
`;

        await sock.sendCustom(from, {
            text: statusMsg
        }, { quoted: m });
    }
};