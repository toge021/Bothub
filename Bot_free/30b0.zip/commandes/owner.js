module.exports = {
    name: 'owner',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n' 
            + 'FN:MCKINGER\n'
            + 'ORG:MCKINGER-XMD;\n'
            + 'TEL;type=CELL;type=VOICE;waid=22896985431:+228 96 98 54 31\n'
            + 'END:VCARD';
        await sock.sendMessage(from, { 
            contacts: { 
                displayName: 'MCKINGER', 
                contacts: [{ vcard }] 
            }
        }, { quoted: m });
    }
};
