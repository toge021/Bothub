const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'antiadd',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        if (!from.endsWith('@g.us')) return sock.sendCustom(from, { text: "Cette commande est réservée aux groupes." });
        
        const configPath = path.join(__dirname, '../env/config.json');
        let config = fs.existsSync(configPath) ? fs.readJsonSync(configPath) : {};
        if (!config.antiadd) config.antiadd = {};

        const action = args[0] ? args[0].toLowerCase() : '';
        if (action === 'on') {
            config.antiadd[from] = true;
            fs.writeJsonSync(configPath, config);
            sock.sendCustom(from, { text: "✅ *Anti-Add* activé pour ce groupe." });
        } else if (action === 'off') {
            config.antiadd[from] = false;
            fs.writeJsonSync(configPath, config);
            sock.sendCustom(from, { text: "❌ *Anti-Add* désactivé pour ce groupe." });
        } else {
            sock.sendCustom(from, { text: "Utilisation : .antiadd on/off" });
        }
    }
};
