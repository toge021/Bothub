const { Sticker, StickerTypes } = require('wa-sticker-formatter');
const { downloadContentFromMessage } = require('@whiskeysockets/baileys');

module.exports = {
    name: 'sticker',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const quoted = m.message.extendedTextMessage?.contextInfo?.quotedMessage || m.message;
        const mime = (quoted.imageMessage || quoted.videoMessage || quoted.viewOnceMessageV2?.message?.imageMessage || quoted.viewOnceMessageV2?.message?.videoMessage)?.mimetype || '';

        if (!/image|video/.test(mime)) return sock.sendCustom(from, { text: "Répondez à une image ou une vidéo pour créer un sticker." });

        try {
            const messageType = quoted.imageMessage ? 'image' : 'video';
            const stream = await downloadContentFromMessage(quoted.imageMessage || quoted.videoMessage || quoted.viewOnceMessageV2?.message?.imageMessage || quoted.viewOnceMessageV2?.message?.videoMessage, messageType);
            let buffer = Buffer.from([]);
            for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

            const sticker = new Sticker(buffer, {
                pack: 'MCKINGER XMD',
                author: 'Mikey',
                type: StickerTypes.FULL,
                categories: ['🤩', '🎉'],
                id: '12345',
                quality: 50,
            });

            const stickerBuffer = await sticker.toBuffer();
            await sock.sendMessage(from, { sticker: stickerBuffer }, { quoted: m });
        } catch (e) {
            sock.sendCustom(from, { text: "Erreur lors de la création du sticker : " + e.message });
        }
    }
};