module.exports = {
    name: 'exec',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *exec* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
