const fs = require('fs');
const path = require('path');
module.exports = {
    name: 'menu',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const imagePath = path.join(__dirname, '../images/menu.jpg');
        const menuText = `━━━━━━━━━━━━━━━╮
👑 𝑀𝐶𝐾𝐼𝑁𝐺𝐸𝑅 X 𝑉𝑂𝐼𝑅 🤴
╰━━━━━━━━━━━━━━━╯
╭───────────────╮
│ 📢 OFFICIAL LINKS
╰───────────────╯
┃ 👑 Owner : wa.me/22896985431
┃ 🌐 Communauté : chat.whatsapp.com/JlDCtzemMKgF8O300JGWor
┃ 📺 Chaîne : whatsapp.com/channel/0029Vb6tl8K2f3EPZquxE92s
╰────────────────────────╯

╭───〔 ⚙️ SYSTEM CORE 〕───╮
┃ ➤ .menu
┃ ➤ .help
┃ ➤ .alive
┃ ➤ .ping
┃ ➤ .runtime
┃ ➤ .botinfo
┃ ➤ .owner
┃ ➤ .speed
┃ ➤ .uptime
┃ ➤ .status
┃ ➤ .repo
┃ ➤ .getbot
╰────────────────────────╯

╭───〔 👥 GROUP CONTROL 〕───╮
┃ ➤ .kick @user
┃ ➤ .kickall 💀
┃ ➤ .add 228XXXXXXXX
┃ ➤ .promote @user
┃ ➤ .demote @user
┃ ➤ .tagall
┃ ➤ .hidetag message
┃ ➤ .group open/close
┃ ➤ .mute / .unmute
┃ ➤ .link
┃ ➤ .revoke
┃ ➤ .welcome on/off
┃ ➤ .goodbye on/off
┃ ➤ .setname
┃ ➤ .setdesc
╰────────────────────────╯

╭───〔 📡 GLOBAL ACTIONS 〕───╮
┃ ➤ .broadcast message
┃ ➤ .bcgroup message
┃ ➤ .bcpm message
┃ ➤ .mentionall
┃ ➤ .forward
┃ ➤ .copy
┃ ➤ .quote
┃ ➤ .sendall
┃ ➤ .alladmin
┃ ➤ .everyone
╰────────────────────────╯

╭───〔 🛡️ SECURITY WALL 〕───╮
┃ ➤ .antilink on/off
┃ ➤ .antispam on/off
┃ ➤ .antibot on/off
┃ ➤ .antiadd on/off
┃ ➤ .antifake on/off
┃ ➤ .warn @user
┃ ➤ .warnings @user
┃ ➤ .resetwarn
┃ ➤ .lock / .unlock
╰────────────────────────╯

╭───〔 🎭 ENTERTAINMENT 〕───╮
┃ ➤ .joke 😂
┃ ➤ .quote 📜
┃ ➤ .fact
┃ ➤ .meme
┃ ➤ .dice 🎲
┃ ➤ .roll
┃ ➤ .ship ❤️
┃ ➤ .pp
┃ ➤ .truth
┃ ➤ .dare
╰────────────────────────╯

╭───〔 🎬 MEDIA MODULE 〕───╮
┃ ➤ .sticker
┃ ➤ .toimg
┃ ➤ .play 🎧
┃ ➤ .yt 🎥
┃ ➤ .lyrics
┃ ➤ .audio
┃ ➤ .video
┃ ➤ .tiktok
┃ ➤ .instagram
┃ ➤ .song
┃ ➤ .vv
╰────────────────────────╯

╭───〔 🤖 AI / SMART 〕───╮
┃ ➤ .ai
┃ ➤ .chat
┃ ➤ .gpt
┃ ➤ .ask
┃ ➤ .define
┃ ➤ .translate
┃ ➤ .summarize
┃ ➤ .rephrase
┃ ➤ .otp
╰────────────────────────╯

╭───〔 🎮 GAMES / FUN 〕───╮
┃ ➤ .game
┃ ➤ .quiz
┃ ➤ .math
┃ ➤ .tictactoe
┃ ➤ .guess
┃ ➤ .leaderboard
┃ ➤ .daily
╰────────────────────────╯

╭───〔 ⚡ SYSTEM OPS 〕───╮
┃ ➤ .restart
┃ ➤ .shutdown
┃ ➤ .backup
┃ ➤ .restore
┃ ➤ .clearchat
┃ ➤ .update
┃ ➤ .exec
┃ ➤ .setprefix
┃ ➤ .setfont
╰───────────────
╭━━━━━━━━━━━━━━━╮
👑 Powered by MCKINGER
╰━━━━━━━━━━━━━━━╯`;
        if (fs.existsSync(imagePath)) {
            await sock.sendCustom(from, { image: fs.readFileSync(imagePath), caption: menuText });
        } else {
            await sock.sendCustom(from, { text: menuText });
        }
    }
};
