module.exports = {
    name: 'antilink',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *antilink* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
