const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'setprefix',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const newPrefix = args[0];

        if (!newPrefix) {
            return sock.sendCustom(from, { text: "⚠️ Veuillez fournir un nouveau préfixe.\nExemple: .setprefix !" });
        }

        const configPath = path.join(__dirname, '../env/config.json');
        let config = {};
        if (fs.existsSync(configPath)) {
            config = fs.readJsonSync(configPath);
        }
        
        config.prefix = newPrefix;
        fs.writeJsonSync(configPath, config);

        await sock.sendCustom(from, { text: `✅ Préfixe modifié avec succès !\nNouveau préfixe : *${newPrefix}*` });
    }
};