const os = require("os");

module.exports = {
    name: 'ping',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        try {
            const start = Date.now();

            const latency = Date.now() - start;

            // ⏱️ UPTIME
            const uptime = process.uptime();
            const h = Math.floor(uptime / 3600);
            const mnt = Math.floor((uptime % 3600) / 60);
            const s = Math.floor(uptime % 60);

            // 💾 RAM
            const used = process.memoryUsage().heapUsed / 1024 / 1024;
            const total = os.totalmem() / 1024 / 1024;

            // 🧠 CPU
            const cpu = os.loadavg()[0].toFixed(2);

            const caption = `╭━━━〔 ⚡ MCKINGER X VOID 〕━━━╮
┃
┃ ✓ STATUT SYSTÈME
┃
┃ 📡 LATENCE : ${latency} ms
┃ ⏱️ UPTIME : ${h}h ${mnt}m ${s}s
┃ 💾 RAM : ${used.toFixed(2)} / ${total.toFixed(0)} MB
┃ 🧠 CPU : ${cpu} %
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`;

            await sock.sendMessage(from, {
                image: { url: "https://i.ibb.co/HT7PmxNz/97f1bd582d4c.jpg" },
                caption: caption,
                contextInfo: {
                    externalAdReply: {
                        title: "Rejoins notre chaîne WhatsApp",
                        body: "👑 MCKINGER X VOID",
                        thumbnailUrl: "https://i.ibb.co/HT7PmxNz/97f1bd582d4c.jpg",
                        sourceUrl: "https://whatsapp.com/channel/0029Vb6tl8K2f3EPZquxE92s",
                        mediaType: 1,
                        renderLargerThumbnail: false // 👈 petit preview
                    }
                }
            }, { quoted: m });

        } catch (e) {
            console.log("PING ERROR:", e);

            await sock.sendCustom(from, {
                text: "❌ Erreur système."
            });
        }
    }
};