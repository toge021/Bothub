const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'antifake',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        if (!from.endsWith('@g.us')) return sock.sendCustom(from, { text: "Cette commande est réservée aux groupes." });
        
        const configPath = path.join(__dirname, '../env/config.json');
        let config = fs.existsSync(configPath) ? fs.readJsonSync(configPath) : {};
        if (!config.antifake) config.antifake = {};

        const action = args[0] ? args[0].toLowerCase() : '';
        if (action === 'on') {
            config.antifake[from] = true;
            fs.writeJsonSync(configPath, config);
            sock.sendCustom(from, { text: "✅ *Anti-Fake* activé pour ce groupe." });
        } else if (action === 'off') {
            config.antifake[from] = false;
            fs.writeJsonSync(configPath, config);
            sock.sendCustom(from, { text: "❌ *Anti-Fake* désactivé pour ce groupe." });
        } else {
            sock.sendCustom(from, { text: "Utilisation : .antifake on/off" });
        }
    }
};
