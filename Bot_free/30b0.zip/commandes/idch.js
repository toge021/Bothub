module.exports = {
    name: "idch",
    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        try {
            let channelId = null;

            // 📌 1. Si dans une chaîne directement
            if (from.endsWith("@newsletter")) {
                channelId = from;
            }

            // 📌 2. Si réponse à un message de chaîne
            else {
                const ctx = m.message?.extendedTextMessage?.contextInfo;

                channelId =
                    ctx?.newsletterMessageInfo?.newsletterJid ||
                    ctx?.quotedMessage?.newsletterMessageInfo?.newsletterJid ||
                    null;
            }

            // ❌ Ignore les faux IDs (genre 0029...)
            if (!channelId || !channelId.endsWith("@newsletter")) {
                return sock.sendCustom(from, {
                    text: `╭━━━〔 📢 MCKINGER X VOID 〕━━━╮
┃
┃ ❌ ID CHAÎNE INTROUVABLE
┃
┃ ⚠️ Réponds à un message d’une chaîne
┃ ou utilise la commande dans une chaîne
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
                });
            }

            // 💎 DESIGN CLEAN (ALIGNÉ)
            await sock.sendCustom(from, {
                text: `╭━━━〔 📢 MCKINGER X VOID 〕━━━╮
┃
┃ ✓ ID CHAÎNE RÉCUPÉRÉ
┃
┃ ID : ${channelId}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
            });

        } catch (e) {
            console.log("IDCH ERROR:", e);

            await sock.sendCustom(from, {
                text: `╭━━━〔 💀 MCKINGER X VOID 〕━━━╮
┃
┃ ❌ ERREUR RÉCUPÉRATION
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
            });
        }
    }
};