const { default: makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, delay } = require("@whiskeysockets/baileys");
const pino = require("pino");
const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'pair',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const phoneNumber = args[0]?.replace(/[^0-9]/g, '');

        if (!phoneNumber) {
            return sock.sendCustom(from, { 
                text: "💡 Utilisez *.pair [numéro]* pour ouvrir une nouvelle session.\nExemple: *.pair 22896985431*" 
            });
        }

        await sock.sendCustom(from, { text: `⏳ Génération du code de couplage pour : ${phoneNumber}...` });

        try {
            // Création d'un dossier temporaire pour la nouvelle session
            const sessionID = `session_${Date.now()}`;
            const sessionPath = path.join(__dirname, `../temp_sessions/${sessionID}`);
            const { state, saveCreds } = await useMultiFileAuthState(sessionPath);
            const { version } = await fetchLatestBaileysVersion();

            const newSock = makeWASocket({
                version,
                logger: pino({ level: "silent" }),
                printQRInTerminal: false,
                auth: state,
                browser: ["Ubuntu", "Chrome", "20.0.04"]
            });

            if (!newSock.authState.creds.registered) {
                await delay(3000);
                let code = await newSock.requestPairingCode(phoneNumber);
                
                const responseText = `━━━━━━━━━━━━━━━━━━━━━━\n👑 *MCKINGER XMD PAIRING*\n━━━━━━━━━━━━━━━━━━━━━━\n\n✅ Code : *${code}*\n\nEntrez ce code sur le WhatsApp du numéro ${phoneNumber}.\n\n〔 🚀 MCKINGER XMD SYSTEM 〕`;
                
                await sock.sendCustom(from, { text: responseText });
            }

            // On garde la session en attente de connexion pendant un temps
            setTimeout(async () => {
                try {
                    if (fs.existsSync(sessionPath)) {
                        // On ne supprime pas si c'est connecté, mais ici c'est juste pour le code
                        // Dans un vrai système katabump, ces sessions seraient gérées par un manager
                    }
                } catch (e) {}
            }, 1000 * 60 * 5); // 5 minutes

        } catch (e) {
            await sock.sendCustom(from, { text: `❌ Erreur lors de la génération du code : ${e.message}` });
        }
    }
};
