const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'resetwarn',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        if (!from.endsWith('@g.us')) return sock.sendCustom(from, { text: "Cette commande est réservée aux groupes." });
        
        const sender = m.key.participant || m.key.remoteJid;
        const metadata = await sock.groupMetadata(from);
        const admins = metadata.participants.filter(v => v.admin !== null).map(v => v.id);
        const isAdmins = admins.includes(sender);
        if (!isAdmins) return sock.sendCustom(from, { text: "❌ Cette commande est réservée aux administrateurs." });

        let user = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
        if (!user && m.message.extendedTextMessage?.contextInfo?.quotedMessage) {
            user = m.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!user) return sock.sendCustom(from, { text: "Veuillez mentionner un utilisateur ou répondre à son message." });

        const configPath = path.join(__dirname, '../env/config.json');
        let config = fs.existsSync(configPath) ? fs.readJsonSync(configPath) : {};
        if (config.warns && config.warns[from] && config.warns[from][user]) {
            delete config.warns[from][user];
            fs.writeJsonSync(configPath, config);
            await sock.sendCustom(from, { text: `✅ Avertissements réinitialisés pour @${user.split('@')[0]}.`, mentions: [user] });
        } else {
            await sock.sendCustom(from, { text: `❌ Cet utilisateur n'a aucun avertissement.` });
        }
    }
};
