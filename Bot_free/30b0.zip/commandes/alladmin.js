module.exports = {
    name: 'alladmin',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *alladmin* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
