module.exports = {
    name: 'rephrase',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *rephrase* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
