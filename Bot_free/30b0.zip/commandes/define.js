module.exports = {
    name: 'define',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *define* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
