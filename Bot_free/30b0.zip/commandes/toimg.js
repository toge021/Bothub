const { downloadContentFromMessage } = require('@whiskeysockets/baileys');
const fs = require('fs-extra');

module.exports = {
    name: 'toimg',

    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        const context = m.message?.extendedTextMessage?.contextInfo;
        const quoted = context?.quotedMessage?.stickerMessage;

        if (!quoted) {
            return sock.sendCustom(from, {
                text: `🚫 Réponds à un *sticker NON animé* pour convertir.`
            });
        }

        try {
            // 📥 download sticker
            const stream = await downloadContentFromMessage(quoted, 'sticker');

            let buffer = Buffer.from([]);
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            const user = m.key.participant || m.key.remoteJid;
            const date = new Date().toLocaleDateString();

            // 💀 SEND IMAGE WITH VOID DESIGN
            await sock.sendMessage(from, {
                image: buffer,
                caption: `
> \`𝙼𝙲𝙺𝙸𝙽𝙶𝙴𝚁 • 𝚇 𝚅𝙾𝙸𝙳 𝚃𝙾𝙸𝙼𝙶\`

✧ ━━━━━━━━━━━━━━━━━ ✧
> 𝙲𝙾𝙽𝚅𝙴𝚁𝚂𝙸𝙾𝙽 𝙲𝙾𝙼𝙿𝙻𝙴𝚃𝙴 🌹

╭━━━━━━━━━━━━━━━╮
┃ 🖼️ 𝚂𝚃𝙰𝚃𝚄𝚃 : 𝚂𝚄𝙲𝙲𝙴𝚂𝚂
┃ ⚡ 𝙼𝙾𝙳𝙴 : 𝚂𝚃𝙸𝙲𝙺𝙴𝚁 ➜ 𝙸𝙼𝙰𝙶𝙴
┃ 👤 𝚄𝚂𝙴𝚁 : @${user.split("@")[0]}
┃ 📅 𝙳𝙰𝚃𝙴 : ${date}
╰━━━━━━━━━━━━━━━╯

📌 𝚂𝚈𝚂𝚃𝙴𝙼 𝚅𝙾𝙸𝙳
• Conversion réussie
• Render optimisé
• Qualité stable

✧ ━━━━━━━━━━━━━━━━━ ✧

"I'm perfect in every way 🫴🍷"

✧ ━━━━━━━━━━━━━━━━━ ✧
> 𝙿𝙾𝚆𝙴𝚁𝙴𝙳 𝙱𝚈 𝙼𝙲𝙺𝙸𝙽𝙶𝙴𝚁 𝚇 𝚅𝙾𝙸𝙳
                `
            }, { quoted: m });

        } catch (e) {
            console.log(e);
            sock.sendCustom(from, {
                text: `❌ Erreur conversion sticker → image`
            });
        }
    }
};