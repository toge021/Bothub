const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'warnings',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        if (!from.endsWith('@g.us')) return sock.sendCustom(from, { text: "Cette commande est réservée aux groupes." });
        
        let user = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
        if (!user && m.message.extendedTextMessage?.contextInfo?.quotedMessage) {
            user = m.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!user) return sock.sendCustom(from, { text: "Veuillez mentionner un utilisateur ou répondre à son message." });

        const configPath = path.join(__dirname, '../env/config.json');
        let config = fs.existsSync(configPath) ? fs.readJsonSync(configPath) : {};
        const count = (config.warns && config.warns[from] && config.warns[from][user]) || 0;

        await sock.sendCustom(from, { text: `📊 *Statut des avertissements :*\n👤 Utilisateur : @${user.split('@')[0]}\n⚠️ Avertissements : ${count}/3`, mentions: [user] });
    }
};
