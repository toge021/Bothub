module.exports = {
    name: 'clearchat',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *clearchat* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
