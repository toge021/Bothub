module.exports = {
    name: "getpp",
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");

        try {
            let target;

            const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid;

            // 🎯 Détection cible
            if (isGroup && mentioned && mentioned.length > 0) {
                target = mentioned[0];
            } else if (args[0]) {
                let number = args[0].replace(/[^0-9]/g, "");
                target = number + "@s.whatsapp.net";
            } else if (!isGroup) {
                target = from;
            }

            if (!target) {
                return await sock.sendCustom(from, {
                    text: `╭───〔 ❌ MCKINGER X VOID 〕───⬣
│
│ ✖️ Utilisation incorrecte
│
│ ➤ getpp @user
│ ➤ getpp 228XXXXXXXX
│ ➤ ou utilise en privé
│
╰────────────────⬣`
                });
            }

            // 📸 Récupération PP
            const ppUrl = await sock.profilePictureUrl(target, "image")
                .catch(() => null);

            const username = target.split("@")[0];

            if (ppUrl) {
                await sock.sendCustom(from, {
                    image: { url: ppUrl },
                    caption: `╭───〔 👤 MCKINGER X VOID 〕───⬣
│
│ ✦ UTILISATEUR : @${username}
│ ✦ STATUS : PHOTO TROUVÉE ✅
│
│ ✧ pp de @${username} récupérée avec succès 🫴🍷
│
╰────────────────⬣`,
                    mentions: [target]
                });
            } else {
                await sock.sendCustom(from, {
                    text: `╭───〔 ⚠️ MCKINGER X VOID 〕───⬣
│
│ ✦ UTILISATEUR : @${username}
│ ✦ STATUS : INTROUVABLE ❌
│
│ ✧ La photo est privée ou inexistante
│
╰────────────────⬣`,
                    mentions: [target]
                });
            }

        } catch (e) {
            console.error("Erreur getpp :", e);
            await sock.sendCustom(from, {
                text: `╭───〔 💀 MCKINGER X VOID 〕───⬣
│
│ ✖️ Une erreur est survenue
│ ✧ Réessaie plus tard
│
╰────────────────⬣`
            });
        }
    },
};