module.exports = {
    name: 'demote',

    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        if (!from.endsWith('@g.us')) {
            return sock.sendCustom(from, {
                text: "⚠️ Cette commande est réservée aux groupes."
            });
        }

        let users = [];

        // 📌 mentions
        const mentioned = m.message?.extendedTextMessage?.contextInfo?.mentionedJid;
        if (mentioned && mentioned.length) users.push(...mentioned);

        // 📌 reply
        const quoted = m.message?.extendedTextMessage?.contextInfo?.participant;
        if (quoted) users.push(quoted);

        users = [...new Set(users)];

        if (users.length === 0) {
            return sock.sendCustom(from, {
                text: "🫴 𝐌𝐜𝐤𝐢𝐧𝐠𝐞𝐫 × 𝐕𝐨𝐢𝐝\n\n👉 Mentionne ou répond à un admin à destituer."
            });
        }

        try {
            await sock.groupParticipantsUpdate(from, users, "demote");

            return sock.sendCustom(from, {
                text:
`╭━━━〔 🫴 𝐌𝐂𝐊𝐈𝐍𝐆𝐄𝐑 × 𝐕𝐎𝐈𝐃 〕━━━╮
┃
┃ ⚔️ 𝐃𝐄𝐌𝐎𝐓𝐈𝐎𝐍 𝐑𝐄́𝐔𝐒𝐒𝐈𝐄
┃
┃ 👤 Statut : ADMIN ➜ MEMBRE
┃ 🔻 Action exécutée avec succès
┃
┃ 🍷 “I'm perfect in every way 🫴🍷
”
┃
╰━━━━━━━━━━━━━━━━━━━━╯`
            });

        } catch (e) {
            console.log(e);

            return sock.sendCustom(from, {
                text:
`╭━━━〔 🫴 𝐌𝐂𝐊𝐈𝐍𝐆𝐄𝐑 × 𝐕𝐎𝐈𝐃 〕━━━╮
┃
┃ ❌ 𝐄𝐑𝐑𝐄𝐔𝐑 𝐃𝐄 𝐃𝐄𝐌𝐎𝐓𝐈𝐎𝐍
┃
┃ ⚠️ Action impossible
┃
╰━━━━━━━━━━━━━━━━━━━━╯`
            });
        }
    }
};