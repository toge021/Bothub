module.exports = {
    name: 'botinfo',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const info = `🤖 *INFOS DU BOT* 🤖\n\n➤ *Nom* : MCKINGER XMD\n➤ *Version* : 1.0.0\n➤ *Plateforme* : Node.js\n➤ *Bibliothèque* : Baileys\n➤ *Mode* : Public\n➤ *Créateur* : MCKINGER`;
        sock.sendMessage(from, { text: info }, { quoted: m });
    }
};
