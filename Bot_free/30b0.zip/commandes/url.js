const axios = require('axios')
const FormData = require('form-data')
const { downloadContentFromMessage } = require('@whiskeysockets/baileys')
const fs = require('fs')
const path = require('path')

module.exports = {
    name: 'url',
    async execute(sock, m, args) {
        const from = m.key.remoteJid
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage

        if (!quoted || !quoted.imageMessage) {
            return sock.sendMessage(from, {
                text: "⚠️ Réponds à une image."
            }, { quoted: m })
        }

        await sock.sendMessage(from, {
            text: "⏳ Upload en cours..."
        }, { quoted: m })

        try {
            // 📥 Télécharger image WhatsApp
            const stream = await downloadContentFromMessage(quoted.imageMessage, 'image')

            let buffer = Buffer.from([])
            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk])
            }

            // 🔑 API KEY
            const apiKey = process.env.IMGBB_KEY
            if (!apiKey) {
                return sock.sendMessage(from, {
                    text: "❌ IMGBB_KEY manquante dans .env"
                }, { quoted: m })
            }

            // 📤 Upload ImgBB
            const form = new FormData()
            form.append("image", buffer.toString("base64"))

            const res = await axios.post(
                `https://api.imgbb.com/1/upload?key=${apiKey}`,
                form,
                { headers: form.getHeaders() }
            )

            const url = res.data.data.url

            // 🖼️ thumbnail stylé (ton logo)
            let thumb = null
            const thumbPath = path.resolve('thumb.jpg')
            if (fs.existsSync(thumbPath)) {
                thumb.jpg = fs.readFileSync(thumbPath)
            }

            // 💎 MESSAGE PREMIUM STYLE
            await sock.sendMessage(from, {
                text: `👑 MCKINGER X VOID UPLOADER\n\n✅ Image uploadée avec succès\n🔗 Lien : ${url}\n\n🫴🍷 Signature MCKINGER`,
                contextInfo: {
                    externalAdReply: {
                        title: "🔗 Image Uploadée",
                        body: "_Clique pour accéder au lien_🫴🍷",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: thumb,
                        sourceUrl: url,
                        mediaUrl: url
                    }
                }
            }, { quoted: m })

        } catch (e) {
            console.error(e)
            await sock.sendMessage(from, {
                text: "❌ Erreur lors de l'upload."
            }, { quoted: m })
        }
    }
}