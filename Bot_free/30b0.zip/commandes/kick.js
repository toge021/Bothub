module.exports = {
    name: 'kick',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        try {
            if (!from.endsWith('@g.us')) {
                return sock.sendCustom(from, {
                    text: "⚠️ Groupe uniquement."
                });
            }

            let users = [];

            const ctx = m.message?.extendedTextMessage?.contextInfo;

            // 📌 mention
            if (ctx?.mentionedJid) {
                users.push(...ctx.mentionedJid);
            }

            // 📌 reply
            if (ctx?.participant) {
                users.push(ctx.participant);
            }

            if (users.length === 0) {
                return sock.sendCustom(from, {
                    text: "⚠️ Mentionne ou répond à un utilisateur."
                });
            }

            // 🔥 SUPPRESSION
            const res = await sock.groupParticipantsUpdate(
                from,
                users,
                "remove"
            );

            console.log("KICK RESULT:", res);

            await sock.sendMessage(from, {
                text: `╭━━━〔 💀 MCKINGER X VOID 〕━━━╮
┃
┃ ✓ UTILISATEUR EXCLU
┃
┃ 👤 ${users.map(u => "@" + u.split("@")[0]).join("\n┃ 👤 ")}
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`,
                mentions: users,

                contextInfo: {
                    externalAdReply: {
                        title: "Lève le camp noob 🫴🍷",
                        body: "👑 MCKINGER X VOID",
                        thumbnailUrl: "https://i.ibb.co/HT7PmxNz/97f1bd582d4c.jpg",
                        sourceUrl: "https://whatsapp.com/channel/0029Vb6tl8K2f3EPZquxE92s",
                        mediaType: 1,
                        renderLargerThumbnail: false // 👈 PETIT
                    }
                }

            }, { quoted: m });

        } catch (e) {
            console.log("KICK ERROR:", e);

            await sock.sendCustom(from, {
                text: `❌ Échec du kick :
${e.message}`
            });
        }
    }
};