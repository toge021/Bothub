const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'warn',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        if (!from.endsWith('@g.us')) return sock.sendCustom(from, { text: "Cette commande est réservée aux groupes." });
        
        const sender = m.key.participant || m.key.remoteJid;
        const metadata = await sock.groupMetadata(from);
        const admins = metadata.participants.filter(v => v.admin !== null).map(v => v.id);
        const isAdmins = admins.includes(sender);
        if (!isAdmins) return sock.sendCustom(from, { text: "❌ Cette commande est réservée aux administrateurs." });

        let user = m.message.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || m.message.extendedTextMessage?.contextInfo?.participant;
        if (!user && m.message.extendedTextMessage?.contextInfo?.quotedMessage) {
            user = m.message.extendedTextMessage.contextInfo.participant;
        }
        
        if (!user) return sock.sendCustom(from, { text: "Veuillez mentionner un utilisateur ou répondre à son message." });

        const configPath = path.join(__dirname, '../env/config.json');
        let config = fs.existsSync(configPath) ? fs.readJsonSync(configPath) : {};
        if (!config.warns) config.warns = {};
        if (!config.warns[from]) config.warns[from] = {};
        
        config.warns[from][user] = (config.warns[from][user] || 0) + 1;
        const count = config.warns[from][user];

        if (count >= 3) {
            await sock.sendCustom(from, { text: `⚠️ @${user.split('@')[0]} a atteint 3 avertissements et va être expulsé.`, mentions: [user] });
            await sock.groupParticipantsUpdate(from, [user], 'remove');
            delete config.warns[from][user];
        } else {
            await sock.sendCustom(from, { text: `⚠️ @${user.split('@')[0]} a reçu un avertissement (${count}/3).`, mentions: [user] });
        }

        fs.writeJsonSync(configPath, config);
    }
};
