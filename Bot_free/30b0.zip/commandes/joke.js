module.exports = {
    name: 'joke',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *joke* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
