const axios = require('axios');
module.exports = {
    name: 'ai',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const text = args.join(' ');
        if (!text) return sock.sendCustom(from, { text: "Posez-moi une question ! Exemple: *.ai Bonjour*" });
        try {
            const response = await axios.get(`https://api.simsimi.net/v2/?text=${encodeURIComponent(text)}&lc=fr`);
            const reply = response.data.success || "Je ne sais pas quoi répondre à cela.";
            sock.sendCustom(from, { text: `🤖 *MCKINGER AI* :\n\n${reply}` });
        } catch (e) {
            sock.sendCustom(from, { text: "Désolé, mon cerveau est un peu fatigué. Réessayez plus tard." });
        }
    }
};
