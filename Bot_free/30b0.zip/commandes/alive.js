const fs = require('fs');
const path = require('path');

module.exports = {
    name: 'alive',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const imagePath = path.join(__dirname, '../images/menu.jpg');
        const aliveMsg = "👑 *MCKINGER XMD* est en ligne !\n\nJe suis prêt à vous servir. Tapez *.menu* pour voir mes capacités.";
        
        if (fs.existsSync(imagePath)) {
            await sock.sendMessage(from, { 
                image: fs.readFileSync(imagePath), 
                caption: aliveMsg,
                contextInfo: {
                    externalAdReply: {
                        title: "MCKINGER XMD",
                        body: "Bot WhatsApp Actif",
                        sourceUrl: "https://whatsapp.com/channel/0029Vb6tl8K2f3EPZquxE92s",
                        mediaType: 1,
                        renderLargerThumbnail: true,
                        thumbnail: fs.readFileSync(imagePath)
                    }
                }
            }, { quoted: m });
        } else {
            await sock.sendMessage(from, { text: aliveMsg }, { quoted: m });
        }
    }
};
