const { downloadMediaMessage } = require("@whiskeysockets/baileys");

module.exports = {
    name: "setpp",
    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        try {
            const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

            let imageMessage;

            // 📸 Cas 1: réponse à une image
            if (quoted?.imageMessage) {
                imageMessage = quoted.imageMessage;
            }

            // 📸 Cas 2: image envoyée directement
            else if (m.message?.imageMessage) {
                imageMessage = m.message.imageMessage;
            }

            // ❌ Aucun média
            if (!imageMessage) {
                return await sock.sendCustom(from, {
                    text: `╭───〔 ❌ MCKINGER X VOID 〕───⬣
│
│ ✖️ Aucune image détectée
│
│ ➤ Réponds à une image avec setpp
│ ➤ ou envoie une image + setpp
│
╰────────────────⬣`
                });
            }

            // 📥 Télécharger image
            const buffer = await downloadMediaMessage(
                { message: { imageMessage } },
                "buffer",
                {},
                { logger: console }
            );

            // 🔥 Set PP
            await sock.updateProfilePicture(sock.user.id, buffer);

            await sock.sendCustom(from, {
                text: `╭───〔 👑 MCKINGER X VOID 〕───⬣
│
│ ✦ STATUS : SUCCÈS ✅
│
│ ✧ Ta photo de profil a été mise à jour
│ ✧ Nouveau style appliqué 🫴🍷
│
╰────────────────⬣`
            });

        } catch (e) {
            console.error("Erreur setpp :", e);
            await sock.sendCustom(from, {
                text: `╭───〔 💀 MCKINGER X VOID 〕───⬣
│
│ ✖️ Impossible de changer la photo
│ ✧ Vérifie l'image ou réessaie
│
╰────────────────⬣`
            });
        }
    },
};