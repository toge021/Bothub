module.exports = {
    name: 'repo',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const repoInfo = `🔗 *MCKINGER CONNECT * 🔗\n\n` +
                         `➤ *Telegram Link:* https://t.me/Mckinger_pride_bot\n` +
                         `➤ *Développeur :* MCKINGER\n` +
                         `➤ *Description :*  I am perfect in every way 🫴🍷.\n\n` +
                         `Go to connect 🫴🍷 !`;
        await sock.sendCustom(from, { text: repoInfo });
    }
};
