const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'sprefix',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const configPath = path.join(__dirname, '../env/config.json');
        let config = {};

        if (fs.existsSync(configPath)) {
            config = fs.readJsonSync(configPath);
        }

        const currentSprefix = config.sprefix === true;
        const newSprefix = !currentSprefix;

        config.sprefix = newSprefix;
        fs.writeJsonSync(configPath, config, { spaces: 4 });

        const status = newSprefix ? "activé" : "désactivé";
        await sock.sendCustom(from, { text: `✅ Le mode sans préfixe a été *${status}* avec succès.` });
    }
};
