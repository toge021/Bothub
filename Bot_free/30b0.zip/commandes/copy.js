module.exports = {
    name: 'copy',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *copy* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
