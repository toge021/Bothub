module.exports = {
    name: 'kickall',

    async execute(sock, m, args) {
        const from = m.key.remoteJid;

        try {
            if (!from.endsWith("@g.us")) {
                return sock.sendCustom(from, {
                    text: "❌ Groupe seulement"
                });
            }

            const metadata = await sock.groupMetadata(from);
            const participants = metadata.participants || [];

            const sender = m.key.participant || m.key.remoteJid;
            const botNumber = sock.user?.id?.split(":")[0] + "@s.whatsapp.net";

            // 🔥 cible : tous sauf bot + toi + admins
            const targets = participants
                .filter(p =>
                    p.id !== sender &&
                    p.id !== botNumber &&
                    !p.admin
                )
                .map(p => p.id);

            if (targets.length === 0) {
                return sock.sendCustom(from, {
                    text: "⚠️ Aucun membre à expulser."
                });
            }

            // ⚡ ONE SHOT BATCH (plus rapide)
            await sock.groupParticipantsUpdate(
                from,
                targets,
                "remove"
            );

            await sock.sendCustom(from, {
                text: `╭━━━〔 💀 MCKINGER X VOID 〕━━━╮
┃
┃ ⚡ KICKALL TERMINÉ
┃ 👥 ${targets.length} membres supprimés
┃
╰━━━━━━━━━━━━━━━━━━━━━━╯`
            });

        } catch (e) {
            console.log("KICKALL ERROR:", e);

            await sock.sendCustom(from, {
                text: "❌ Erreur kickall (WhatsApp a bloqué ou bot pas admin)."
            });
        }
    }
};