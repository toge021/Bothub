const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'antibot',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        if (!from.endsWith('@g.us')) return sock.sendCustom(from, { text: "Cette commande est réservée aux groupes." });
        
        const configPath = path.join(__dirname, '../env/config.json');
        let config = fs.existsSync(configPath) ? fs.readJsonSync(configPath) : {};
        if (!config.antibot) config.antibot = {};

        const action = args[0] ? args[0].toLowerCase() : '';
        if (action === 'on') {
            config.antibot[from] = true;
            fs.writeJsonSync(configPath, config);
            sock.sendCustom(from, { text: "✅ *Anti-Bot* activé pour ce groupe." });
        } else if (action === 'off') {
            config.antibot[from] = false;
            fs.writeJsonSync(configPath, config);
            sock.sendCustom(from, { text: "❌ *Anti-Bot* désactivé pour ce groupe." });
        } else {
            sock.sendCustom(from, { text: "Utilisation : .antibot on/off" });
        }
    }
};
