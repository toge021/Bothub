module.exports = {
    name: 'update',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        await sock.sendCustom(from, { text: "✅ La commande *update* a été activée et est prête à être configurée avec vos APIs spécifiques." });
    }
};
