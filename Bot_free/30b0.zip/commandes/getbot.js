module.exports = {
    name: 'getbot',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const botInfo = `🤖 *MCKINGER XMD INFO* 🤖\n\n` +
                        `➤ *Nom :* MCKINGER-XMD\n` +
                        `➤ *Version :* 5.0.0\n` +
                        `➤ *Développeur :* MCKINGER\n` +
                        `➤ *Langage :* Node.js (Baileys)\n` +
                        `➤ *Statut :* Opérationnel ✅\n\n` +
                        `Pour obtenir le bot, tapez *.repo*`;
        await sock.sendCustom(from, { text: botInfo });
    }
};
