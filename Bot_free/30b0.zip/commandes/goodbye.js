const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'goodbye',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        if (!from.endsWith('@g.us')) return sock.sendCustom(from, { text: "Cette commande est réservée aux groupes." });
        
        const configPath = path.join(__dirname, '../env/config.json');
        let config = fs.existsSync(configPath) ? fs.readJsonSync(configPath) : {};
        
        if (args[0] === 'on') {
            config.goodbye = config.goodbye || {};
            config.goodbye[from] = true;
            fs.writeJsonSync(configPath, config);
            sock.sendCustom(from, { text: "✅ Souhait de revoir (goodbye) activé pour ce groupe." });
        } else if (args[0] === 'off') {
            config.goodbye = config.goodbye || {};
            config.goodbye[from] = false;
            fs.writeJsonSync(configPath, config);
            sock.sendCustom(from, { text: "❌ Souhait de revoir (goodbye) désactivé pour ce groupe." });
        } else {
            sock.sendCustom(from, { text: "Utilisation: .goodbye on/off" });
        }
    }
};