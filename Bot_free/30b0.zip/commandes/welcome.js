const fs = require('fs-extra');
const path = require('path');

module.exports = {
    name: 'welcome',
    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        if (!from.endsWith('@g.us')) {
            return sock.sendCustom(from, { text: "⚠️ Commande réservée aux groupes." });
        }

        const configPath = path.join(__dirname, '../env/config.json');
        let config = fs.existsSync(configPath) ? fs.readJsonSync(configPath) : {};

        config.welcome = config.welcome || {};

        if (args[0] === 'on') {
            config.welcome[from] = true;
            fs.writeJsonSync(configPath, config);

            sock.sendCustom(from, {
                text: `╭━━━〔 👑 𝗠𝗰𝗸𝗶𝗻𝗴𝗲𝗿 𝗫 𝗩𝗼𝗶𝗱 〕━━━⬣
┃ ✅ 𝐖𝐞𝐥𝐜𝐨𝐦𝐞 activé
┃ 📌 Groupe protégé
╰━━━━━━━━━━━━━━━━⬣`
            });

        } else if (args[0] === 'off') {
            config.welcome[from] = false;
            fs.writeJsonSync(configPath, config);

            sock.sendCustom(from, {
                text: `╭━━━〔 ⚠️ 𝗗𝗶𝘀𝗮𝗯𝗹𝗲 〕━━━⬣
┃ ❌ Welcome désactivé
╰━━━━━━━━━━━━━━━━⬣`
            });

        } else {
            sock.sendCustom(from, { text: "📌 Utilisation : .welcome on/off" });
        }
    }
};