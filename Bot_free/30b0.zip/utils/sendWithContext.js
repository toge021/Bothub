const fs = require("fs");
const path = require("path");

const WA_CHANNEL = process.env.WA_CHANNEL || "https://whatsapp.com/channel/0029Vb6tl8K2f3EPZquxE92s";

const NEWSLETTER_JID = "120363424857953119@newsletter";
const NEWSLETTER_NAME = "╭━━━━━━━━━━━━━━━╮\n👑 𝑀𝐶𝐾𝐼𝑁𝐺𝐸𝑅 X 𝑉𝑂𝐼𝐷 🤴\n╰━━━━━━━━━━━━━━━╯";

let thumbBuffer = null;
try {
    // Le chemin doit être résolu à partir de la racine du projet, pas __dirname
    const imagePath = path.resolve("images/thumb.jpg");
    if (fs.existsSync(imagePath)) {
        thumbBuffer = fs.readFileSync(imagePath);
    } else {
        const imagePathPng = path.resolve("images/thumb.png");
        if (fs.existsSync(imagePathPng)) {
            thumbBuffer = fs.readFileSync(imagePathPng);
        }
    }
} catch (err) {
    console.error("❌ Erreur chargement thumbnail :", err.message);
}

function getContextInfo() {
    return {
        forwardingScore: 99,
        isForwarded: true,
        forwardedNewsletterMessageInfo: {
            newsletterJid: NEWSLETTER_JID,
            newsletterName: NEWSLETTER_NAME,
            serverMessageId: -1,
        },
        externalAdReply: {
            title: "rejoins notre chaîne whatsapp", // en minuscules
            body: "👑 𝑀𝐶𝐾𝐼𝑁𝐺𝐸𝑅 X 𝑉𝑂𝐼𝐷 🤴",
            mediaType: 1,
            thumbnail: thumbBuffer,
            renderLargerThumbnail: false,
            mediaUrl: WA_CHANNEL,
            sourceUrl: WA_CHANNEL,
            thumbnailUrl: WA_CHANNEL, // Assurez-vous que c'est une URL directe vers une image
        },
    };
}

async function sendWithContext(client, remoteJid, content, options = {}) {
    const contextInfo = getContextInfo();
    
    // Appliquer la police si nécessaire (la fonction applyFont sera dans index.js)
    if (typeof options.applyFont === "function" && options.fontIndex) {
        if (content.text) {
            content.text = options.applyFont(content.text, options.fontIndex);
        }
        if (content.caption) {
            content.caption = options.applyFont(content.caption, options.fontIndex);
        }
    }

    // Ajouter le thumb au-dessus du texte si pas déjà une image/vidéo
    if (content.text && !content.image && !content.video && !content.document && thumbBuffer) {
        content.caption = content.text;
        content.image = thumbBuffer;
        delete content.text;
    }

    const message = {
        ...content,
        contextInfo,
    };

    return await client.sendMessage(remoteJid, message, options);
}

module.exports = { sendWithContext, getContextInfo };
