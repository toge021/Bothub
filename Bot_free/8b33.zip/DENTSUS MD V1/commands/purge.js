export const name = "purge";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  const count = parseInt(args[0]) || 10;
  if (count > 50) return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Maximum 50 messages à la fois." }, { quoted: msg });
  try {
    await natsu.sendMessage(jid, { text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ⚜️ Purge de ${count} messages en cours...` }, { quoted: msg });
  } catch (e) {
    await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ❌ Erreur purge." }, { quoted: msg });
  }
}
