import { BOT_NAME, BOT_VERSION, BOT_DEV, CHANNELS, BOT_IMAGE, MENU_AUDIO } from "../index.js";

export const name = "menu";

export async function execute(natsu, msg, args, from) {
  try {
    const jid = from || msg.key.remoteJid;
    const uptime = process.uptime();
    const h = Math.floor(uptime / 3600);
    const m = Math.floor((uptime % 3600) / 60);
    const s = Math.floor(uptime % 60);
    const uptimeStr = `${h}h ${m}m ${s}s`;

    const caption = `> ╔══════════════════╗
        ⚫ ${BOT_NAME} ⚫
> ╚══════════════════╝

> 🥷🏾 *Utilisateur* : ${msg.pushName || "Invité"}
> ⚙️ *Mode*         : 🔒 Privé
> ⏱️ *Uptime*       : ${uptimeStr}
> 📱 *Version*      : ${BOT_VERSION}
> 🧎🏾 *Développeur* : _${BOT_DEV}_

> ╔───── UTILITY ─────╗
> 📍 delete
> 📍 vv
> 📍 device
> 📍 countryinfos
> 📍 fancy
> 📍 infos
> 📍 meteo
> 📍 ping
> 📍 whois
> 📍 autorecording
> 📍 setpp
> ╚──────────────────╝

> ╔────── SUDO ──────╗
> ✌🏽 delsudo
> ✌🏽 listsudo
> ✌🏽 setsudo
> ╚─────────────────╝

> ╔───── GROUPS ─────╗
> ✨ add
> ✨ demote @
> ✨ demoteall
> ✨ gclink
> ✨ infosgroups
> ✨ kick @
> ✨ kickall
> ✨ left
> ✨ listonline
> ✨ mute
> ✨ unmute
> ✨ mute-time
> ✨ promote @
> ✨ promoteall
> ✨ principal
> ✨ tag
> ✨ tagadmin
> ✨ tagall
> ╚──────────────────╝

> ╔──── DOWNLOAD ────╗
> 📡 play
> 📡 tiktok
> 📡 tik2
> 📡 url
> 📡 youtube 
> ╚──────────────────╝

> ╔───── SECURITY ─────╗
> 🔒 antibot
> 🔒 antidemote
> 🔒 antilink
> 🔒 antipromote
> 🔒 antispam
> 🔒 warnadmin
> ╚───────────────────╝

> ╔───── MEDIAS ─────╗
> 🚀 photo
> 🚀 save
> 🚀 sticker
> ╚──────────────────╝

> ╔─────────FUN───────╗
> 💓 wasted
> 💓 blur
> ╚───────────────────╝

©️ Dev  𝗡𝗔𝗧𝗦𝗨𝗼𝗿𝗗𝗘𝗡𝗧𝗦𝗨`;

    await natsu.sendMessage(jid, { image: { url: BOT_IMAGE }, caption, gifPlayback: true }, { quoted: msg });
    await natsu.sendMessage(jid, { audio: { url: MENU_AUDIO }, mimetype: "audio/mpeg" }, { quoted: msg });
  } catch (e) {
    console.error("❌ Erreur commande menu :", e);
    await natsu.sendMessage(from || msg.key.remoteJid, { text: "> ⚠️ Impossible d'afficher le menu." });
  }
}
