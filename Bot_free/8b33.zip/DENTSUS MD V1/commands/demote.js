export const name = "demote";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  if (!jid.endsWith("@g.us")) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Commande de groupe uniquement." }, { quoted: msg });
  }
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid || [];
  const participant = msg.message?.extendedTextMessage?.contextInfo?.participant;
  const targets = mentioned.length ? mentioned : participant ? [participant] : [];
  if (!targets.length) return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Usage : .demote @membre" }, { quoted: msg });
  try {
    await natsu.groupParticipantsUpdate(jid, targets, "demote");
    await natsu.sendMessage(jid, {
      text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ✅ ${targets.map((t) => "@" + t.split("@")[0]).join(", ")} n'est/ne sont plus admin(s).`,
      mentions: targets,
    }, { quoted: msg });
  } catch (e) {
    await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ❌ Impossible de rétrograder." }, { quoted: msg });
  }
}
