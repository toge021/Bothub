export const name = "left";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  if (!jid.endsWith("@g.us")) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Commande de groupe uniquement." }, { quoted: msg });
  }
  await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: 👋🏾 Au revoir !" }, { quoted: msg });
  await natsu.groupLeave(jid);
}
