export const name = "tagadmin";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  if (!jid.endsWith("@g.us")) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Commande de groupe uniquement." }, { quoted: msg });
  }
  try {
    const meta = await natsu.groupMetadata(jid);
    const admins = meta.participants.filter((p) => p.admin);
    if (!admins.length) return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Aucun admin trouvé." }, { quoted: msg });
    const mentions = admins.map((p) => p.id);
    const text = `👑 *Admins du groupe :*\n` + mentions.map((m) => `@${m.split("@")[0]}`).join("\n");
    await natsu.sendMessage(jid, { text, mentions }, { quoted: msg });
  } catch (e) {
    await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ❌ Erreur tagadmin." }, { quoted: msg });
  }
}
