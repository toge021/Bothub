export const name = "infosgroups";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  if (!jid.endsWith("@g.us")) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Commande de groupe uniquement." }, { quoted: msg });
  }
  try {
    const meta = await natsu.groupMetadata(jid);
    const admins = meta.participants.filter((p) => p.admin);
    const desc = meta.desc || "Pas de description";
    const text = `╭════۩۞۩════╮
   𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗 - Infos Groupe
╰════۩۞۩════╯

📛 *Nom:* ${meta.subject}
👥 *Membres:* ${meta.participants.length}
👑 *Admins:* ${admins.length}
📝 *Description:* ${desc}
🔒 *Restriction:* ${meta.announce ? "Admins seulement" : "Tous"}
🆔 *ID:* ${meta.id}`;
    await natsu.sendMessage(jid, { text }, { quoted: msg });
  } catch (e) {
    await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ❌ Impossible de récupérer les infos du groupe." }, { quoted: msg });
  }
}
