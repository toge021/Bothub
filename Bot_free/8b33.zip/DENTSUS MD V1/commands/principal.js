export const name = "principal";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  if (!jid.endsWith("@g.us")) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Commande de groupe." }, { quoted: msg });
  }
  try {
    const meta = await natsu.groupMetadata(jid);
    const creatorId = meta.owner;
    if (!creatorId) return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ❌ Créateur absent." }, { quoted: msg });
    await natsu.sendMessage(jid, {
      text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Le créateur du groupe est : @${creatorId.split("@")[0]}`,
      mentions: [creatorId],
    }, { quoted: msg });
  } catch (e) {
    await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ❌ Erreur." }, { quoted: msg });
  }
}
