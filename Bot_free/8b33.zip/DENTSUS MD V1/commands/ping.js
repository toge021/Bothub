export const name = "ping";

export async function execute(natsu, msg, args, from) {
  try {
    const jid = from || msg.key.remoteJid;
    const start = Date.now();
    const sentMsg = await natsu.sendMessage(jid, { text: "🫩 Ping..." }, { quoted: msg });
    const latency = Date.now() - start;

    await natsu.sendMessage(jid, {
      text: `> ╭═⚛️ PONG ⚛️══╮\n> │ 🏎️ Bot opérationnel\n> │ ⏱️ : ${latency} ms\n> ╰═══════════╯`,
    }, { quoted: sentMsg });
  } catch (e) {
    console.error("❌ Erreur ping :", e);
    await natsu.sendMessage(from || msg.key.remoteJid, { text: "> ⚠️ 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Impossible de calculer la vitesse." }, { quoted: msg });
  }
}
