import { loadSudo } from "../index.js";

export const name = "listsudo";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  const list = loadSudo();
  if (!list.length) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: 📋 Aucun sudo défini." }, { quoted: msg });
  }
  const text = `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: 📋 *Liste Sudo:*\n${list.map((n, i) => `${i + 1}. +${n}`).join("\n")}`;
  await natsu.sendMessage(jid, { text }, { quoted: msg });
}
