export const name = "gclink";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  if (!jid.endsWith("@g.us")) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Commande de groupe uniquement." }, { quoted: msg });
  }
  try {
    const code = await natsu.groupInviteCode(jid);
    await natsu.sendMessage(jid, {
      text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: 🔗 Lien d'invitation du groupe :\nhttps://chat.whatsapp.com/${code}`,
    }, { quoted: msg });
  } catch (e) {
    await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ❌ Impossible de récupérer le lien (vérifiez mes droits admin)." }, { quoted: msg });
  }
}
