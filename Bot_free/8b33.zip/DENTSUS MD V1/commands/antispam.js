import { statusProtections } from "../protections.js";

export const name = "antispam";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  if (!args[0] || !["on", "off"].includes(args[0])) {
    return await natsu.sendMessage(jid, {
      text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: AntiSpam est ${statusProtections.antiSpam ? "actif" : "inactif"}\nUsage : .antispam <on/off>`,
    }, { quoted: msg });
  }
  statusProtections.antiSpam = args[0] === "on";
  await natsu.sendMessage(jid, { text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Anti-spam ${args[0] === "on" ? "actif ✅" : "inactif ❌"} !` }, { quoted: msg });
}
