import { CHANNELS, NEWSLETTER_IDS } from "../index.js";

export const name = "autojoin";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;

  if (!args[0] || !["on", "off", "status"].includes(args[0])) {
    return await natsu.sendMessage(jid, {
      text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: 📡 Auto-join Newsletter\n\nUsage :\n.autojoin on — Rejoindre les canaux officiels\n.autojoin off — Se désabonner des canaux\n.autojoin status — Voir les canaux\n\n🌐 Canaux :\n${CHANNELS.whatsapp1}\n${CHANNELS.whatsapp2}`,
    }, { quoted: msg });
  }

  if (args[0] === "status") {
    return await natsu.sendMessage(jid, {
      text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: 📡 *Canaux Officiels DENTSU XD*\n\n🌐 WhatsApp 1:\n${CHANNELS.whatsapp1}\n\n🌐 WhatsApp 2:\n${CHANNELS.whatsapp2}\n\n📱 Telegram:\n${CHANNELS.telegram1}\n${CHANNELS.telegram2}`,
    }, { quoted: msg });
  }

  const results = [];
  for (const newsletterId of NEWSLETTER_IDS) {
    try {
      if (args[0] === "on") {
        if (typeof natsu.newsletterFollow === "function") {
          await natsu.newsletterFollow(newsletterId);
          results.push(`✅ Rejoint : ${newsletterId}`);
        } else {
          results.push(`⚠️ newsletterFollow non disponible`);
        }
      } else if (args[0] === "off") {
        if (typeof natsu.newsletterUnfollow === "function") {
          await natsu.newsletterUnfollow(newsletterId);
          results.push(`✅ Quitté : ${newsletterId}`);
        } else {
          results.push(`⚠️ newsletterUnfollow non disponible`);
        }
      }
    } catch (e) {
      results.push(`❌ Erreur pour ${newsletterId}: ${e.message}`);
    }
  }

  await natsu.sendMessage(jid, {
    text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: 📡 Résultat auto-join :\n\n${results.join("\n")}`,
  }, { quoted: msg });
}
