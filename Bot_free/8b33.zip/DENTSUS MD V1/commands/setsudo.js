import { addSudo, normalizeNumber } from "../index.js";

export const name = "setsudo";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
  const raw = mentioned ? mentioned.split("@")[0] : args[0];
  const bare = normalizeNumber(raw);
  if (!bare) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Usage : .setsudo @mention ou .setsudo 242xxxxxxxx" }, { quoted: msg });
  }
  const updated = addSudo(bare);
  await natsu.sendMessage(jid, { text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ✅ *${bare}* ajouté aux sudo.\nSudo actifs: ${updated.join(", ")}` }, { quoted: msg });
}
