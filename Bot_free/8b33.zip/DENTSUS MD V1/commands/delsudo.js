import { removeSudo, normalizeNumber } from "../index.js";

export const name = "delsudo";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;
  const mentioned = msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];
  const raw = mentioned ? mentioned.split("@")[0] : args[0];
  const bare = normalizeNumber(raw);
  if (!bare) {
    return await natsu.sendMessage(jid, { text: "> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: Usage : .delsudo @mention ou .delsudo 242xxxxxxxx" }, { quoted: msg });
  }
  const updated = removeSudo(bare);
  if (updated !== false) {
    await natsu.sendMessage(jid, { text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: 🗑️ Le numéro *${bare}* a été retiré des sudo.` }, { quoted: msg });
  } else {
    await natsu.sendMessage(jid, { text: `> 𝗗𝗘𝗡𝗧𝗦𝗨 𝗫𝗗: ⚠️ Le numéro *${bare}* n'était pas dans la liste sudo.` }, { quoted: msg });
  }
}
