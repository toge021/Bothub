import { BOT_NAME, OWNER_NUMBERS, CHANNELS } from "../index.js";

export const name = "owner";

export async function execute(natsu, msg, args, from) {
  const jid = from || msg.key.remoteJid;

  const text = `╔═══•❥🌑•❥═══•❥🌑•❥═══╗
        🏅 ${BOT_NAME} V1 🏅
╚═══•❥🌑•❥═══•❥🌑•❥═══╝

╔══════•⊰👁️‍🗨️⊱•══════╗
     🕷️ 𝘿𝙀𝙑 𝘽𝙔 NATSU 🕷️
╚══════•⊰👁️‍🗨️⊱•══════╝

│ ⚫ *Rejoins la Confrérie ${BOT_NAME}* ⚫
│ 
│ 🖤  natsu : +${OWNER_NUMBERS[0]}
│ 🖤  OMA   : +${OWNER_NUMBERS[1]}
│ 🖤  Telegram : ${CHANNELS.telegram1}

╭─────•⊰ 🔮 Canaux Officiels 🔮 ⊱•─────╮
│ 🕯️ WhatsApp :  
│ ${CHANNELS.whatsapp1}  
│
│ 🕯️ WhatsApp 2 :
│ ${CHANNELS.whatsapp2}
│
│ 🕯️ Telegram :  
│ ${CHANNELS.telegram2}  
╰━━━━━━━•⊰⚫⊱•━━━━━━━╯`;

  await natsu.sendMessage(jid, { text }, { quoted: msg });
}
