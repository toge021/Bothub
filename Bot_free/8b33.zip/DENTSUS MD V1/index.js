import {
  makeWASocket,
  useMultiFileAuthState,
  fetchLatestBaileysVersion,
  makeCacheableSignalKeyStore,
  DisconnectReason,
  isJidBroadcast,
  proto,
} from "@whiskeysockets/baileys";
import chalk from "chalk";
import fs from "fs";
import path from "path";
import readline from "readline";
import dotenv from "dotenv";
import { initProtections } from "./protections.js";
dotenv.config();

const config = {
  PREFIX: process.env.PREFIXE || ".",
  AUTH_DIR: process.env.DOSSIER_AUTH || "auth_baileys",
  USE_QR: process.env.USE_QR === "true",
  RECONNECT_DELAY: parseInt(process.env.RECONNECT_DELAY) || 5000,
};

export const BOT_NAME = "\u{1D5D7}\u{1D5DC}\u{1D5E1}\u{1D5E3}\u{1D5E6}\u{1D5E8} \u{1D5EB}\u{1D5D7}";
export const BOT_VERSION = "1.0";
export const BOT_DEV = "NATSUorDENTSU";
export const OWNER_NUMBERS = ["242053605516", "242053323191"];
export const OWNER_NAMES = { "242053605516": "natsu", "242053323191": "OMA" };
export const CHANNELS = {
  whatsapp1: "https://whatsapp.com/channel/0029VbC1s7fFnSz1YhZYc01h",
  whatsapp2: "https://whatsapp.com/channel/0029VayOeIbGufIvDPhi6m1X",
  telegram1: "t.me/NatsuetDentsu",
  telegram2: "t.me/DPLOIEMENT_DUN_BOT2",
};
export const NEWSLETTER_IDS = [
  "120363373387302754@newsletter",
  "120363408953987969@newsletter",
  "120363425458450099@newsletter",
  "120363423640959729@newsletter",
];
export const BOT_IMAGE = "https://files.catbox.moe/slzrm9.jpg";
export const MENU_AUDIO = "https://files.catbox.moe/cfzs04.mp3";

// Logger simple sans pino-pretty (compatible Pterodactyl, pas de worker threads)
const log = {
  info:  (...a) => console.log("[INFO]",  ...a),
  warn:  (...a) => console.log("[WARN]",  ...a),
  error: (...a) => console.log("[ERROR]", ...a),
};
// Logger muet pour Baileys (evite les spams internes)
const silentLogger = {
  level: "silent", child: () => silentLogger,
  info: ()=>{}, warn: ()=>{}, error: ()=>{},
  debug: ()=>{}, trace: ()=>{}, fatal: ()=>{},
};

const SUDO_FILE = "./sudo.json";
export function loadSudo() {
  if (!fs.existsSync(SUDO_FILE)) return [];
  try { return JSON.parse(fs.readFileSync(SUDO_FILE, "utf-8")); } catch { return []; }
}
export function saveSudo(list) { fs.writeFileSync(SUDO_FILE, JSON.stringify(list, null, 2)); }
export function addSudo(num) {
  const s = new Set(loadSudo()); s.add(num); saveSudo([...s]); return [...s];
}
export function removeSudo(num) {
  const list = loadSudo().filter((n) => n !== num); saveSudo(list); return list;
}
export function isSudo(num) { return loadSudo().includes(num); }

export function normalizeJid(jid) {
  if (!jid) return null;
  const bare = String(jid).trim().split(":")[0];
  return bare.includes("@") ? bare : bare + "@s.whatsapp.net";
}
export function getBareNumber(jid) {
  if (!jid) return "";
  return String(jid).split("@")[0].split(":")[0].replace(/[^0-9]/g, "");
}
export function normalizeNumber(raw) {
  if (!raw) return null;
  const n = String(raw).replace(/[^0-9]/g, "");
  return n.length >= 7 ? n : null;
}

function pickText(message) {
  if (!message) return;
  return (
    message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.buttonsResponseMessage?.selectedButtonId ||
    message.listResponseMessage?.singleSelectReply?.selectedRowId ||
    message.templateButtonReplyMessage?.selectedId ||
    message.interactiveResponseMessage?.text
  );
}

function unwrapMessage(msg) {
  return (
    msg?.viewOnceMessage?.message ||
    msg?.viewOnceMessageV2?.message ||
    msg?.ephemeralMessage?.message ||
    msg?.documentWithCaptionMessage?.message ||
    msg
  );
}

function afficherBanner() {
  try { console.clear(); } catch {}
  console.log("\n=============================================");
  console.log("   DENTSUS MD  -  SYSTEM ONLINE  ⚡");
  console.log("   Bot WhatsApp Baileys + Node.js");
  console.log("=============================================\n");
}

// Saisie du numero dans la console (sans .env)
function demanderNumeroConsole() {
  return new Promise((resolve) => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
    console.log("\n╔═══════════════════════════════════════════╗");
    console.log("║   📱  ENTREZ VOTRE NUMERO WHATSAPP        ║");
    console.log("║   Format international sans +             ║");
    console.log("║   Exemple : 242053605516                  ║");
    console.log("╚═══════════════════════════════════════════╝");
    rl.question("  >> Numero : ", (answer) => {
      rl.close();
      const clean = answer.replace(/[^0-9]/g, "");
      if (clean.length < 7) {
        console.log("❌ Numero invalide. Redemarre et reessaie.");
        resolve(null);
      } else {
        resolve(clean);
      }
    });
  });
}

// Code de parrainage 8 caracteres alphanumeriques (PAS de QR)
async function demanderCodeParrainage(natsu) {
  if (typeof natsu.requestPairingCode !== "function") {
    console.log("⚠️  requestPairingCode non disponible");
    return;
  }
  const number = await demanderNumeroConsole();
  if (!number) return;
  try {
    const code = await natsu.requestPairingCode(number, "DENTSUMD");
    const afficher = () => {
      console.log("\n╔═══════════════════════════════════════════╗");
      console.log("║   🔑  CODE DE LIAISON WHATSAPP            ║");
      console.log("║                                           ║");
      console.log("║     >>>  " + String(code) + "  <<<             ║");
      console.log("║                                           ║");
      console.log("║  WhatsApp > Appareils lies >              ║");
      console.log("║  Lier un appareil > Entrer le code        ║");
      console.log("╚═══════════════════════════════════════════╝\n");
    };
    afficher();
    const iv = setInterval(afficher, 15000);
    setTimeout(() => clearInterval(iv), 120000);
    return code;
  } catch (err) {
    console.log("❌ Echec code pairing: " + (err?.message ?? err));
  }
}

async function autoFollowNewsletters(natsu) {
  for (const newsletterId of NEWSLETTER_IDS) {
    try {
      if (typeof natsu.newsletterFollow === "function")
        await natsu.newsletterFollow(newsletterId);
    } catch {}
  }
}

const emojiMap = {
  menu: "📋", ping: "🏓", infos: "🗒️", owner: "👑", device: "📱",
  delete: "🗑️", vv: "👁️", whois: "🖼️", setpp: "🖼️", autorecording: "🎙️",
  sticker: "🖼️", save: "💾", photo: "🖼️", url: "🔗", add: "👥",
  kick: "❌", kickall: "😼", tagall: "🌍", tag: "👥", tagadmin: "👑",
  promote: "↗️", demote: "↘️", demoteall: "↘️", promoteall: "↗️",
  gclink: "🔗", left: "👋", mute: "🔇", unmute: "🔊", purge: "⚜️",
  principal: "👑", setppg: "🖼️", settimeg: "⏰", writetoall: "📣",
  wasted: "💀", antibot: "🤖", antidemote: "⚜️", antilink: "🔗",
  antipromote: "⚜️", antispam: "✅", warnadmin: "⚔️", listonline: "🟢",
  delsudo: "❌", listsudo: "📋", setsudo: "✅", "mute-time": "⏰",
};

// Cache messages pour eviter les erreurs Bad MAC (retry Baileys)
const msgStore = new Map();

log.info("Demarrage DENTSUS MD...");
startBot();

async function startBot() {
  try {
    let version;
    try {
      const res = await fetchLatestBaileysVersion();
      version = res.version;
      log.info("Version Baileys : " + version.join("."));
    } catch {
      version = [2, 3000, 1015901307];
      log.warn("Version Baileys de secours utilisee");
    }

    const { state, saveCreds } = await useMultiFileAuthState(config.AUTH_DIR);

    const natsu = makeWASocket({
      version,
      logger: silentLogger,
      printQRInTerminal: config.USE_QR,
      auth: {
        creds: state.creds,
        keys: makeCacheableSignalKeyStore(state.keys, silentLogger),
      },
      msgRetryCounterCache: new Map(),
      browser: ["Ubuntu", "Chrome", "20.0.04"],
      generateHighQualityLinkPreview: true,
      // Fix Bad MAC : fournit les messages pour le retry de dechiffrement
      getMessage: async (key) => {
        const stored = msgStore.get(key.id);
        if (stored) return stored;
        return proto.Message.fromObject({ conversation: "" });
      },
    });

    natsu.ev.on("creds.update", saveCreds);

    // Stocke les messages recus pour le retry (fix Bad MAC)
    natsu.ev.on("messages.upsert", ({ messages }) => {
      for (const msg of messages) {
        if (msg.key?.id && msg.message) {
          msgStore.set(msg.key.id, msg.message);
          // Limite le cache a 500 messages
          if (msgStore.size > 500) {
            const firstKey = msgStore.keys().next().value;
            msgStore.delete(firstKey);
          }
        }
      }
    });

    natsu.ev.on("connection.update", async (update) => {
      const { connection, lastDisconnect, qr } = update;

      if (qr && config.USE_QR) {
        try {
          const { default: qrcode } = await import("qrcode-terminal");
          console.log("\n📱 Scanne ce QR avec WhatsApp :\n");
          qrcode.generate(qr, { small: true });
        } catch {}
      }

      if (connection === "open") {
        log.info("✅ Bot connecte !");
        afficherBanner();
        try {
          const userJid = natsu.user?.id || null;
          const bareConnected = getBareNumber(userJid);
          global.owners = bareConnected ? [bareConnected, ...OWNER_NUMBERS] : [...OWNER_NUMBERS];
          global.owners = [...new Set(global.owners)];
          log.info("Proprietaires : " + global.owners.join(", "));
        } catch { global.owners = [...OWNER_NUMBERS]; }

        try { initProtections(natsu); } catch (e) { log.error("Erreur initProtections: " + e?.message); }

        global.commands = {};
        const cmdDir = "./commands";
        if (fs.existsSync(cmdDir)) {
          const cmdFiles = fs.readdirSync(cmdDir).filter((f) => f.endsWith(".js"));
          for (const file of cmdFiles) {
            try {
              const mod = await import(path.resolve(cmdDir, file));
              const cmd = mod.default ?? mod;
              if (cmd?.name && typeof cmd.execute === "function") global.commands[cmd.name] = cmd;
            } catch (e) { log.warn("Echec import " + file + ": " + (e?.message ?? e)); }
          }
        }
        log.info(Object.keys(global.commands).length + " commandes chargees");
        await autoFollowNewsletters(natsu);
        try {
          const selfJid = natsu.user?.id || null;
          const bareJid = selfJid ? selfJid.split(":")[0] : null;
          if (bareJid) {
            await natsu.sendMessage(normalizeJid(bareJid), {
              image: { url: BOT_IMAGE },
              caption: "🎉 DENTSUS MD est ACTIF !\n\nTape " + config.PREFIX + "menu pour les commandes",
            });
          }
        } catch {}
      }

      if (connection === "close") {
        let reason = "unknown";
        try { reason = lastDisconnect?.error?.output?.statusCode ?? lastDisconnect?.error?.message ?? String(lastDisconnect); } catch {}
        log.error("Deconnecte : " + reason);
        const loggedOut =
          lastDisconnect?.error?.output?.statusCode === DisconnectReason.loggedOut ||
          /loggedOut/i.test(String(reason));
        if (!loggedOut) {
          log.warn("Reconnexion dans " + config.RECONNECT_DELAY + " ms...");
          setTimeout(startBot, config.RECONNECT_DELAY);
        } else {
          log.error("Session terminee — supprime le dossier auth_baileys et redemarre");
        }
      }
    });

    // Demande le numero manuellement 3s apres le demarrage
    setTimeout(async () => {
      try {
        if (!state.creds?.registered && !config.USE_QR) {
          await demanderCodeParrainage(natsu);
        }
      } catch (e) { log.warn("Erreur pairing: " + e?.message); }
    }, 3000);

    // Handler principal des messages (commandes)
    natsu.ev.on("messages.upsert", async ({ messages }) => {
      try {
        const msg = messages?.[0];
        if (!msg?.message) return;

        const from = msg.key.remoteJid;
        if (!from || isJidBroadcast(from)) return;

        const isGroup = from.endsWith("@g.us");
        let sender = msg.key.fromMe
          ? natsu.user?.id
          : isGroup
          ? msg.key.participant
          : msg.key.remoteJid;

        if (!sender) return;
        if (String(sender).includes("@lid")) {
          try { sender = natsu.decodeJid(sender); } catch {}
        }

        const senderNum = getBareNumber(sender);
        const ownersNums = (global.owners || []).map(getBareNumber);
        const sudoNums = loadSudo().map(getBareNumber);
        if (!ownersNums.includes(senderNum) && !sudoNums.includes(senderNum)) return;

        const rawMsg = unwrapMessage(msg.message);
        const body = pickText(rawMsg);
        if (!body || !body.startsWith(config.PREFIX)) return;

        const args = body.slice(config.PREFIX.length).trim().split(/ +/);
        const commandName = (args.shift() || "").toLowerCase();
        const cmd = global.commands?.[commandName];

        try { await natsu.sendMessage(from, { react: { text: "📡", key: msg.key } }); } catch {}

        if (cmd) {
          const emoji = emojiMap[commandName];
          if (emoji) { try { await natsu.sendMessage(from, { react: { text: emoji, key: msg.key } }); } catch {} }
          try {
            if (typeof cmd.execute === "function") await cmd.execute(natsu, msg, args, from);
            else if (typeof cmd === "function") await cmd(natsu, msg, args, from);
          } catch (e) {
            log.error("Erreur commande " + commandName + ": " + e?.message);
            try {
              await natsu.sendMessage(from, {
                text: "> ⚠️ Erreur lors de l'execution de la commande : " + commandName,
              }, { quoted: msg });
            } catch {}
          }
        }
      } catch (e) {
        // Erreurs Bad MAC / dechiffrement — on ignore silencieusement
        if (e?.message?.includes("Bad MAC") || e?.message?.includes("decrypt")) return;
        log.warn("Erreur messages.upsert: " + e?.message);
      }
    });

  } catch (e) {
    log.error("Erreur critique: " + (e?.message ?? e));
    setTimeout(startBot, config.RECONNECT_DELAY);
  }
}

process.on("unhandledRejection", (r) => {
  const msg = String(r);
  // Ignorer silencieusement les erreurs de dechiffrement Baileys (Bad MAC)
  if (msg.includes("Bad MAC") || msg.includes("decrypt") || msg.includes("No sessions")) return;
  log.error("Rejection: " + msg);
});
process.on("uncaughtException", (e) => {
  const msg = e?.message || String(e);
  if (msg.includes("Bad MAC") || msg.includes("decrypt") || msg.includes("No sessions")) return;
  log.error("Exception: " + msg);
});
