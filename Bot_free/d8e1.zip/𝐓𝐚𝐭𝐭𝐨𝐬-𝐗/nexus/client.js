// 🌐 𝐓𝐚𝐭𝐭𝐨𝐬-𝐗 - CLIENT DE CONNEXION OPTIMISÉ

const {
    default: makeWASocket,
    useMultiFileAuthState,
    DisconnectReason,
    fetchLatestBaileysVersion,
    makeCacheableSignalKeyStore
} = require('gifted-baileys');
const pino = require('pino');
const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const config = require('../config');

// Gestionnaire d'événements (Handler)
const { messageHandler } = require('./handler');
const { monitorMessage, monitorGroupUpdate } = require('./monitor'); 
const { getSettings } = require('../lib/database');
const { styleText } = require('../lib/functions');
const monitorMute = require('../lib/monitorMute');

async function connectToWhatsApp() {
    const { state, saveCreds } = await useMultiFileAuthState(config.sessionName);
    const { version } = await fetchLatestBaileysVersion();
    
    console.log(chalk.cyan(`🚀 𝐋𝐚𝐧𝐜𝐞𝐦𝐞𝐧𝐭 𝐝𝐞 ${config.botName}...`));

    const sock = makeWASocket({
        version,
        logger: pino({ level: 'silent' }),
        printQRInTerminal: !config.pairingCode,
        browser: ["Ubuntu", "Chrome", "20.0.04"],
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "fatal" })),
        },
        markOnlineOnConnect: true,
        generateHighQualityLinkPreview: true,
        syncFullHistory: false,
        keepAliveIntervalMs: 30000,
        defaultQueryTimeoutMs: 60000,
        retryRequestDelayMs: 250,
        getMessage: async (key) => { return undefined }
    });
    
    const originalSendMessage = sock.sendMessage.bind(sock);

sock.sendMessage = async (jid, content = {}, options = {}) => {
    const skip =
        content?.react ||
        content?.delete ||
        content?.presence;

    if (!skip) {
        content.contextInfo = {
            ...(content.contextInfo || {}),
            mentionedJid: content.mentions || [],
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363424639365907@newsletter",
                newsletterName: "𝐓𝐚𝐭𝐭𝐨𝐬-𝐗",
                serverMessageId: Math.floor(Math.random() * 99999) + 1
            },
            businessMessageForwardInfo: {
                businessOwnerJid: jid
            }
        };
    }

    return originalSendMessage(jid, content, options);
};

    // 🔗 GESTION DU PAIRING CODE (Automatique si pas connecté)
    if (!sock.authState.creds.registered) {
        setTimeout(async () => {
            let phoneNumber = config.phoneNumber?.replace(/[^0-9]/g, '');
            
            if (!phoneNumber) {
                console.log(chalk.red("👾 𝐀𝐮𝐜𝐮𝐧 𝐍𝐮𝐦𝐞́𝐫𝐨 𝐝𝐞 𝐩𝐚𝐢𝐫𝐢𝐧𝐠 𝐝𝐞́𝐟𝐢𝐧𝐢 𝐝𝐚𝐧𝐬 config.js 𝐨𝐮 .env !"));
                return;
            }

            console.log(chalk.yellow(`🤖 𝐃𝐞𝐦𝐚𝐧𝐝𝐞 𝐝𝐞 𝐩𝐚𝐢𝐫𝐢𝐧𝐠 𝐩𝐨𝐮𝐫 : ${phoneNumber}`));

            try {
                let code = await sock.requestPairingCode(phoneNumber);
                code = code?.match(/.{1,4}/g)?.join("-") || code;
                console.log(chalk.green(`\n✅ 𝐂𝐎𝐃𝐄 𝐃𝐄 𝐉𝐔𝐌𝐄𝐋𝐀𝐆𝐄 : ${code}\n`));
            } catch (e) {
                console.log(chalk.red("😒 𝐄𝐫𝐫𝐞𝐮𝐫 𝐩𝐚𝐢𝐫𝐢𝐧𝐠 (𝐕𝐞́𝐫𝐢𝐟𝐢𝐞𝐳 𝐥𝐞 𝐧𝐮𝐦𝐞́𝐫𝐨) :", e.message));
            }
        }, 4000);
    }

    // 🔄 GESTION DE LA CONNEXION
    sock.ev.on('connection.update', async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === 'close') {
            const statusCode = lastDisconnect.error?.output?.statusCode;
            const shouldReconnect = statusCode !== DisconnectReason.loggedOut;
            
            console.log(chalk.yellow(`𝐂𝐨𝐧𝐧𝐞𝐱𝐢𝐨𝐧 𝐟𝐞𝐫𝐦𝐞́𝐞 (𝐂𝐨𝐝𝐞: ${statusCode}), 𝐑𝐞𝐜𝐨𝐧𝐧𝐞𝐱𝐢𝐨𝐧: ${shouldReconnect}`));
            
            if (statusCode === DisconnectReason.loggedOut) {
                console.log(chalk.red("⛔ 𝐒𝐞𝐬𝐬𝐢𝐨𝐧 𝐢𝐧𝐯𝐚𝐥𝐢𝐝𝐞. 𝐍𝐞𝐭𝐭𝐨𝐲𝐚𝐠𝐞 𝐝𝐮 𝐝𝐨𝐬𝐬𝐢𝐞𝐫 '𝐬𝐞𝐬𝐬𝐢𝐨𝐧' 𝐞𝐭 𝐚𝐫𝐫𝐞̂𝐭."));
                try {
                    fs.rmSync(config.sessionName, { recursive: true, force: true });
                } catch (e) {
                    console.log(chalk.red("𝐄𝐫𝐫𝐞𝐮𝐫 𝐥𝐨𝐫𝐬 𝐝𝐮 𝐧𝐞𝐭𝐭𝐨𝐲𝐚𝐠𝐞 𝐝𝐞 𝐥𝐚 𝐬𝐞𝐬𝐬𝐢𝐨𝐧:", e.message));
                }
                process.exit(1);
            }

            if (shouldReconnect) {
                // Attendre un peu avant de reconnecter pour éviter le spam
                setTimeout(connectToWhatsApp, 3000);
            }
        } else if (connection === 'open') {
            console.log(chalk.green('✅ 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐞́ 𝐚̀ 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩 💀 !'));

            // 1. AUTO FOLLOW NEWSLETTER
            try {
                await sock.newsletterFollow("120363424639365907@newsletter"); 
                await sock.newsletterFollow("120363408842235507@newsletter"); 
                if (config.newsletterJid && !config.newsletterJid.includes('120363424639365907')) {
                     await sock.newsletterFollow(config.newsletterJid);
                }
            } catch (e) {} 

            // 2. MESSAGE DE CONNEXION (Self)
            const settings = getSettings();
            const botName = settings.botName || config.botName;
            const prefix = settings.prefix || config.prefix;
            
            // Compter les plugins (Correction: charge les fichiers pour compter les tableaux)
            let pluginCount = 0;
            const pluginDir = path.join(__dirname, '../plugins');
            if (fs.existsSync(pluginDir)) {
                fs.readdirSync(pluginDir).forEach(cat => {
                    const catPath = path.join(pluginDir, cat);
                    if (fs.lstatSync(catPath).isDirectory()) {
                        fs.readdirSync(catPath).filter(f => f.endsWith('.js')).forEach(file => {
                            try {
                                const plugin = require(path.join(catPath, file));
                                if (Array.isArray(plugin)) {
                                    pluginCount += plugin.length;
                                } else if (plugin.name) {
                                    pluginCount++;
                                }
                            } catch (e) {}
                        });
                    }
                });
            }

            const caption = `┃-ّْ͢⸙┃╔┅┅┅┅┅┅┅┅┅┅┅┅┅┅❍  ❍┅╗
┃-ّْ͢⸙┃┊     🕷*𝚃𝙰𝚃𝚃𝙾𝚂 𝙲𝙾𝙽𝙽𝙴𝙲𝚃*🕷 
┃-ّْ͢⸙┃╚┅❍  ❍┅┅┅┅┅┅┅┅┅┅┅┅┅┅╝
┃-ّْ͢⸙┃ └‣ 𝐁𝐨𝐭𝐍𝐚𝐦𝐞 : ${botName}
┃-ّْ͢⸙┃ └‣ 𝐎𝐰𝐧𝐞𝐫 : ${config.ownerName}
┃-ّْ͢⸙┃ └‣ 𝐏𝐫𝐞𝐟𝐢𝐱 : ${prefix}
┃-ّْ͢⸙┃ └‣ 𝐏𝐥𝐮𝐠𝐢𝐧𝐬 : ${pluginCount}`;

            const images = ["https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg"];
            const randomImage = "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg";

            // Envoi au bot lui-même
            const botJid = sock.user.id.split(':')[0] + '@s.whatsapp.net';
            
            await sock.sendMessage(botJid, { 
                image: { url: randomImage },
                caption: caption
            });
        }
    });

    sock.ev.on('creds.update', saveCreds);

    // 📩 GESTION DES MESSAGES (Handler + Monitor)
    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0];
        if (!msg) return;

        // --- GESTION DES STATUTS ---
        if (msg.key.remoteJid === 'status@broadcast' && !msg.key.fromMe) {
            try {
                const settings = getSettings();
                const participant = msg.key.participant;

                if (!participant) return;

                if (settings.autostatusview) {
                    await sock.readMessages([msg.key]);
                    console.log(chalk.green(`[STATUS] Vu : ${participant}`));
                }

                if (settings.autostatusreact) {
                    const delay = Math.floor(Math.random() * (3000 - 1000 + 1)) + 1000;
                    setTimeout(async () => {
                        try {
                            await sock.sendMessage('status@broadcast', { 
                                react: { text: '👾', key: msg.key } 
                            }, { statusJidList: [participant] });
                        } catch (reactErr) {}
                    }, delay); 
                }
            } catch (statusErr) {
                console.error(chalk.yellow(`[𝐒𝐓𝐀𝐓𝐔𝐒 𝐄𝐑𝐑𝐎𝐑] ${statusErr.message} (𝐁𝐨𝐭 𝐜𝐨𝐧𝐭𝐢𝐧𝐮𝐞 
                )`));
            }
            return;
        }

        if (m.type === 'notify') {
           const settings = getSettings();
           const chatId = msg.key.remoteJid;

           if (settings.autotyping) {
               await sock.sendPresenceUpdate('composing', chatId);
               setTimeout(() => sock.sendPresenceUpdate('paused', chatId), 5000);
           } else if (settings.autorecord) {
               await sock.sendPresenceUpdate('recording', chatId);
               setTimeout(() => sock.sendPresenceUpdate('paused', chatId), 5000);
           }
            
            await monitorMute(sock, msg);
            await monitorMessage(sock, m);
            await messageHandler(sock, m);

        }
    });

    // 👥 GESTION DES GROUPES (Promote/Demote/Welcome)
    sock.ev.on('group-participants.update', async (update) => {
        await monitorGroupUpdate(sock, update);
    });

    return sock;
}

module.exports = { connectToWhatsApp };