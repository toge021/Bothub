// 🚀 𝐓𝐚𝐭𝐭𝐨𝐬-𝐗 - 𝗽𝗼𝗶𝗻𝘁 𝗱'𝗲𝗻𝘁𝗿𝗲́ 

const { connectToWhatsApp } = require('./nexus/client');
const { loadPlugins } = require('./nexus/handler');
const config = require('./config');

async function start() {
    try {
        console.log(`🤖 𝐃𝐞́𝐦𝐚𝐫𝐫𝐚𝐠𝐞 𝐝𝐞 ${config.botName}...`);
        
        // 1. Charger les plugins
        loadPlugins();

        // 2. Se connecter
        await connectToWhatsApp();

    } catch (e) {
        console.error("𝐄𝐫𝐫𝐞𝐮𝐫 𝐜𝐫𝐢𝐭𝐢𝐪𝐮𝐞:", e);
    }
}

start();