const { t } = require('../../lib/language');

module.exports = {
  name: 'ping',
  aliases: ['speed'],
  category: 'misc',
  description: 'Affiche la latence du bot',
  usage: '.ping',

  groupOnly: false,
  ownerOnly: false,
  adminOnly: false,
  newsletterShow: true,

  execute: async (client, message, args, msgOptions) => {
    const start = Date.now();

    // ♟ Réaction
    await client.sendMessage(message.key.remoteJid, {
      react: { text: "♟", key: message.key }
    });

    const end = Date.now();
    const latency = end - start;

    const caption = `
┃-ّْ͢⸙┃╔┅┅┅┅┅┅┅┅┅┅┅┅┅┅❍  ❍┅╗
┃-ّْ͢⸙┃┊      🕷 *𝐩𝐢𝐧𝐠 𝐬𝐭𝐚𝐭𝐮𝐭* 🕷
┃-ّْ͢⸙┃╚┅❍  ❍┅┅┅┅┅┅┅┅┅┅┅┅┅┅╝
┃-ّْ͢⸙┃ └‣ 𝐋𝐚𝐭𝐞𝐧𝐜𝐲 : ${latency} 𝐦𝐬
┃-ّْ͢⸙┃ └‣ ${t('misc.latency', { ms: latency })}
`;

    await client.sendMessage(
      message.key.remoteJid,
      {
        text: caption.trim(),
        ...msgOptions
      },
      { quoted: message }
    );
  }
};