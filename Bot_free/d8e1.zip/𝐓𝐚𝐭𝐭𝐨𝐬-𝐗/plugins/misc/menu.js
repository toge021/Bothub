// 📜 Plugin: MENU (Style modifié seulement)

const fs = require('fs');
const path = require('path');
const config = require('../../config');
const { getSettings } = require('../../lib/database');
const { styleText, formatUptime } = require('../../lib/functions');
const { t } = require('../../lib/language');

const MENU_IMAGES = [
    "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
    "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
    "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
    "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg",
    "https://i.ibb.co/2JnvtJf/7f6266744ea1.jpg",
    "https://i.ibb.co/kgxm9w8N/5bd59cc4db32.jpg",
    "https://i.ibb.co/QF34Dyc9/199932bcd52d.jpg"
];

function box(title, body = '') {
    return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸            ⌬
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

module.exports = {
    name: 'menu',
    aliases: ['help', 'list'],
    category: 'misc',
    description: 'Affiche le menu stylisé',
    usage: '.menu',

    groupOnly: false,
    ownerOnly: false,
    adminOnly: false,
    newsletterShow: true,

    execute: async (client, message, args, msgOptions) => {
        await client.sendMessage(message.key.remoteJid, {
            react: { text: "👾", key: message.key }
        });

        const settings = getSettings();
        const prefix = settings.prefix || config.prefix;
        const botName = settings.botName || config.botName;
        const lang = settings.lang || config.defaultLang;
        const username = message.pushName || "Utilisateur";

        const randomImage =
            MENU_IMAGES[Math.floor(Math.random() * MENU_IMAGES.length)];

        const pluginsDir = path.join(__dirname, '../../plugins');
        const categories = fs.readdirSync(pluginsDir);

        const greeting = lang === 'fr'
            ? t('menu.greet_fr')
            : t('menu.greet_en');

        let pluginCount = 0;

        categories.forEach(category => {
            const catPath = path.join(pluginsDir, category);

            if (fs.existsSync(catPath) && fs.lstatSync(catPath).isDirectory()) {
                const files = fs.readdirSync(catPath).filter(file => file.endsWith('.js'));

                files.forEach(file => {
                    try {
                        const pluginModule = require(path.join(catPath, file));
                        const commands = Array.isArray(pluginModule) ? pluginModule : [pluginModule];
                        pluginCount += commands.filter(cmd => cmd.name).length;
                    } catch {}
                });
            }
        });

        let caption = box(
            `*${botName}*`,
            `┃❐┃ ✧➤ *${styleText(greeting)}* : ${username}
┃❐┃ ✧➤ *${styleText(t('menu.uptime'))}* : ${formatUptime(process.uptime())}
┃❐┃ ✧➤ *${styleText(t('menu.prefix'))}* : ${prefix}
┃❐┃ ✧➤ *PLUGINS* : ${pluginCount}`
        );

        categories.forEach(category => {
            const catPath = path.join(pluginsDir, category);

            if (fs.existsSync(catPath) && fs.lstatSync(catPath).isDirectory()) {
                const files = fs.readdirSync(catPath).filter(file => file.endsWith('.js'));

                if (files.length > 0) {
                    let section = '';

                    files.forEach(file => {
                        try {
                            const pluginModule = require(path.join(catPath, file));
                            const commands = Array.isArray(pluginModule)
                                ? pluginModule
                                : [pluginModule];

                            commands.forEach(plugin => {
                                if (plugin.name) {
                                    section += `┃❐┃ ✧➤ ${prefix}${styleText(plugin.name)}\n`;
                                }
                            });
                        } catch {}
                    });

                    caption += `\n\n` + box(`*${styleText(category)}*`, section.trim());
                }
            }
        });

        caption += `\n\n` + box(
            '𝐓𝐚𝐭𝐭𝐨𝐬-𝐗',
            `┃❐┃ ✧➤ ⚡ Powered By Tattos-X ⚡`
        );

        // 📷 Envoi menu
        await client.sendMessage(
            message.key.remoteJid,
            {
                image: { url: randomImage },
                caption: caption.trim(),
                ...msgOptions
            },
            { quoted: null }
        );

        // 🎵 Audio après menu
        await client.sendMessage(
            message.key.remoteJid,
            {
                audio: { url: "https://files.catbox.moe/6wxh07.mpeg" },
                mimetype: "audio/mpeg",
                ptt: false,
                ...msgOptions
            },
            { quoted: null }
        );
    }
};