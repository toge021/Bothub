const axios = require("axios");

const TGS_IMAGES = [
    "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
    "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
    "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
    "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg"
];

function randomImage() {
    return TGS_IMAGES[Math.floor(Math.random() * TGS_IMAGES.length)];
}

function box(title, body = "") {
    return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸 
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

module.exports = {
    name: "tgsticker",
    aliases: ["tgs"],
    category: "tools",
    description: "Télécharge tous les stickers Telegram",
    usage: ".tgsticker https://t.me/addstickers/PackName",
    newsletterShow: true,

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        const url = args[0];

        const contextInfo = {
            forwardingScore: 999,
            isForwarded: true,
            forwardedNewsletterMessageInfo: {
                newsletterJid: "120363408842235507@newsletter",
                newsletterName: "𝐓𝐚𝐭𝐭𝐨𝐬-𝐗",
                serverMessageId: 1
            }
        };

        if (!url) {
            return sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "TGSTICKER",
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Exemple :
┃❐┃ ✧➤ .tgsticker https://t.me/addstickers/PackName`
                ),
                contextInfo
            }, { quoted: msg });
        }

        // 🔥 Support plusieurs formats Telegram
        const match = url.match(
            /(?:addstickers\/|telegram\.me\/addstickers\/|t\.me\/addstickers\/)([^/?]+)/i
        );

        if (!match) {
            return sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "TGSTICKER",
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Lien invalide.`
                ),
                contextInfo
            }, { quoted: msg });
        }

        const packName = match[1];

        try {
            if (!process.env.TG_TOKEN) {
                return sock.sendMessage(from, {
                    image: { url: randomImage() },
                    caption: box(
                        "TGSTICKER",
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ TG_TOKEN manquant dans .env`
                    ),
                    contextInfo
                }, { quoted: msg });
            }

            const { data } = await axios.get(
                `https://api.telegram.org/bot${process.env.TG_TOKEN}/getStickerSet?name=${packName}`
            );

            if (!data.ok) {
                return sock.sendMessage(from, {
                    image: { url: randomImage() },
                    caption: box(
                        "TGSTICKER",
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Pack introuvable.`
                    ),
                    contextInfo
                }, { quoted: msg });
            }

            const stickers = data.result.stickers;

            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "TGSTICKER",
                    `┃❐┃ ✧➤ PACK : ${packName}
┃❐┃ ✧➤ TOTAL : ${stickers.length}
┃❐┃ ✧➤ STATUS : Download...`
                ),
                contextInfo
            }, { quoted: msg });

            let success = 0;
            let failed = 0;

            // 🔥 Télécharge TOUS les stickers
            for (const sticker of stickers) {
                try {
                    const fileId = sticker.file_id;

                    const fileRes = await axios.get(
                        `https://api.telegram.org/bot${process.env.TG_TOKEN}/getFile?file_id=${fileId}`
                    );

                    const filePath = fileRes.data.result.file_path;

                    const fileUrl =
                        `https://api.telegram.org/file/bot${process.env.TG_TOKEN}/${filePath}`;

                    const buffer = await axios.get(fileUrl, {
                        responseType: "arraybuffer",
                        timeout: 30000
                    });

                    await sock.sendMessage(from, {
                        sticker: buffer.data,
                        contextInfo
                    }, { quoted: msg });

                    success++;

                    // petite pause anti flood
                    await new Promise(r => setTimeout(r, 400));

                } catch (e) {
                    failed++;
                    console.log("Sticker Skip:", e.message);
                }
            }

            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "SUCCESS",
                    `┃❐┃ ✧➤ SENT : ${success}
┃❐┃ ✧➤ FAILED : ${failed}
┃❐┃ ✧➤ TOTAL : ${stickers.length}`
                ),
                contextInfo
            }, { quoted: msg });

            await sock.sendMessage(from, {
                react: { text: "✅", key: msg.key }
            });

        } catch (e) {
            console.log("TG Sticker Error:", e.message);

            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "TGSTICKER",
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Erreur téléchargement.`
                ),
                contextInfo
            }, { quoted: msg });

            await sock.sendMessage(from, {
                react: { text: "❌", key: msg.key }
            });
        }
    }
};