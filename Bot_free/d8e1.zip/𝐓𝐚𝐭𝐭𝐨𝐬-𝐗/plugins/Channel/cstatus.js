const { downloadContentFromMessage } = require('gifted-baileys');

const CHANNEL_ID = "120363424639365907@newsletter";

module.exports = {
    name: 'cstatus',
    aliases: ['channel', 'newsletter'],
    category: 'owner',
    description: 'Publie texte/image/video dans la chaîne WhatsApp',
    usage: '.cstatus texte / répondre à média',

    ownerOnly: true,
    newsletterShow: true,

    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const targetMessage = quoted || message.message;

        if (!quoted && !args.length) {
            return client.sendMessage(from, {
                text: '⚠️ Utilise .cstatus texte\nou réponds à une image / vidéo.'
            }, { quoted: message });
        }

        await client.sendMessage(from, {
            react: { text: '⏳', key: message.key }
        });

        try {
            let content = {};

            // IMAGE
            if (targetMessage.imageMessage) {
                const stream = await downloadContentFromMessage(
                    targetMessage.imageMessage,
                    'image'
                );

                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                content = {
                    image: buffer,
                    caption:
                        targetMessage.imageMessage.caption ||
                        args.join(' ') ||
                        ''
                };
            }

            // VIDEO
            else if (targetMessage.videoMessage) {
                const stream = await downloadContentFromMessage(
                    targetMessage.videoMessage,
                    'video'
                );

                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                content = {
                    video: buffer,
                    caption:
                        targetMessage.videoMessage.caption ||
                        args.join(' ') ||
                        ''
                };
            }

            // TEXTE
            else {
                const text = quoted
                    ? (
                        quoted.conversation ||
                        quoted.extendedTextMessage?.text ||
                        args.join(' ')
                    )
                    : args.join(' ');

                content = { text };
            }

            // 🔥 Envoi dans la chaîne
            await client.sendMessage(CHANNEL_ID, content);

            await client.sendMessage(from, {
                react: { text: '✅', key: message.key }
            });

        } catch (e) {
            console.error(e);

            await client.sendMessage(from, {
                text: '❌ Erreur lors de la publication dans la chaîne.'
            }, { quoted: message });
        }
    }
};