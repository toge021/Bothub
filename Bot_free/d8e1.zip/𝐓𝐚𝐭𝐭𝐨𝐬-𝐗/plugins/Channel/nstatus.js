const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('gifted-baileys');

const DB = path.join(__dirname, '../../lib/newsletters.json');

function loadDB() {
    if (!fs.existsSync(DB)) {
        fs.writeFileSync(DB, JSON.stringify({ channels: [] }, null, 2));
    }
    return JSON.parse(fs.readFileSync(DB));
}

function saveDB(data) {
    fs.writeFileSync(DB, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'nstatus',
    aliases: ['newsletterstatus'],
    category: 'owner',
    ownerOnly: true,
    newsletterShow: true,

    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const db = loadDB();

        const sub = args[0]?.toLowerCase();

        // ADD
        if (sub === 'add') {
            const jid = args[1];
            if (!jid || !jid.includes('@newsletter')) {
                return client.sendMessage(from, {
                    text: '⚠️ Exemple:\n.nstatus add 1203xxxx@newsletter'
                }, { quoted: message });
            }

            if (!db.channels.includes(jid)) {
                db.channels.push(jid);
                saveDB(db);
            }

            return client.sendMessage(from, {
                text: '✅ Chaîne ajoutée.'
            }, { quoted: message });
        }

        // DEL
        if (sub === 'del') {
            const jid = args[1];
            db.channels = db.channels.filter(x => x !== jid);
            saveDB(db);

            return client.sendMessage(from, {
                text: '✅ Chaîne retirée.'
            }, { quoted: message });
        }

        // LIST
        if (sub === 'list') {
            return client.sendMessage(from, {
                text: db.channels.length
                    ? db.channels.join('\n')
                    : 'Aucune chaîne.'
            }, { quoted: message });
        }

        // POST
        if (!db.channels.length) {
            return client.sendMessage(from, {
                text: '⚠️ Aucune chaîne ajoutée.'
            }, { quoted: message });
        }

        let content = {};
        const target = quoted || message.message;

        try {
            if (target.imageMessage) {
                const stream = await downloadContentFromMessage(target.imageMessage, 'image');
                let buffer = Buffer.from([]);
                for await (const c of stream) buffer = Buffer.concat([buffer, c]);

                content = {
                    image: buffer,
                    caption: target.imageMessage.caption || args.join(' ')
                };
            }

            else if (target.videoMessage) {
                const stream = await downloadContentFromMessage(target.videoMessage, 'video');
                let buffer = Buffer.from([]);
                for await (const c of stream) buffer = Buffer.concat([buffer, c]);

                content = {
                    video: buffer,
                    caption: target.videoMessage.caption || args.join(' ')
                };
            }

            else {
                content = {
                    text: quoted
                        ? (quoted.conversation || quoted.extendedTextMessage?.text)
                        : args.join(' ')
                };
            }

            for (const jid of db.channels) {
                await client.sendMessage(jid, content).catch(() => {});
            }

            await client.sendMessage(from, {
                text: '✅ Publié dans toutes les chaînes.'
            }, { quoted: message });

        } catch (e) {
            console.log(e);
            await client.sendMessage(from, {
                text: '❌ Erreur.'
            }, { quoted: message });
        }
    }
};