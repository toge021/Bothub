const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('gifted-baileys');

const DB = path.join(__dirname, '../../lib/channels.json');

function loadDB() {
    if (!fs.existsSync(DB)) {
        fs.writeFileSync(DB, JSON.stringify({ channels: [] }, null, 2));
    }
    return JSON.parse(fs.readFileSync(DB));
}

function saveDB(data) {
    fs.writeFileSync(DB, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'chstatus',
    aliases: ['cstatus2', 'nstatus2'],
    category: 'Channel',
    description: 'Publie dans une ou plusieurs chaînes WhatsApp',
    usage: '.chstatus add/del/list/post',

    ownerOnly: true,
    newsletterShow: true,

    async execute(client, message, args) {
        const from = message.key.remoteJid;
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const db = loadDB();

        const sub = args[0]?.toLowerCase();

        // ================= ADD =================
        if (sub === 'add') {
            const jid = args[1];

            if (!jid || !jid.includes('@newsletter')) {
                return client.sendMessage(from, {
                    text: '⚠️ Exemple:\n.channelstatus add 120363xxxx@newsletter'
                }, { quoted: message });
            }

            if (!db.channels.includes(jid)) {
                db.channels.push(jid);
                saveDB(db);
            }

            return client.sendMessage(from, {
                text: '✅ Chaîne ajoutée avec succès.'
            }, { quoted: message });
        }

        // ================= DEL =================
        if (sub === 'del') {
            const jid = args[1];
            db.channels = db.channels.filter(x => x !== jid);
            saveDB(db);

            return client.sendMessage(from, {
                text: '✅ Chaîne supprimée.'
            }, { quoted: message });
        }

        // ================= LIST =================
        if (sub === 'list') {
            const txt = db.channels.length
                ? db.channels.map((x, i) => `${i + 1}. ${x}`).join('\n')
                : 'Aucune chaîne enregistrée.';

            return client.sendMessage(from, {
                text: txt
            }, { quoted: message });
        }

        // ================= POST =================
        if (!db.channels.length) {
            return client.sendMessage(from, {
                text: '⚠️ Aucune chaîne ajoutée.\nUtilise: .channelstatus add 1203xxxx@newsletter'
            }, { quoted: message });
        }

        let content = {};
        const target = quoted || message.message;

        try {
            // IMAGE
            if (target.imageMessage) {
                const stream = await downloadContentFromMessage(target.imageMessage, 'image');
                let buffer = Buffer.from([]);

                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                content = {
                    image: buffer,
                    caption: target.imageMessage.caption || args.join(' ')
                };
            }

            // VIDEO
            else if (target.videoMessage) {
                const stream = await downloadContentFromMessage(target.videoMessage, 'video');
                let buffer = Buffer.from([]);

                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                content = {
                    video: buffer,
                    caption: target.videoMessage.caption || args.join(' ')
                };
            }

            // AUDIO
            else if (target.audioMessage) {
                const stream = await downloadContentFromMessage(target.audioMessage, 'audio');
                let buffer = Buffer.from([]);

                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                content = {
                    audio: buffer,
                    mimetype: 'audio/mp4',
                    ptt: false
                };
            }

            // TEXTE
            else {
                const text = quoted
                    ? (quoted.conversation || quoted.extendedTextMessage?.text || '')
                    : args.join(' ');

                if (!text) {
                    return client.sendMessage(from, {
                        text: '⚠️ Mets un texte ou réponds à un média.'
                    }, { quoted: message });
                }

                content = { text };
            }

            // 🔥 Envoi dans toutes les chaînes
            let sent = 0;

            for (const jid of db.channels) {
                try {
                    await client.sendMessage(jid, content);
                    sent++;
                } catch (e) {
                    console.log("CHANNEL ERROR:", jid, e.message);
                }
            }

            return client.sendMessage(from, {
                text: `✅ Publication envoyée dans ${sent} chaîne(s).`
            }, { quoted: message });

        } catch (e) {
            console.error(e);

            return client.sendMessage(from, {
                text: '❌ Erreur lors de la publication.'
            }, { quoted: message });
        }
    }
};