module.exports = {
    name: "idch",
    newsletterShow: true,

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid

        const IMAGES = [
            "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
            "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
            "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
            "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg"
        ]

        const randomImage = () =>
            IMAGES[Math.floor(Math.random() * IMAGES.length)]

        const box = (title, body = "") => `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸   
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim()

        try {
            const link = args[0]?.trim()

            // ❌ CHECK
            if (!link || !link.includes("whatsapp.com/channel/")) {
                return sock.sendMessage(from, {
                    image: { url: randomImage() },
                    caption: box(
                        "ID CHANNEL",
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Donne un lien valide
┃❐┃ ✧➤ Ex : .idch https://whatsapp.com/channel/xxxx`
                    )
                }, { quoted: msg })
            }

            // 🔥 EXTRACTION SAFE
            const parts = link.split("/channel/")
            const code = parts[1]?.split("?")[0]

            if (!code) {
                return sock.sendMessage(from, {
                    image: { url: randomImage() },
                    caption: box(
                        "ID CHANNEL",
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Lien invalide`
                    )
                }, { quoted: msg })
            }

            // 🔥 FETCH CHANNEL
            const res = await sock.newsletterMetadata("invite", code)

            if (!res) throw new Error("No data")

            const id = res.id
            const name = res.name || "Unknown"

            // ✅ SUCCESS
            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "CHANNEL INFO",
                    `┃❐┃ ✧➤ NAME : ${name}
┃❐┃ ✧➤ ID : ${id}`
                )
            }, { quoted: msg })

        } catch (e) {
            console.log("IDCH ERROR:", e?.message || e)

            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "ID CHANNEL",
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Impossible de récupérer
┃❐┃ ✧➤ Lien privé ou invalide`
                )
            }, { quoted: msg })
        }
    }
}