const fs = require("fs");
const path = require("path");

const {
    downloadVideoUniversalAlmighty,
    searchYouTubeVideo,
    searchAlternativeVideo
} = require("../../utils/downloader");

const CACHE_DIR = "./cache";

if (!fs.existsSync(CACHE_DIR)) fs.mkdirSync(CACHE_DIR);

// 🔥 Images style
const PLAY_IMAGES = [
    "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
    "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
    "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
    "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg"
];

function randomImage() {
    return PLAY_IMAGES[Math.floor(Math.random() * PLAY_IMAGES.length)];
}

function box(title, body = "") {
    return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸  
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

module.exports = {
    name: "play2",
    category: "download",
    newsletterShow: true,

    async execute(sock, msg, args) {
        const from = msg.key.remoteJid;
        const query = args.join(" ").trim();

        if (!query) {
            return sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "PLAY",
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Exemple : .play alan walker faded`
                )
            }, { quoted: msg });
        }

        await sock.sendMessage(from, {
            react: { text: "🔍", key: msg.key }
        });

        try {
            let downloadResult;
            let sourceName = "YouTube";

            // 🔥 SEARCH
            const ytUrl = await searchYouTubeVideo(query);

            if (!ytUrl) throw new Error("Aucune vidéo trouvée");

            downloadResult = await downloadVideoUniversalAlmighty(ytUrl);

            if (!downloadResult.success) {
                const alt = await searchAlternativeVideo(query);

                if (alt) {
                    downloadResult = await downloadVideoUniversalAlmighty(alt.url);
                    sourceName = alt.source;
                }
            }

            if (!downloadResult.success) {
                throw new Error("Download failed");
            }

            const fileName = `play_${Buffer.from(query).toString("hex").slice(0, 10)}.mp4`;
            const filePath = path.join(CACHE_DIR, fileName);

            // 🔥 CACHE
            if (!fs.existsSync(filePath)) {
                fs.copyFileSync(downloadResult.path, filePath);
            }

            const sizeMB = (downloadResult.size / 1024 / 1024).toFixed(2);

            // 🔥 Message préparation
            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "PLAY",
                    `┃❐┃ ✧➤ TITLE : ${query}
┃❐┃ ✧➤ SOURCE : ${sourceName}
┃❐┃ ✧➤ SIZE : ${sizeMB} MB
┃❐┃ ✧➤ STATUS : READY`
                )
            }, { quoted: msg });

            const buffer = fs.readFileSync(filePath);

            // 🔥 AUDIO
            await sock.sendMessage(from, {
                audio: buffer,
                mimetype: "audio/mpeg",
                ptt: false
            }, { quoted: msg });

            // 🔥 VIDEO
            await sock.sendMessage(from, {
                video: buffer,
                caption: box(
                    "VIDEO",
                    `┃❐┃ ✧➤ ${query}
┃❐┃ ✧➤ Powered By Tattos-X`
                )
            }, { quoted: msg });

            await sock.sendMessage(from, {
                react: { text: "✅", key: msg.key }
            });

        } catch (err) {
            console.error(err);

            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    "PLAY",
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ ${err.message}`
                )
            }, { quoted: msg });

            await sock.sendMessage(from, {
                react: { text: "❌", key: msg.key }
            });
        }
    }
};