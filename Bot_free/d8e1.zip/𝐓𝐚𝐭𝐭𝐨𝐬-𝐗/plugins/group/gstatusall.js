const { downloadContentFromMessage } = require('gifted-baileys');

module.exports = {
    name: 'gstatusall',
    aliases: ['bgall'],
    category: 'group',
    description: 'Envoie un statut dans tous les groupes',
    usage: '.gstatus texte / répondre média',

    ownerOnly: true,
    newsletterShow: true,

    execute: async (client, message, args) => {
        const from = message.key.remoteJid;
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const targetMessage = quoted || message.message;

        await client.sendMessage(from, {
            react: { text: '⏳', key: message.key }
        });

        try {
            let statusContent = {};

            if (targetMessage.imageMessage) {
                const stream = await downloadContentFromMessage(targetMessage.imageMessage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

                statusContent = {
                    image: buffer,
                    caption: targetMessage.imageMessage.caption || args.join(' ')
                };
            }

            else if (targetMessage.videoMessage) {
                const stream = await downloadContentFromMessage(targetMessage.videoMessage, 'video');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

                statusContent = {
                    video: buffer,
                    caption: targetMessage.videoMessage.caption || args.join(' ')
                };
            }

            else if (targetMessage.audioMessage) {
                const stream = await downloadContentFromMessage(targetMessage.audioMessage, 'audio');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) buffer = Buffer.concat([buffer, chunk]);

                statusContent = {
                    audio: buffer,
                    mimetype: 'audio/mp4',
                    ptt: true
                };
            }

            else {
                statusContent = {
                    text: quoted
                        ? (quoted.conversation || quoted.extendedTextMessage?.text)
                        : args.join(' ')
                };
            }

            const groups = await client.groupFetchAllParticipating();
            const ids = Object.keys(groups);

            for (const jid of ids) {
                await client.sendMessage(jid, {
                    groupStatusMessage: statusContent
                }).catch(() => {});
            }

            await client.sendMessage(from, {
                react: { text: '✅', key: message.key }
            });

        } catch (e) {
            console.error(e);

            await client.sendMessage(from, {
                text: '❌ Erreur.'
            }, { quoted: message });
        }
    }
};