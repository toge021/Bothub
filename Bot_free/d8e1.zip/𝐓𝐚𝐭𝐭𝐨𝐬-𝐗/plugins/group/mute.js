const fs = require("fs");

const MUTE_IMAGES = [
    "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
    "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
    "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
    "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg"
];

function randomImage() {
    return MUTE_IMAGES[Math.floor(Math.random() * MUTE_IMAGES.length)];
}

function box(title, body = "") {
return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬ 🕸 ${title} 🕸 ⌬
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

function ctx(jid){
return {
forwardingScore: 999,
isForwarded: true,
forwardedNewsletterMessageInfo: {
newsletterJid: "120363424639365907@newsletter",
newsletterName: "𝐓𝐚𝐭𝐭𝐨𝐬-𝐗",
serverMessageId: 1
},
businessMessageForwardInfo: {
businessOwnerJid: jid
}
};
}

function parseDuration(input){
if(!input) return null;
const m = input.toLowerCase().match(/^(\d+)(s|m|h|d)$/);
if(!m) return null;

const n = parseInt(m[1]);
const u = m[2];

return {
s: n*1000,
m: n*60000,
h: n*3600000,
d: n*86400000
}[u];
}

module.exports = {
name: "mute",
aliases: ["silence"],
groupOnly: true,
adminOnly: true,
newsletterShow: true,

async execute(sock, msg, args){

const from = msg.key.remoteJid;
const file = "./database/muted.json";

let data = {};
try{
if(fs.existsSync(file)){
data = JSON.parse(fs.readFileSync(file));
}
}catch{
data = {};
}

if(!data[from]) data[from] = {};

const metadata = await sock.groupMetadata(from);

if(!args[0]){
return sock.sendMessage(from,{
image:{url:randomImage()},
caption:box("MUTE PANEL",
`┃❐┃ ✧➤ .mute @user 30m
┃❐┃ ✧➤ .mute all 1h
┃❐┃ ✧➤ .mute admin 10m
┃❐┃ ✧➤ .mute off @user
┃❐┃ ✧➤ .mute list`),
contextInfo: ctx(from)
},{quoted:msg});
}

if(args[0] === "list"){
let txt = "";
let mentions = [];

for(let user in data[from]){
txt += `┃❐┃ ✧➤ @${user.split("@")[0]}\n`;
mentions.push(user);
}

if(!txt) txt = "┃❐┃ ✧➤ Aucun mute.";

return sock.sendMessage(from,{
image:{url:randomImage()},
caption:box("MUTE LIST",txt),
mentions,
contextInfo: ctx(from)
},{quoted:msg});
}

if(args[0] === "off"){
const user =
msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0];

if(!user){
return sock.sendMessage(from,{
image:{url:randomImage()},
caption:box("UNMUTE","┃❐┃ ✧➤ Mentionne la cible."),
contextInfo: ctx(from)
},{quoted:msg});
}

delete data[from][user];
fs.writeFileSync(file,JSON.stringify(data,null,2));

return sock.sendMessage(from,{
image:{url:randomImage()},
caption:box("UNMUTE",`┃❐┃ ✧➤ @${user.split("@")[0]} libéré.`),
mentions:[user],
contextInfo: ctx(from)
},{quoted:msg});
}

let duration = args[1] || "5m";
let ms = parseDuration(duration);

if(!ms){
return sock.sendMessage(from,{
image:{url:randomImage()},
caption:box("MUTE","┃❐┃ ✧➤ Temps invalide."),
contextInfo: ctx(from)
},{quoted:msg});
}

const expire = Date.now()+ms;

if(args[0] === "all"){
metadata.participants.forEach(p=>{
if(!p.admin) data[from][p.id]=expire;
});

fs.writeFileSync(file,JSON.stringify(data,null,2));

return sock.sendMessage(from,{
image:{url:randomImage()},
caption:box("MUTE ALL",`┃❐┃ ✧➤ Groupe mute ${duration}`),
contextInfo: ctx(from)
},{quoted:msg});
}

let user =
msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] ||
msg.message?.extendedTextMessage?.contextInfo?.participant ||
(args[0].replace(/[^0-9]/g,"")+"@s.whatsapp.net");

if(!user){
return sock.sendMessage(from,{
image:{url:randomImage()},
caption:box("MUTE","┃❐┃ ✧➤ Cible introuvable."),
contextInfo: ctx(from)
},{quoted:msg});
}

data[from][user]=expire;
fs.writeFileSync(file,JSON.stringify(data,null,2));

return sock.sendMessage(from,{
image:{url:randomImage()},
caption:box("MUTE SUCCESS",
`┃❐┃ ✧➤ @${user.split("@")[0]} mute
┃❐┃ ✧➤ Durée : ${duration}`),
mentions:[user],
contextInfo: ctx(from)
},{quoted:msg});

}
};