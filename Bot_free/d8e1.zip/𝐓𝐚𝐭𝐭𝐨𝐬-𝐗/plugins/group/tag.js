// /home/container/plugins/group/tag.js

const fs = require('fs');
const { createWriteStream } = require('fs');
const path = require('path');
const ffmpeg = require('fluent-ffmpeg');
const configManager = require('../../lib/tagConfig');
const { OWNER_NAME } = require('../../config');
const { downloadMediaMessage } = require('gifted-baileys');

const TAG_IMAGES = [
    "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
    "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
    "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
    "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg"
];

function randomImage() {
    return TAG_IMAGES[Math.floor(Math.random() * TAG_IMAGES.length)];
}

function box(title, body = '') {
    return `
â•­ââ•®â•­â”â”â”â•â§‰ â§‰â•â”â”â”â•â§‰ â§‰â•â”â”â•®
â”ƒââ”ƒâŒ¬            ðŸ•¸ ${title} ðŸ•¸            âŒ¬
â”ƒââ”ƒâ•°â”â”â”â•â§‰ â§‰â•â”â”â”â•â§‰ â§‰â•â”â”â•¯
${body}
â•°ââ•¯ âœ§âž¤`.trim();
}

function newsletterContext(jid, old = {}) {
    return {
        ...(old || {}),
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363424639365907@newsletter",
            newsletterName: "ð“ðšð­ð­ð¨ð¬-ð—",
            serverMessageId: 1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: jid
        }
    };
}

// ======================= TAGALL =======================

async function tagall(message, client) {
    const remoteJid = message.key.remoteJid;

    if (!remoteJid.includes('@g.us')) {
        return client.sendMessage(remoteJid, {
            image: { url: randomImage() },
            caption: box('TAGALL', `â”ƒââ”ƒ âœ§âž¤ ERROR
â”ƒââ”ƒ âœ§âž¤ Groupe uniquement.`),
            contextInfo: newsletterContext(remoteJid)
        });
    }

    try {
        const metadata = await client.groupMetadata(remoteJid);
        const participants = metadata.participants;
        const mentions = participants.map(p => p.id);

        let list = '';
        for (const p of participants) {
            list += `â”ƒââ”ƒ âœ§âž¤ @${p.id.split('@')[0]}\n`;
        }

        const caption = box(
            'TAGALL',
            `â”ƒââ”ƒ âœ§âž¤ GROUP : ${metadata.subject}
â”ƒââ”ƒ âœ§âž¤ MEMBERS : ${participants.length}
â”ƒââ”ƒ âœ§âž¤ LIST :
${list}
â”ƒââ”ƒ âœ§âž¤ OWNER : ${OWNER_NAME || 'Tattos-X'}`
        );

        await client.sendMessage(remoteJid, {
            image: { url: randomImage() },
            caption,
            mentions,
            contextInfo: newsletterContext(remoteJid)
        });

    } catch (e) {
        console.log(e);
    }
}

// ======================= TAGADMIN =======================

async function tagadmin(message, client) {
    const remoteJid = message.key.remoteJid;
    const botNumber = client.user.id.split(':')[0] + '@s.whatsapp.net';

    if (!remoteJid.includes('@g.us')) {
        return client.sendMessage(remoteJid, {
            image: { url: randomImage() },
            caption: box('TAGADMIN', `â”ƒââ”ƒ âœ§âž¤ ERROR
â”ƒââ”ƒ âœ§âž¤ Groupe uniquement.`),
            contextInfo: newsletterContext(remoteJid)
        });
    }

    try {
        const metadata = await client.groupMetadata(remoteJid);

        const admins = metadata.participants.filter(
            p => p.admin && p.id !== botNumber
        );

        if (!admins.length) {
            return client.sendMessage(remoteJid, {
                image: { url: randomImage() },
                caption: box('TAGADMIN', `â”ƒââ”ƒ âœ§âž¤ INFO
â”ƒââ”ƒ âœ§âž¤ Aucun admin trouvÃ©.`),
                contextInfo: newsletterContext(remoteJid)
            });
        }

        const mentions = admins.map(a => a.id);

        let list = '';
        for (const a of admins) {
            list += `â”ƒââ”ƒ âœ§âž¤ @${a.id.split('@')[0]}\n`;
        }

        await client.sendMessage(remoteJid, {
            image: { url: randomImage() },
            caption: box('TAGADMIN', list),
            mentions,
            contextInfo: newsletterContext(remoteJid)
        });

    } catch (e) {
        console.log(e);
    }
}

// ======================= AUDIO =======================

async function convertToPTT(inputPath, outputPath) {
    return new Promise((resolve, reject) => {
        ffmpeg(inputPath)
            .audioCodec("libopus")
            .format("ogg")
            .audioBitrate("48k")
            .audioChannels(1)
            .save(outputPath)
            .on("end", () => resolve(outputPath))
            .on("error", reject);
    });
}

async function respond(message, client, lid) {
    const number = client.user.id.split(":")[0];
    const remoteJid = message.key.remoteJid;

    const body =
        message.message?.extendedTextMessage?.text ||
        message.message?.conversation ||
        "";

    if (!configManager.config?.users[number]) return;

    const tagRespond = configManager.config.users[number]?.response;
    const lidNumber = lid[0] ? lid[0].split("@")[0] : "";

    if (
        !message.key.fromMe &&
        tagRespond &&
        (body.includes(`@${number}`) || body.includes("@" + lidNumber))
    ) {
        const inputAudio =
            configManager.config.users[number]?.tagAudioPath || "tag.mp3";

        const outputAudio = path.join("temp", `tag_${Date.now()}.ogg`);

        if (!fs.existsSync("temp")) fs.mkdirSync("temp");

        const convertedPath = await convertToPTT(inputAudio, outputAudio);

        await client.sendMessage(remoteJid, {
            audio: { url: convertedPath },
            mimetype: "audio/ogg; codecs=opus",
            ptt: false,
            contextInfo: newsletterContext(remoteJid, {
                stanzaId: message.key.id,
                participant: message.key.participant || remoteJid,
                quotedMessage: message.message
            })
        });

        fs.unlinkSync(convertedPath);
    }
}

// ======================= SETTAG =======================

async function settag(message, client) {
    const number = client.user.id.split(':')[0];
    const remoteJid = message.key.remoteJid;

    try {
        const quotedMessage =
            message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quotedMessage || !quotedMessage.audioMessage) {
            return client.sendMessage(remoteJid, {
                image: { url: randomImage() },
                caption: box('SETTAG', `â”ƒââ”ƒ âœ§âž¤ ERROR
â”ƒââ”ƒ âœ§âž¤ RÃ©pondez Ã  un audio.`),
                contextInfo: newsletterContext(remoteJid)
            });
        }

        const audio = await downloadMediaMessage(
            { message: quotedMessage },
            "stream"
        );

        const filePath = `${number}.mp3`;
        const writeStream = createWriteStream(filePath);
        audio.pipe(writeStream);

        configManager.config.users[number] =
            configManager.config.users[number] || {};

        configManager.config.users[number].tagAudioPath = filePath;
        configManager.save();

        await client.sendMessage(remoteJid, {
            image: { url: randomImage() },
            caption: box('SETTAG', `â”ƒââ”ƒ âœ§âž¤ SUCCESS
â”ƒââ”ƒ âœ§âž¤ Audio mis Ã  jour.`),
            contextInfo: newsletterContext(remoteJid)
        });

    } catch (e) {
        console.log(e);
    }
}

// ======================= TAGOPTION =======================

async function tagoption(message, client) {
    const number = client.user.id.split(':')[0];
    const remoteJid = message.key.remoteJid;

    const body =
        message.message?.conversation ||
        message.message?.extendedTextMessage?.text ||
        "";

    const args = body.slice(1).trim().split(/\s+/).slice(1);

    if (!configManager.config?.users[number]) return;

    try {
        const option = args.join(' ').toLowerCase();

        if (option.includes("on")) {
            configManager.config.users[number].response = true;
            configManager.save();

            return client.sendMessage(remoteJid, {
                image: { url: randomImage() },
                caption: box('TAGOPTION', `â”ƒââ”ƒ âœ§âž¤ STATUS
â”ƒââ”ƒ âœ§âž¤ ActivÃ©e.`),
                contextInfo: newsletterContext(remoteJid)
            });
        }

        if (option.includes("off")) {
            configManager.config.users[number].response = false;
            configManager.save();

            return client.sendMessage(remoteJid, {
                image: { url: randomImage() },
                caption: box('TAGOPTION', `â”ƒââ”ƒ âœ§âž¤ STATUS
â”ƒââ”ƒ âœ§âž¤ DÃ©sactivÃ©e.`),
                contextInfo: newsletterContext(remoteJid)
            });
        }

        return client.sendMessage(remoteJid, {
            image: { url: randomImage() },
            caption: box('TAGOPTION', `â”ƒââ”ƒ âœ§âž¤ INFO
â”ƒââ”ƒ âœ§âž¤ Choisissez on / off.`),
            contextInfo: newsletterContext(remoteJid)
        });

    } catch (e) {
        console.log(e);
    }
}

// ======================= TAG =======================

async function tag(message, client) {
    const remoteJid = message.key.remoteJid;

    if (!remoteJid.includes('@g.us')) {
        return client.sendMessage(remoteJid, {
            image: { url: randomImage() },
            caption: box('TAG', `â”ƒââ”ƒ âœ§âž¤ ERROR
â”ƒââ”ƒ âœ§âž¤ Groupe uniquement.`),
            contextInfo: newsletterContext(remoteJid)
        });
    }

    try {
        const metadata = await client.groupMetadata(remoteJid);
        const participants = metadata.participants.map(u => u.id);

        const quotedMessage =
            message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (quotedMessage) {
            const quotedText =
                quotedMessage.conversation ||
                quotedMessage.extendedTextMessage?.text ||
                "";

            const sticker = quotedMessage.stickerMessage;

            if (sticker) {
                return client.sendMessage(remoteJid, {
                    sticker,
                    mentions: participants,
                    contextInfo: newsletterContext(remoteJid)
                });
            }

            return client.sendMessage(remoteJid, {
                text: quotedText,
                mentions: participants,
                contextInfo: newsletterContext(remoteJid)
            });
        }

        const body =
            message.message?.conversation ||
            message.message?.extendedTextMessage?.text ||
            "";

        const text =
            body.slice(1).trim().split(/\s+/).slice(1).join(' ') ||
            participants.map(id => `@${id.split('@')[0]}`).join(' ');

        await client.sendMessage(remoteJid, {
            text,
            mentions: participants,
            contextInfo: newsletterContext(remoteJid)
        });

    } catch (e) {
        console.log(e);
    }
}

module.exports = [
    {
        name: 'tagall',
        aliases: ['everyone'],
        category: 'group',
        description: 'Tag tous les membres',
        groupOnly: true,
        adminOnly: true,
        newsletterShow: true,
        execute: async (client, message) => {
            await tagall(message, client);
        }
    },
    {
        name: 'tagadmin',
        aliases: ['admins'],
        category: 'group',
        description: 'Tag les admins',
        groupOnly: true,
        adminOnly: true,
        newsletterShow: true,
        execute: async (client, message) => {
            await tagadmin(message, client);
        }
    },
    {
        name: 'tag',
        aliases: [],
        category: 'group',
        description: 'Mention gÃ©nÃ©rale',
        groupOnly: true,
        adminOnly: true,
        newsletterShow: true,
        execute: async (client, message) => {
            await tag(message, client);
        }
    },
    {
        name: 'tagoption',
        aliases: [],
        category: 'group',
        description: 'Activer/DÃ©sactiver rÃ©ponse tag',
        groupOnly: false,
        adminOnly: false,
        newsletterShow: true,
        execute: async (client, message) => {
            await tagoption(message, client);
        }
    },
    {
        name: 'settag',
        aliases: [],
        category: 'group',
        description: 'DÃ©finir audio tag',
        groupOnly: false,
        adminOnly: false,
        newsletterShow: true,
        execute: async (client, message) => {
            await settag(message, client);
        }
    }
];