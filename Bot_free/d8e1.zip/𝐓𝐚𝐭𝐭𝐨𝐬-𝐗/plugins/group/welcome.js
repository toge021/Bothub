const { updateGroupSetting, getGroupSettings } = require('../../lib/database');
const { t } = require('../../lib/language');

const WELCOME_IMAGES = [
    "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
    "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
    "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
    "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg"
];

function randomImage() {
    return WELCOME_IMAGES[Math.floor(Math.random() * WELCOME_IMAGES.length)];
}

function box(title, body = '') {
    return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸            ⌬
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

function newsletterContext(jid, old = {}) {
    return {
        ...(old || {}),
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363424639365907@newsletter",
            newsletterName: "𝐓𝐚𝐭𝐭𝐨𝐬-𝐗",
            serverMessageId: 1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: jid
        }
    };
}

module.exports = [
    {
        name: 'welcome',
        aliases: [],
        category: 'group',
        description: 'Active/Désactive le message de bienvenue',
        usage: '.welcome <on/off>',
        groupOnly: true,
        adminOnly: true,
        newsletterShow: true,

        execute: async (client, message, args) => {
            const chatId = message.key.remoteJid;
            const setting = args[0]?.toLowerCase();
            const currentConfig = getGroupSettings(chatId);

            if (!setting) {
                return client.sendMessage(chatId, {
                    image: { url: randomImage() },
                    caption: box(
                        'WELCOME',
                        `┃❐┃ ✧➤ STATUS : ${currentConfig.welcome ? 'ON' : 'OFF'}
┃❐┃ ✧➤ USE : .welcome on/off`
                    ),
                    contextInfo: newsletterContext(chatId)
                }, { quoted: message });
            }

            if (setting === 'on') {
                updateGroupSetting(chatId, 'welcome', true);

                return client.sendMessage(chatId, {
                    image: { url: randomImage() },
                    caption: box(
                        'WELCOME',
                        `┃❐┃ ✧➤ SUCCESS
┃❐┃ ✧➤ Welcome activé.`
                    ),
                    contextInfo: newsletterContext(chatId)
                }, { quoted: message });
            }

            if (setting === 'off') {
                updateGroupSetting(chatId, 'welcome', false);

                return client.sendMessage(chatId, {
                    image: { url: randomImage() },
                    caption: box(
                        'WELCOME',
                        `┃❐┃ ✧➤ SUCCESS
┃❐┃ ✧➤ Welcome désactivé.`
                    ),
                    contextInfo: newsletterContext(chatId)
                }, { quoted: message });
            }
        }
    },

    {
        name: 'setwelcome',
        aliases: [],
        category: 'group',
        description: 'Configure le message de bienvenue',
        usage: '.setwelcome <message>',
        groupOnly: true,
        adminOnly: true,
        newsletterShow: true,

        execute: async (client, message, args) => {
            const chatId = message.key.remoteJid;
            const text = args.join(' ');

            if (!text) {
                return client.sendMessage(chatId, {
                    image: { url: randomImage() },
                    caption: box(
                        'SETWELCOME',
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Message manquant.`
                    ),
                    contextInfo: newsletterContext(chatId)
                }, { quoted: message });
            }

            updateGroupSetting(chatId, 'welcomeMessage', text);

            return client.sendMessage(chatId, {
                image: { url: randomImage() },
                caption: box(
                    'SETWELCOME',
                    `┃❐┃ ✧➤ SUCCESS
┃❐┃ ✧➤ Message mis à jour.`
                ),
                contextInfo: newsletterContext(chatId)
            }, { quoted: message });
        }
    },

    {
        name: 'welcome_event',
        aliases: [],
        category: 'hidden',
        hidden: true,
        newsletterShow: true,

        execute: async (client, update) => {
            const chatId = update.id;
            const config = getGroupSettings(chatId);

            if (!config.welcome) return;

            for (const user of update.participants) {
                if (update.action === 'add') {
                    let text = config.welcomeMessage ||
                        `Bienvenue @user dans @group`;

                    const metadata = await client.groupMetadata(chatId);

                    text = text
                        .replace(/@user/g, `@${user.split('@')[0]}`)
                        .replace(/@group/g, metadata.subject)
                        .replace(/@desc/g, metadata.desc || '');

                    await client.sendMessage(chatId, {
                        image: { url: randomImage() },
                        caption: box(
                            'WELCOME USER',
                            `┃❐┃ ✧➤ ${text}`
                        ),
                        mentions: [user],
                        contextInfo: newsletterContext(chatId)
                    });
                }
            }
        }
    }
];