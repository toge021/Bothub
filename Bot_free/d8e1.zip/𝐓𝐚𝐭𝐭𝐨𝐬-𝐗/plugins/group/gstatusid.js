const fs = require('fs');
const path = require('path');
const { downloadContentFromMessage } = require('gifted-baileys');

const DB_PATH = path.join(__dirname, '../../lib/gstatus.json');

function loadDB() {
    if (!fs.existsSync(DB_PATH)) {
        fs.writeFileSync(DB_PATH, JSON.stringify({ groups: [] }, null, 2));
    }
    return JSON.parse(fs.readFileSync(DB_PATH));
}

function saveDB(data) {
    fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = {
    name: 'gstatusid',
    aliases: ['bgid'],
    category: 'group',
    description: 'Active/Désactive le statut global pour tous les groupes',
    usage: '.gstatusid on/off (ou répondre média/texte)',

    groupOnly: true,
    adminOnly: true,
    newsletterShow: true,

    execute: async (client, message, args) => {
        const from = message.key.remoteJid;
        const quoted = message.message?.extendedTextMessage?.contextInfo?.quotedMessage;
        const db = loadDB();

        const option = args[0]?.toLowerCase();

        // ✅ OFF
        if (option === 'off') {
            db.groups = db.groups.filter(id => id !== from);
            saveDB(db);

            return client.sendMessage(from, {
                text: '✅ GSTATUS désactivé dans ce groupe.'
            }, { quoted: message });
        }

        // ✅ ON
        if (option === 'on') {
            if (!db.groups.includes(from)) {
                db.groups.push(from);
                saveDB(db);
            }

            return client.sendMessage(from, {
                text: '✅ GSTATUS activé dans ce groupe.\nTous tes futurs statuts seront envoyés ici.'
            }, { quoted: message });
        }

        // ❌ Aucun message
        if (!quoted && !args.length) {
            return client.sendMessage(from, {
                text: '⚠️ Utilise:\n.gstatus on\n.gstatus off\nou réponds à un message.'
            }, { quoted: message });
        }

        await client.sendMessage(from, {
            react: { text: '⏳', key: message.key }
        });

        try {
            let statusContent = {};

            const targetMessage = quoted || message.message;

            // IMAGE
            if (targetMessage.imageMessage) {
                const stream = await downloadContentFromMessage(targetMessage.imageMessage, 'image');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                statusContent = {
                    image: buffer,
                    caption: targetMessage.imageMessage.caption || args.join(' ')
                };
            }

            // VIDEO
            else if (targetMessage.videoMessage) {
                const stream = await downloadContentFromMessage(targetMessage.videoMessage, 'video');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                statusContent = {
                    video: buffer,
                    caption: targetMessage.videoMessage.caption || args.join(' ')
                };
            }

            // AUDIO
            else if (targetMessage.audioMessage) {
                const stream = await downloadContentFromMessage(targetMessage.audioMessage, 'audio');
                let buffer = Buffer.from([]);
                for await (const chunk of stream) {
                    buffer = Buffer.concat([buffer, chunk]);
                }

                statusContent = {
                    audio: buffer,
                    mimetype: 'audio/mp4',
                    ptt: true
                };
            }

            // TEXTE
            else {
                const text = quoted
                    ? (quoted.conversation || quoted.extendedTextMessage?.text)
                    : args.join(' ');

                statusContent = {
                    text,
                    backgroundColor: '#000000',
                    font: 1
                };
            }

            // 🔥 Envoi à tous les groupes activés
            for (const jid of db.groups) {
                await client.sendMessage(jid, {
                    groupStatusMessage: statusContent
                }).catch(() => {});
            }

            await client.sendMessage(from, {
                react: { text: '✅', key: message.key }
            });

        } catch (e) {
            console.error(e);

            await client.sendMessage(from, {
                text: '❌ Erreur lors de l’envoi du statut.'
            }, { quoted: message });
        }
    }
};