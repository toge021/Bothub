const axios = require('axios');

const LANGUAGES = {
    auto: 'Détection automatique',
    fr: 'Français',
    en: 'Anglais',
    es: 'Espagnol',
    de: 'Allemand',
    it: 'Italien',
    pt: 'Portugais',
    nl: 'Néerlandais',
    ru: 'Russe',
    zh: 'Chinois',
    ja: 'Japonais',
    ko: 'Coréen',
    ar: 'Arabe',
    hi: 'Hindi',
    tr: 'Turc'
};

function box(title, body = '') {
    return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸            ⌬
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

function newsletterContext(jid, old = {}) {
    return {
        ...(old || {}),
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363424639365907@newsletter",
            newsletterName: "𝐓𝐚𝐭𝐭𝐨𝐬-𝐗",
            serverMessageId: 1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: jid
        }
    };
}

async function translateText(text, targetLang, sourceLang = 'auto') {
    try {
        const url =
            `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sourceLang}&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;

        const response = await axios.get(url, { timeout: 10000 });

        let translated = '';

        if (response.data && response.data[0]) {
            for (const part of response.data[0]) {
                if (part[0]) translated += part[0];
            }
        }

        return translated || null;
    } catch (error) {
        console.log(error.message);
        return null;
    }
}

module.exports = {
    name: 'translate',
    aliases: ['tr', 'tl'],
    category: 'tools',
    description: 'Traduit un texte',
    usage: '.translate fr bonjour',
    groupOnly: false,
    adminOnly: false,
    ownerOnly: false,
    newsletterShow: true,

    execute: async (client, message, args) => {
        const remoteJid = message.key.remoteJid;
        const quotedMsg =
            message.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (args.length === 0 && !quotedMsg) {
            const langList = Object.entries(LANGUAGES)
                .filter(([code]) => code !== 'auto')
                .map(([code, name]) => `┃❐┃ ✧➤ ${code} = ${name}`)
                .join('\n');

            return client.sendMessage(remoteJid, {
                text: box(
                    'TRANSLATE',
                    `┃❐┃ ✧➤ LANGUAGES :
${langList}

┃❐┃ ✧➤ USE :
┃❐┃ ✧➤ .translate fr hello`
                ),
                contextInfo: newsletterContext(remoteJid)
            });
        }

        let textToTranslate = '';
        let targetLang = 'fr';
        let argsCopy = [...args];

        if (argsCopy.length > 0 && LANGUAGES[argsCopy[0]]) {
            targetLang = argsCopy.shift();
        }

        if (argsCopy.length > 0) {
            textToTranslate = argsCopy.join(' ').trim();
        } else if (quotedMsg) {
            textToTranslate =
                quotedMsg.conversation ||
                quotedMsg.extendedTextMessage?.text ||
                '';
        }

        if (!textToTranslate) {
            return client.sendMessage(remoteJid, {
                text: box(
                    'TRANSLATE',
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Aucun texte trouvé.`
                ),
                contextInfo: newsletterContext(remoteJid)
            });
        }

        await client.sendMessage(remoteJid, {
            react: { text: '⏳', key: message.key }
        }).catch(() => {});

        try {
            const translated = await translateText(
                textToTranslate,
                targetLang,
                'auto'
            );

            if (!translated) throw new Error();

            const targetName = LANGUAGES[targetLang] || targetLang;

            await client.sendMessage(remoteJid, {
                text: box(
                    'TRANSLATE',
                    `┃❐┃ ✧➤ TO : ${targetName}
┃❐┃ ✧➤ ORIGINAL :
┃❐┃ ${textToTranslate}

┃❐┃ ✧➤ RESULT :
┃❐┃ ${translated}`
                ),
                contextInfo: newsletterContext(remoteJid)
            });

            await client.sendMessage(remoteJid, {
                react: { text: '✅', key: message.key }
            }).catch(() => {});

        } catch (error) {
            await client.sendMessage(remoteJid, {
                text: box(
                    'TRANSLATE',
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Traduction échouée.`
                ),
                contextInfo: newsletterContext(remoteJid)
            });

            await client.sendMessage(remoteJid, {
                react: { text: '❌', key: message.key }
            }).catch(() => {});
        }
    }
};