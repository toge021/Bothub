module.exports = {
    name: 'gstatusdel',
    aliases: ['delstatus', 'clearstatus'],
    category: 'group',
    description: 'Supprime tous les statuts groupes envoyés par le bot',
    usage: '.gstatusdel',

    ownerOnly: true,
    newsletterShow: true,

    execute: async (client, message, args) => {
        const from = message.key.remoteJid;

        await client.sendMessage(from, {
            react: { text: '⏳', key: message.key }
        });

        try {
            // 🔥 Récupère tous les groupes
            const groups = await client.groupFetchAllParticipating();
            const ids = Object.keys(groups);

            let deleted = 0;

            for (const jid of ids) {
                try {
                    // Supprime les anciens statuts du groupe
                    await client.sendMessage(jid, {
                        groupStatusMessage: {
                            delete: true
                        }
                    });

                    deleted++;
                } catch (e) {}
            }

            await client.sendMessage(from, {
                text: `✅ ${deleted} statut(s) supprimé(s) dans les groupes.`
            }, { quoted: message });

            await client.sendMessage(from, {
                react: { text: '✅', key: message.key }
            });

        } catch (e) {
            console.error(e);

            await client.sendMessage(from, {
                text: '❌ Erreur lors de la suppression des statuts.'
            }, { quoted: message });

            await client.sendMessage(from, {
                react: { text: '❌', key: message.key }
            });
        }
    }
};