const axios = require('axios');
const fs = require('fs');
const path = require('path');

const CONFIG_FILE = path.join(__dirname, '../../lib/speck.json');

const LANGUAGES = {
    fr: 'Français',
    en: 'Anglais',
    es: 'Espagnol',
    de: 'Allemand',
    it: 'Italien',
    pt: 'Portugais',
    ar: 'Arabe',
    hi: 'Hindi',
    tr: 'Turc',
    ru: 'Russe'
};

function box(title, body = '') {
    return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸            ⌬
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

function newsletterContext(jid, old = {}) {
    return {
        ...(old || {}),
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363424639365907@newsletter",
            newsletterName: "𝐓𝐚𝐭𝐭𝐨𝐬-𝐗",
            serverMessageId: 1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: jid
        }
    };
}

function loadConfig() {
    if (!fs.existsSync(CONFIG_FILE)) {
        fs.writeFileSync(CONFIG_FILE, JSON.stringify({ enabled: false, lang: "en" }, null, 2));
    }
    return JSON.parse(fs.readFileSync(CONFIG_FILE));
}

function saveConfig(data) {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(data, null, 2));
}

async function translateText(text, targetLang) {
    try {
        const url =
            `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${targetLang}&dt=t&q=${encodeURIComponent(text)}`;

        const res = await axios.get(url, { timeout: 10000 });

        let translated = '';

        if (res.data && res.data[0]) {
            for (const part of res.data[0]) {
                if (part[0]) translated += part[0];
            }
        }

        return translated || text;
    } catch {
        return text;
    }
}

module.exports = [
    {
        name: 'speck',
        aliases: [],
        category: 'owner',
        description: 'Auto traduction des messages sortants',
        usage: '.speck en on / .speck off',
        ownerOnly: true,
        newsletterShow: true,

        execute: async (client, message, args) => {
            const jid = message.key.remoteJid;
            const conf = loadConfig();

            if (!args[0]) {
                return client.sendMessage(jid, {
                    text: box(
                        'SPECK',
                        `┃❐┃ ✧➤ STATUS : ${conf.enabled ? 'ON' : 'OFF'}
┃❐┃ ✧➤ LANG : ${conf.lang}
┃❐┃ ✧➤ USE :
┃❐┃ ✧➤ .speck en on
┃❐┃ ✧➤ .speck off`
                    ),
                    contextInfo: newsletterContext(jid)
                });
            }

            if (args[0].toLowerCase() === 'off') {
                conf.enabled = false;
                saveConfig(conf);

                return client.sendMessage(jid, {
                    text: box(
                        'SPECK',
                        `┃❐┃ ✧➤ STATUS : OFF`
                    ),
                    contextInfo: newsletterContext(jid)
                });
            }

            const lang = args[0].toLowerCase();
            const state = args[1]?.toLowerCase();

            if (!LANGUAGES[lang]) {
                return client.sendMessage(jid, {
                    text: box(
                        'SPECK',
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Langue invalide.`
                    ),
                    contextInfo: newsletterContext(jid)
                });
            }

            if (state !== 'on') {
                return client.sendMessage(jid, {
                    text: box(
                        'SPECK',
                        `┃❐┃ ✧➤ USE :
┃❐┃ ✧➤ .speck ${lang} on`
                    ),
                    contextInfo: newsletterContext(jid)
                });
            }

            conf.enabled = true;
            conf.lang = lang;
            saveConfig(conf);

            return client.sendMessage(jid, {
                text: box(
                    'SPECK',
                    `┃❐┃ ✧➤ STATUS : ON
┃❐┃ ✧➤ LANG : ${LANGUAGES[lang]}`
                ),
                contextInfo: newsletterContext(jid)
            });
        }
    },

    {
        name: 'speck_listener',
        hidden: true,

        execute: async (client, message) => {
            try {
                if (!message.key.fromMe) return;

                const jid = message.key.remoteJid;
                const conf = loadConfig();

                if (!conf.enabled) return;

                const text =
                    message.message?.conversation ||
                    message.message?.extendedTextMessage?.text;

                if (!text) return;

                if (text.startsWith('.')) return;

                const translated = await translateText(text, conf.lang);

                if (!translated || translated.trim() === text.trim()) return;

                await client.sendMessage(jid, {
                    delete: message.key
                }).catch(() => {});

                await client.sendMessage(jid, {
                    text: translated,
                    contextInfo: newsletterContext(jid)
                });

            } catch (e) {
                console.log(e);
            }
        }
    }
];