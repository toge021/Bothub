const { updateGroupSetting, getGroupSettings } = require('../../lib/database');

const GOODBYE_IMAGES = [
    "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
    "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
    "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
    "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg"
];

function randomImage() {
    return GOODBYE_IMAGES[Math.floor(Math.random() * GOODBYE_IMAGES.length)];
}

function box(title, body = '') {
    return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸            ⌬
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

function newsletterContext(jid, old = {}) {
    return {
        ...(old || {}),
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363424639365907@newsletter",
            newsletterName: "𝐓𝐚𝐭𝐭𝐨𝐬-𝐗",
            serverMessageId: 1
        },
        businessMessageForwardInfo: {
            businessOwnerJid: jid
        }
    };
}

module.exports = [
    {
        name: 'goodbye',
        aliases: ['bye', 'leave'],
        category: 'group',
        description: 'Active/Désactive le message goodbye',
        usage: '.goodbye <on/off>',
        groupOnly: true,
        adminOnly: true,
        newsletterShow: true,

        execute: async (client, message, args) => {
            const chatId = message.key.remoteJid;
            const setting = args[0]?.toLowerCase();
            const currentConfig = getGroupSettings(chatId);

            if (!setting) {
                return client.sendMessage(chatId, {
                    image: { url: randomImage() },
                    caption: box(
                        'GOODBYE',
                        `┃❐┃ ✧➤ STATUS : ${currentConfig.goodbye ? 'ON' : 'OFF'}
┃❐┃ ✧➤ USE : .goodbye on/off`
                    ),
                    contextInfo: newsletterContext(chatId)
                }, { quoted: message });
            }

            if (setting === 'on') {
                updateGroupSetting(chatId, 'goodbye', true);

                return client.sendMessage(chatId, {
                    image: { url: randomImage() },
                    caption: box(
                        'GOODBYE',
                        `┃❐┃ ✧➤ SUCCESS
┃❐┃ ✧➤ Goodbye activé.`
                    ),
                    contextInfo: newsletterContext(chatId)
                }, { quoted: message });
            }

            if (setting === 'off') {
                updateGroupSetting(chatId, 'goodbye', false);

                return client.sendMessage(chatId, {
                    image: { url: randomImage() },
                    caption: box(
                        'GOODBYE',
                        `┃❐┃ ✧➤ SUCCESS
┃❐┃ ✧➤ Goodbye désactivé.`
                    ),
                    contextInfo: newsletterContext(chatId)
                }, { quoted: message });
            }
        }
    },

    {
        name: 'setgoodbye',
        aliases: [],
        category: 'group',
        description: 'Configure le message goodbye',
        usage: '.setgoodbye <message>',
        groupOnly: true,
        adminOnly: true,
        newsletterShow: true,

        execute: async (client, message, args) => {
            const chatId = message.key.remoteJid;
            const text = args.join(' ');

            if (!text) {
                return client.sendMessage(chatId, {
                    image: { url: randomImage() },
                    caption: box(
                        'SETGOODBYE',
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Message manquant.`
                    ),
                    contextInfo: newsletterContext(chatId)
                }, { quoted: message });
            }

            updateGroupSetting(chatId, 'goodbyeMessage', text);

            return client.sendMessage(chatId, {
                image: { url: randomImage() },
                caption: box(
                    'SETGOODBYE',
                    `┃❐┃ ✧➤ SUCCESS
┃❐┃ ✧➤ Message mis à jour.`
                ),
                contextInfo: newsletterContext(chatId)
            }, { quoted: message });
        }
    },

    {
        name: 'goodbye_event',
        aliases: [],
        category: 'hidden',
        hidden: true,
        newsletterShow: true,

        execute: async (client, update) => {
            const chatId = update.id;
            const config = getGroupSettings(chatId);

            if (!config.goodbye) return;

            for (const user of update.participants) {
                if (update.action === 'remove') {
                    let text = config.goodbyeMessage ||
                        `Au revoir @user de @group`;

                    const metadata = await client.groupMetadata(chatId);

                    text = text
                        .replace(/@user/g, `@${user.split('@')[0]}`)
                        .replace(/@group/g, metadata.subject)
                        .replace(/@desc/g, metadata.desc || '');

                    await client.sendMessage(chatId, {
                        image: { url: randomImage() },
                        caption: box(
                            'GOODBYE USER',
                            `┃❐┃ ✧➤ ${text}`
                        ),
                        mentions: [user],
                        contextInfo: newsletterContext(chatId)
                    });
                }
            }
        }
    }
];