const axios = require('axios');
const { downloadContentFromMessage } = require('gifted-baileys');

const URL_IMAGES = [
    "https://i.ibb.co/Qv94TXLm/c90b399124f9.jpg",
    "https://i.ibb.co/Kx4WLJzn/65c9084dac77.jpg",
    "https://i.ibb.co/SDCKHFSy/5617087035b5.jpg",
    "https://i.ibb.co/35Jzpp1W/77836434fa80.jpg"
];

function randomImage() {
    return URL_IMAGES[Math.floor(Math.random() * URL_IMAGES.length)];
}

function box(title, body = '') {
    return `
╭❐╮╭━━━═⧉ ⧉═━━━═⧉ ⧉═━━╮
┃❐┃⌬            🕸 ${title} 🕸      
┃❐┃╰━━━═⧉ ⧉═━━━═⧉ ⧉═━━╯
${body}
╰❐╯ ✧➤`.trim();
}

module.exports = {
    name: 'url',
    aliases: ['tourl', 'imgurl'],
    category: 'tools',
    description: 'Upload image/video/audio/sticker/document et génère un lien',
    usage: '.url',
    newsletterShow: true,

    async execute(sock, m, args) {
        const from = m.key.remoteJid;
        const quoted = m.message?.extendedTextMessage?.contextInfo?.quotedMessage;

        if (!quoted) {
            return sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    'URL',
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Réponds à un média.`
                )
            }, { quoted: m });
        }

        try {
            let media = null;
            let type = null;
            let ext = "file";

            if (quoted.imageMessage) {
                media = quoted.imageMessage;
                type = 'image';
                ext = 'jpg';
            } 
            else if (quoted.videoMessage) {
                media = quoted.videoMessage;
                type = 'video';
                ext = 'mp4';
            } 
            else if (quoted.audioMessage) {
                media = quoted.audioMessage;
                type = 'audio';
                ext = 'mp3';
            } 
            else if (quoted.stickerMessage) {
                media = quoted.stickerMessage;
                type = 'sticker';
                ext = 'webp';
            } 
            else if (quoted.documentMessage) {
                media = quoted.documentMessage;
                type = 'document';
                ext = media.fileName?.split('.').pop() || 'bin';
            }

            if (!media) {
                return sock.sendMessage(from, {
                    image: { url: randomImage() },
                    caption: box(
                        'URL',
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Média non supporté.`
                    )
                }, { quoted: m });
            }

            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    'UPLOAD',
                    `┃❐┃ ✧➤ STATUS
┃❐┃ ✧➤ Upload en cours...`
                )
            }, { quoted: m });

            const stream = await downloadContentFromMessage(media, type);
            let buffer = Buffer.from([]);

            for await (const chunk of stream) {
                buffer = Buffer.concat([buffer, chunk]);
            }

            const apiKey = process.env.IMGBB_KEY;

            if (!apiKey) {
                return sock.sendMessage(from, {
                    image: { url: randomImage() },
                    caption: box(
                        'URL',
                        `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ API ImgBB manquante.`
                    )
                }, { quoted: m });
            }

            const base64 = buffer.toString('base64');

            const res = await axios.post(
                'https://api.imgbb.com/1/upload',
                new URLSearchParams({
                    key: apiKey,
                    image: base64,
                    name: `upload.${ext}`
                }),
                {
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded'
                    }
                }
            );

            const url = res.data.data.url;

            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    'SUCCESS',
                    `┃❐┃ ✧➤ TYPE : ${type.toUpperCase()}
┃❐┃ ✧➤ LINK :
┃❐┃ ✧➤ ${url}`
                )
            }, { quoted: m });

        } catch (e) {
            console.error("UPLOAD ERROR:", e.response?.data || e.message);

            await sock.sendMessage(from, {
                image: { url: randomImage() },
                caption: box(
                    'URL',
                    `┃❐┃ ✧➤ ERROR
┃❐┃ ✧➤ Erreur lors de l'upload.`
                )
            }, { quoted: m });
        }
    }
};