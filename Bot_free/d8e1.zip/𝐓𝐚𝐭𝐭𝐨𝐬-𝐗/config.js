// ⚙️ REN-MDX - CONFIGURATION (Via .env)
require('dotenv').config();

module.exports = {
  // --- IDENTITÉ ---
  botName: process.env.BOT_NAME || '𝐓𝐚𝐭𝐭𝐨𝐬-𝐗' ,
  ownerName: process.env.OWNER_NAME || 'Admin',
  ownerNumber: (process.env.OWNER_NUMBER || '237682229367').split(','), // Support multi-owner via virgule
  phoneNumber: process.env.OWNER_NUMBER || '237682229367', // Pour pairing code
  prefix: process.env.PREFIX || '.',

  // --- PARAMÈTRES INTERNES ---
  sessionName: process.env.SESSION_NAME || 'session',
  defaultLang: process.env.DEFAULT_LANG || 'fr',
  autoRead: process.env.AUTO_READ === 'true',
  
  // --- NEWSLETTER & LINKS ---
  newsletterJid: process.env.NEWSLETTER_JID || '120363424639365907@newsletter',
  logoUrl: process.env.LOGO_URL || 'https://i.ibb.co/PzCSCjZq/1f782e6edddc.jpg',

  // --- OPTIMISATIONS ---
  syncFullHistory: false, 
  keepAliveInterval: 30000, 

  // --- BASE DE DONNÉES (JSON) ---
  database: {
    users: './database/users.json',
    groups: './database/groups.json',
    settings: './database/settings.json'
  }
};