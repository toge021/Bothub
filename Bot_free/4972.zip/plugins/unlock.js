import fetch from "node-fetch";
export const name = "unlock";

export async function execute(sock, msg) {
  const from = msg.key.remoteJid;
  await sock.groupSettingUpdate(from, "not_announcement");

  const pp = await fetch("https://devhackers-link-generator.onrender.com/874f.jpeg").then(r => r.buffer());

  await sock.sendMessage(from, {
    image: pp,
    caption:
`🔓 GROUPE DÉVERROUILLÉ

Tous les membres peuvent désormais envoyer des messages.

— DEV HACKERS
Bot : XMD V1-KYRO`
  });
}