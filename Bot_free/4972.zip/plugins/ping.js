export const name = "ping";

export async function execute(sock, msg, args) {
  try {
    const from = msg.key.remoteJid;

    const start = Date.now();
    const sentMsg = await sock.sendMessage(from, { text: "pong !..." }, { quoted: msg });
    const latency = Date.now() - start;

    const reply = `𝑪𝒂𝒍𝒄𝒖𝒍𝒆 𝒅𝒆 𝒍𝒂 𝒗𝒊𝒕𝒆𝒔𝒔𝒆 𝒗𝒂𝒘𝒖𝒍𝒆𝒏𝒕𝒆 : ${latency} ms\n\n𝑪𝑶𝑹𝑽𝑼𝑺 𝑴𝑫`;

    await sock.sendMessage(from, { text: reply }, { quoted: sentMsg });

  } catch (err) {
    console.error("❌ Erreur ping :", err);
    await sock.sendMessage(msg.key.remoteJid, {
      text: "Impossible de calculer la vitesse.\n\n𝑪𝑶𝑹𝑽𝑼𝑺 𝑴𝑫"
    }, { quoted: msg });
  }
}