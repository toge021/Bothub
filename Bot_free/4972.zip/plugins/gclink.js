export const name = "gclink";

export async function execute(sock, msg, args) {

const from = msg.key.remoteJid

if(!from.endsWith("@g.us")){
return sock.sendMessage(from,{text:"❌ Cette commande fonctionne seulement dans un groupe"})
}

try{

const code = await sock.groupInviteCode(from)

await sock.sendMessage(from,{
image:{url:"https://devhackers-link-generator.onrender.com/874f.jpeg"},
caption:`🔗 *LIEN DU GROUPE*

https://chat.whatsapp.com/${code}

BY DEV KIYOTAKA`
},{quoted:msg})

}catch(err){

sock.sendMessage(from,{text:"❌ Impossible de récupérer le lien"})
}

}