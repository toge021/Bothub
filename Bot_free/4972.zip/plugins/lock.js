import fetch from "node-fetch";
export const name = "lock";

export async function execute(sock, msg) {
  const from = msg.key.remoteJid;
  await sock.groupSettingUpdate(from, "announcement");

  const pp = await fetch("https://devhackers-link-generator.onrender.com/874f.jpeg").then(r => r.buffer());

  await sock.sendMessage(from, {
    image: pp,
    caption:
`🔒 GROUPE VERROUILLÉ

Seuls les administrateurs peuvent envoyer des messages.

— DEV HACKERS
Bot : XMD V1-KYRO`
  });
}