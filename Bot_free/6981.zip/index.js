import makeWASocket, { 
    useMultiFileAuthState, 
    DisconnectReason, 
    fetchLatestBaileysVersion, 
    makeCacheableSignalKeyStore, 
    jidDecode 
} from '@whiskeysockets/baileys';
import pino from 'pino';
import { Boom } from '@hapi/boom';
import fs from 'fs';
import readline from 'readline';
import * as config from './config.js';
import { handler } from './handler.js';

async function startSadeus() {
    const { state, saveCreds } = await useMultiFileAuthState("session");
    const { version } = await fetchLatestBaileysVersion();

    const sock = makeWASocket({
        version,
        logger: pino({ level: "silent" }),
        printQRInTerminal: false,
        auth: {
            creds: state.creds,
            keys: makeCacheableSignalKeyStore(state.keys, pino({ level: "silent" })),
        },
        browser: ["Ubuntu", "Chrome", "20.0.04"],
    });

    if (!sock.authState.creds.registered) {
        console.log("━━━━━━━━━━━━━━━━━━━━━━━");
        console.log("SADEUS FAMILY BOT - CONNEXION");
        console.log("━━━━━━━━━━━━━━━━━━━━━━━");
        
        const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
        const question = (text) => new Promise((resolve) => rl.question(text, resolve));
        
        let phoneNumber = await question("Entrez votre numéro de téléphone (ex: 228XXXXXXXX) : ");
        phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
        
        if (!phoneNumber) {
            console.log("Numéro invalide. Relancez le bot.");
            process.exit(1);
        }
        
        rl.close();
        
        setTimeout(async () => {
            let code = await sock.requestPairingCode(phoneNumber.trim());
            console.log("━━━━━━━━━━━━━━━━━━━━━━━");
            console.log(`VOTRE CODE : ${code}`);
            console.log("━━━━━━━━━━━━━━━━━━━━━━━");
        }, 3000);
    }

    sock.ev.on("creds.update", saveCreds);

    sock.ev.on("connection.update", (update) => {
        const { connection, lastDisconnect } = update;
        if (connection === "close") {
            let reason = new Boom(lastDisconnect?.error)?.output.statusCode;
            if (reason === DisconnectReason.loggedOut) {
                console.log("Déconnecté. Supprimez le dossier session et relancez.");
            } else {
                startSadeus();
            }
        } else if (connection === "open") {
            console.log("━━━━━━━━━━━━━━━━━━━━━━━");
            console.log("SADEUS FAMILY BOT EN LIGNE ! 🐍");
            console.log("━━━━━━━━━━━━━━━━━━━━━━━");
        }
    });

    sock.ev.on("messages.upsert", async (chatUpdate) => {
        try {
            const mek = chatUpdate.messages[0];
            if (!mek.message) return;
            await handler(sock, mek);
        } catch (err) {
            console.log(err);
        }
    });

    sock.decodeJid = (jid) => {
        if (!jid) return jid;
        if (/:\d+@/gi.test(jid)) {
            let decode = jidDecode(jid) || {};
            return (decode.user && decode.server && decode.user + "@" + decode.server) || jid;
        } else return jid;
    };
}

startSadeus();
