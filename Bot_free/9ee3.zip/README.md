# Kurosaki

> By Daniel_Chérie

**Généré par [SIGMA MDX Builder](https://sigma-mdx.replit.app)**

## Démarrage rapide

> ✅ Votre `.env` est **déjà configuré** avec votre Session ID, préfixe et numéro propriétaire.

```bash
npm install
npm run dev
```

Pour un déploiement en production (VPS, Railway, Render…) :

```bash
npm install
npm start
```
