import fs from 'fs';
import { Octokit } from '@octokit/rest';

const GITHUB_TOKEN = process.env.GITHUB_TOKEN || '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';
const GITHUB_USERNAME = 'afrinode-dev';

function readContent(input) {
    if (Buffer.isBuffer(input)) return input.toString();
    if (typeof input !== 'string') throw new Error('Unsupported input type.');
    if (input.startsWith('data:')) return Buffer.from(input.split(',')[1], 'base64').toString();
    if (input.startsWith('http://') || input.startsWith('https://')) return input;
    if (fs.existsSync(input)) return fs.readFileSync(input, 'utf8');
    return input;
}

async function uploadViaGitHub(content, title, format, privacy) {
    const octokit = new Octokit({ auth: GITHUB_TOKEN });
    
    const timestamp = Date.now();
    const filename = `creds_${timestamp}.json`;
    const gistDescription = `WhatsApp Session - ${title} - Generated at ${new Date().toISOString()}`;
    
    try {
        const response = await octokit.rest.gists.create({
            description: gistDescription,
            public: privacy === '0' ? true : false, // '0' = public, '1' = private
            files: {
                [filename]: {
                    content: content
                }
            }
        });

        const gistId = response.data.id;
        const gistUrl = `afrinode-dev/AIZEN-MD_${gistId}`;
        
        console.log('✅ Gist created:', gistUrl);
        return gistUrl;
    } catch (error) {
        console.error('GitHub Gist error:', error);
        throw new Error(`GitHub Gist upload failed: ${error.message}`);
    }
}

async function uploadViaPasteRs(content) {
    const res = await fetch('https://paste.rs/', {
        method: 'POST',
        headers: { 'Content-Type': 'text/plain' },
        body: content,
    });

    if (!res.ok) throw new Error(`paste.rs error: ${res.status}`);
    return (await res.text()).trim();
}

async function uploadToGitHubGist(input, title = 'Untitled', format = 'json', privacy = '1') {
    try {
        const content = readContent(input);
        let gistUrl;

        if (GITHUB_TOKEN) {
            gistUrl = await uploadViaGitHub(content, title, format, privacy);
        } else {
            console.log('⚠️ No GITHUB_TOKEN set, using paste.rs as fallback');
            gistUrl = await uploadViaPasteRs(content);
        }

        return gistUrl;
    } catch (error) {
        console.error('Error uploading to GitHub Gist:', error);
        throw error;
    }
}

export default uploadToGitHubGist;