import path from 'path';
import fs from 'fs';
import axios from 'axios';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const GITHUB_USERNAME = 'afrinode-dev';

/**
 * Save credentials from GitHub Gist to session/creds.json
 * @param {string} txt - Gist ID with optional prefix (afrinode-dev/AIZEN-MD_gistId)
 */
async function SaveCreds(txt) {
    // Extract Gist ID from format: afrinode-dev/AIZEN-MD_gistId
    const gistId = txt.replace(`afrinode-dev/AIZEN-MD_`, '');
    const gistUrl = `https://gist.githubusercontent.com/${GITHUB_USERNAME}/${gistId}/raw`;

    try {
        console.log(`📥 Downloading credentials from: ${gistUrl}`);
        
        const response = await axios.get(gistUrl);
        
        // Handle both string and object responses
        const data = typeof response.data === 'string' ? response.data : JSON.stringify(response.data, null, 2);
        
        // Ensure session directory exists
        const sessionDir = path.join(__dirname, 'session');
        if (!fs.existsSync(sessionDir)) {
            fs.mkdirSync(sessionDir, { recursive: true });
            console.log('📁 Created session directory');
        }
        
        // Save credentials
        const credsPath = path.join(sessionDir, 'creds.json');
        fs.writeFileSync(credsPath, data);
        
        console.log('✅ Credentials saved successfully to session/creds.json');
        
        // Verify file was written
        if (fs.existsSync(credsPath)) {
            const stats = fs.statSync(credsPath);
            console.log(`📄 File size: ${stats.size} bytes`);
        }

    } catch (error) {
        console.error('❌ Error downloading or saving credentials:', error.message);
        if (error.response) {
            console.error('❌ Status:', error.response.status);
            console.error('❌ Response:', error.response.data);
        }
        throw error;
    }
}

export default SaveCreds;