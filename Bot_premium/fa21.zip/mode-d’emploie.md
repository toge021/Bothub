# 🤖 TOGE-MD-V5 — WhatsApp Bot Multi-Session

**TOGE-MD-V5** est un bot WhatsApp avancé développé en JavaScript (Node.js) avec `@whiskeysockets/baileys`.  
Il supporte **le multi‑session**, **l’isolation totale des données par session**, une **API REST complète**, un **système de modération**, des **commandes personnalisables** et un **mode « pairing code »** pour connecter facilement de nouveaux comptes.

---

## ✨ Fonctionnalités principales

### 🔌 Multi‑session
- Gestion de plusieurs comptes WhatsApp simultanément.
- **Isolation complète** : chaque session possède ses propres fichiers de configuration, base de données, mods, bannissements, personnages, etc.
- Stockage local dans `./sessions/session_<numéro>/`.

### 🔐 Pairing Code
- Connexion de nouveaux comptes **sans QR code** (via `requestPairingCode`).
- API dédiée : `GET /api/pair-code?number=241XXXXXXXX`.
- Support du mode pairing automatique si aucune session n’existe.

### 🧠 Commandes & modularité
- Chargement dynamique des commandes depuis le dossier `./commands/`.
- Suggestions automatiques en cas de faute de frappe.
- **Commandes intégrées** : gestion des mods, bannissement, mode public/self/private, personnages, antiviewonce, antilink, antiflood, antidelete, antitag, autoleave, autokick, nightmode, etc.

### 👑 Système de modération
- Propriétaire (OWNER_NUMBER).
- Modérateurs (`.mods list` / `.setmod` / `.removemod`).
- Accès superposables : owner > authorized (sudo) > mods.
- Modes bot : `public`, `self` (ignorer tout sauf owner), `private` (autoriser uniquement certains utilisateurs).

### 🎭 Personnages
- Changement de personnalité / style de réponse via `.setchar`.
- Chaque session peut avoir son propre personnage.
- Commande `.characters` pour lister les personnalités disponibles.

### 📦 Base de données par session
- Fichiers JSON isolés : `database.json`, `banned.json`, `mods.json`, `acces.json`, `private.json`, `bangroup.json`, `antilinks.json`, `welcome.json`, `goodbye.json`, `pmchatbot.json`, `character.json`, `botmode.json`, …
- Migration automatique depuis l’ancienne structure `./db/`.

### 🛡️ Sécurité & Anti‑abus
- **Anti‑spam** / **Anti‑flood**.
- **Anti‑delete** : détection et log des messages supprimés.
- **Anti‑viewonce** : téléchargement des messages éphémères.
- **Anti‑link** (WhatsApp et généraux).
- **Anti‑tag** / **Anti‑groupement mention**.
- **Bannissement** : utilisateurs / groupes.
- **Auto‑kick** temporisé.
- **Blacklist** globale et par session.

### 📨 Gestion des groupes
- **Bienvenue / Au revoir** personnalisables avec image de profil.
- **Anti‑promote / Anti‑demote** automatique.
- **Auto‑accept** des demandes d’entrée (`.aceptar`).
- **Anti‑kick** (`.antikickall`).

### 🧩 Modules supplémentaires
- **Chatbot privé** (`.pmchatbot on/off`).
- **Auto‑typing** / **Auto‑recording** à l’arrivée d’un message.
- **Auto‑like** des statuts.
- **Auto‑verse** : verset biblique programmé.
- **Night mode** : désactivation programmée du bot dans un groupe.
- **Sauvegarde des statuts** (images/vidéos) via `.status`.
- **Journalisation des conversations**.

### 🧠 Gestion des médias
- Téléchargement de messages `view once`.
- Envoi d’images, vidéos, stickers, audio (PTT), documents, contacts, localisation.
- Résolution automatique des `lid` (identifiants temporaires WhatsApp).

---

## 🚀 Installation & démarrage

### Prérequis
- Node.js **v18+**
- `npm` ou `yarn`

### Étapes

```bash
# 1. Cloner le projet
git clone https:/github.com/toge021/TOGE-MD-V5.git
cd TOGE-MD-V5

# 2. Installer les dépendances
npm install

# 3. Configurer le fichier settings.js (à la racine)
#    – OWNER_NUMBER : votre numéro (format international, sans +)
#    – PREFIX : préfixe par défaut (ex : ".")
#    – SESSION_ID (optionnel) : numéro à connecter automatiquement

# 4. Lancer le bot
npm start