# KIYOTAKA MD - Bot WhatsApp

Bot généré via Dev-Hackers Bot Builder.

## Installation

```bash
npm install
```

## Démarrage

```bash
npm start
```

Au premier démarrage :
1. Entrez votre numéro WhatsApp (format international, sans le +)
2. Vous recevrez un code à 8 chiffres sur WhatsApp
3. Entrez ce code dans le terminal

Le bot est alors connecté !

## Commandes disponibles

Préfixe : `!`
- `!menu` : Affiche le menu
- `!tagall` : Mentionne tous les membres du groupe
- `!sticker` : Transforme une image en sticker
- Et plus de 30 commandes...

## Propriétaire

Numéro : 33652128731

---
Créé par Dev-Hackers - Bot Builder
